import { BudgetSettings, Supplier } from '../store'
export type BudgetSummary = { min:number; likely:number; max:number; committedTotal:number; committedPaid:number; committedRemaining:number }
export function calcBudget(settings:BudgetSettings, suppliers:Supplier[]):BudgetSummary{
  const guests = settings.guestsExact ?? Math.round((settings.guestsMin + settings.guestsMax)/2)
  const giftTotalLikely = guests * settings.giftAvg
  const saveRatio = Math.max(0, Math.min(0.5, settings.savePercent/100))
  const likely = settings.mode==='נרוויח'? Math.round(giftTotalLikely*(1-saveRatio))
               : settings.mode==='כיס אישי'? Math.round(giftTotalLikely*(1+saveRatio))
               : Math.round(giftTotalLikely)
  const min = Math.round(likely*0.85), max = Math.round(likely*1.15)
  const committed = suppliers.filter(s=> s.status==='התחייב')
  const committedTotal = committed.reduce((sum,s)=> sum + (s.finalAmount||0), 0)
  const committedPaid = committed.reduce((sum,s)=> sum + (s.deposit||0), 0)
  return {min, likely, max, committedTotal, committedPaid, committedRemaining: committedTotal-committedPaid}
}
