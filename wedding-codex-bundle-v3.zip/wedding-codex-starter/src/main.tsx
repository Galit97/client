import React from 'react'
import ReactDOM from 'react-dom/client'
import { createBrowserRouter, RouterProvider } from 'react-router-dom'
import './styles/globals.css'
import App from './App'
import Dashboard from './pages/Dashboard'
import BudgetOverview from './pages/BudgetOverview'
import NewBudgetWizard from './pages/NewBudgetWizard'
import Guests from './pages/Guests'
import Suppliers from './pages/Suppliers'
import Tasks from './pages/Tasks'
import Settings from './pages/Settings'

const router = createBrowserRouter([{
  path: '/', element: <App/>, children: [
    { index: true, element: <Dashboard/> },
    { path: 'budget', element: <BudgetOverview/> },
    { path: 'budget/setup', element: <NewBudgetWizard/> },
    { path: 'guests', element: <Guests/> },
    { path: 'suppliers', element: <Suppliers/> },
    { path: 'tasks', element: <Tasks/> },
    { path: 'settings', element: <Settings/> },
  ]
}])

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode><RouterProvider router={router}/></React.StrictMode>
)
