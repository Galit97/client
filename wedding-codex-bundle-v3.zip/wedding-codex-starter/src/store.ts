import { create } from 'zustand'
export type SupplierStatus = 'פתוח'|'הצעה'|'התחייב'
export interface Supplier { id:string; name:string; category:string; status:SupplierStatus; finalAmount?:number; deposit?:number }
export interface BudgetSettings { guestsMin:number; guestsMax:number; guestsExact?:number; giftAvg:number; savePercent:number; mode:'ניצמד'|'כיס אישי'|'נרוויח' }
interface AppState {
  participants:string[]; hasEventDate:boolean; budget?:BudgetSettings; suppliers:Supplier[];
  setEventDate:(v:boolean)=>void; setBudget:(b:BudgetSettings)=>void; addSupplier:(s:Supplier)=>void; updateSupplier:(id:string,patch:Partial<Supplier>)=>void
}
export const useApp = create<AppState>((set)=> ({
  participants:['אא','בג','דא'], hasEventDate:false, suppliers:[],
  setEventDate:(v)=>set({hasEventDate:v}),
  setBudget:(b)=>set({budget:b}),
  addSupplier:(s)=>set((st)=>({suppliers:[...st.suppliers,s]})),
  updateSupplier:(id,patch)=>set((st)=>({suppliers:st.suppliers.map(x=>x.id===id?{...x,...patch}:x)})),
}))
