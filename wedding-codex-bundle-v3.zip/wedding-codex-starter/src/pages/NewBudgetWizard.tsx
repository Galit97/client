import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useApp, BudgetSettings } from '../store'
export default function NewBudgetWizard(){
  const nav = useNavigate()
  const setBudget = useApp(s=> s.setBudget)
  const [data, setData] = useState<BudgetSettings>({guestsMin:150,guestsMax:300,guestsExact:undefined,giftAvg:300,savePercent:10,mode:'ניצמד'})
  const set = (patch: Partial<BudgetSettings>) => setData({...data, ...patch})
  return (
    <div className="stack">
      <header className="section-header budget">
        <h1 className="section-title">הגדרת תקציב</h1>
        <p className="section-sub">אין תצוגה חיה בשלב ההגדרה—תראו את התוצאה אחרי שמירה.</p>
      </header>
      <section className="card stack">
        <strong className="label">אורחים</strong>
        <div className="row">
          <div className="stack" style={{flex:1}}>
            <label className="label">מספר מוזמנים (מינימום)</label>
            <input className="number" type="number" min={50} max={600} step={10} value={data.guestsMin} onChange={e=> set({guestsMin: Number(e.target.value)})}/>
          </div>
          <div className="stack" style={{flex:1}}>
            <label className="label">מספר מוזמנים (מקסימום)</label>
            <input className="number" type="number" min={50} max={600} step={10} value={data.guestsMax} onChange={e=> set({guestsMax: Number(e.target.value)})}/>
          </div>
          <div className="stack" style={{flex:1}}>
            <label className="label">מספר מוזמנים (מדויק) (אופציונלי)</label>
            <input className="number" type="number" min={50} max={600} step={5} value={data.guestsExact ?? ''} onChange={e=> set({guestsExact: Number(e.target.value) || undefined})}/>
          </div>
        </div>
        <strong className="label">מתנה צפויה</strong>
        <div className="row">
          <input className="number" style={{flex:1}} type="number" min={100} max={600} step={10} value={data.giftAvg} onChange={e=> set({giftAvg: Number(e.target.value)})}/>
          <div className="row">{[200,300,400].map(v=>(<button key={v} className="btn secondary" onClick={()=> set({giftAvg: v})}>₪{v}</button>))}</div>
        </div>
        <strong className="label">יעד</strong>
        <div className="row">
          {(['ניצמד','כיס אישי','נרוויח'] as const).map(m=>(<button key={m} className={"btn "+(data.mode===m?'primary':'secondary')} onClick={()=> set({mode:m})}>{m}</button>))}
          <div className="row" style={{marginInlineStart:'auto'}}>
            <label className="label">אחוז חיסכון (%)</label>
            <input className="number" type="number" min={5} max={30} step={5} value={data.savePercent} onChange={e=> set({savePercent: Number(e.target.value)})}/>
          </div>
        </div>
      </section>
      <footer className="row" style={{justifyContent:'space-between'}}>
        <button className="btn secondary" onClick={()=> nav('/suppliers')}>לעמוד ספקים</button>
        <button className="btn primary" onClick={()=> { setBudget(data); nav('/budget'); }}>שמירה וצפייה בתקציב</button>
      </footer>
    </div>
  )
}
