import React from 'react'
import { useNavigate } from 'react-router-dom'
import { useApp } from '../store'
import { calcBudget } from '../services/budget'
import { BudgetShekelIcon } from '../components/Icons'

export default function BudgetOverview(){
  const nav = useNavigate()
  const budget = useApp(s=> s.budget)
  const suppliers = useApp(s=> s.suppliers)
  return (
    <div className="stack">
      <header className="section-header budget">
        <div className="row" style={{justifyContent:'space-between'}}>
          <div><h1 className="section-title">תקציב</h1><p className="section-sub">רק ספקים בסטטוס ‘התחייב’ ייכנסו לחישוב.</p></div>
          <button className="btn ghost" onClick={()=> nav('/budget/setup')}>עריכת התקציב</button>
        </div>
      </header>
      {!budget ? (
        <section className="card"><p className="section-sub">עדיין אין הגדרות תקציב.</p><button className="btn primary" onClick={()=> nav('/budget/setup')}>התחלה מהירה</button></section>
      ) : (
        <section className="card stack">
          <div className="row" style={{alignItems:'center',gap:12}}><BudgetShekelIcon/><strong>תמצית יעד</strong></div>
          {(() => { const s = calcBudget(budget, suppliers); return (
            <div className="grid cols-3">
              <div className="card"><div className="label">יעד מינימום</div><div>₪{s.min.toLocaleString('he-IL')}</div></div>
              <div className="card"><div className="label">יעד סביר</div><div>₪{s.likely.toLocaleString('he-IL')}</div></div>
              <div className="card"><div className="label">יעד מקסימום</div><div>₪{s.max.toLocaleString('he-IL')}</div></div>
            </div>
          )})()}
        </section>
      )}
    </div>
  )
}
