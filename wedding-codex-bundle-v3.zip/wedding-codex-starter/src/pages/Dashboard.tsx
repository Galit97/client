import React from 'react'
import { NavLink } from 'react-router-dom'
import { useApp } from '../store'
export default function Dashboard(){
  const app = useApp()
  return (
    <div className="stack">
      <header className="card">
        <div className="row" style={{justifyContent:'space-between',alignItems:'center'}}>
          <div>
            <h1 className="section-title" style={{margin:0}}>ברוכים הבאים</h1>
            <p className="section-sub" style={{margin:0}}>ניהול חתונה רגוע ושקוף</p>
          </div>
          <div className="row" style={{gap:8}}>
            {app.participants.slice(0,3).map((ini,i)=>(
              <div key={i} title={ini} style={{width:24,height:24,borderRadius:999,background:'#fff',border:'2px solid #fff',boxShadow:'0 2px 6px rgba(0,0,0,.08)',display:'grid',placeItems:'center',color:'#1E5A78',fontWeight:700}}>{ini}</div>
            ))}
            {app.participants.length>3 && (<div style={{width:24,height:24,borderRadius:999,background:'#fff',border:'1px solid #E5E7EB',display:'grid',placeItems:'center',color:'#475569',fontSize:12}}>+{app.participants.length-3}</div>)}
          </div>
        </div>
      </header>
      <section className="card">
        <div className="row" style={{justifyContent:'space-between'}}>
          <div>
            <h2 style={{margin:'0 0 4px'}}>תקציב</h2>
            <p className="section-sub" style={{margin:0}}>נגדיר טווח אורחים ויעד—ונראה הכל בשקיפות.</p>
          </div>
          <NavLink to="/budget/setup" className="btn secondary">התחלה מהירה</NavLink>
        </div>
      </section>
      <div className="grid cols-3">
        <NavLink to="/guests" className="card">מוזמנים</NavLink>
        <NavLink to="/suppliers" className="card">ספקים</NavLink>
        <NavLink to="/tasks" className="card">משימות</NavLink>
      </div>
    </div>
  )
}
