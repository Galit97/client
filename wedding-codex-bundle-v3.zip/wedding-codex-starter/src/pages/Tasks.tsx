import React from 'react'
export default function Tasks(){
  return (
    <div className="stack">
      <header className="section-header tasks"><h1 className="section-title">משימות</h1><p className="section-sub">מה נשאר לעשות.</p></header>
      <section className="card">כאן תבוא רשימת המשימות…</section>
    </div>
  )
}
