import React from 'react'
export default function Guests(){
  return (
    <div className="stack">
      <header className="section-header guests">
        <h1 className="section-title">מוזמנים</h1>
        <p className="section-sub">ניהול רשימות והזמנות.</p>
      </header>
      <section className="card">כאן יבואו רשימות המוזמנים…</section>
    </div>
  )
}
