import React from 'react'
export default function Settings(){
  return (
    <div className="stack">
      <header className="section-header" style={{background:'var(--surface-sky-50)'}}>
        <h1 className="section-title">הגדרות</h1>
        <p className="section-sub">שותפים והרשאות</p>
      </header>
      <section className="card">מסכי שיתוף והרשאות…</section>
    </div>
  )
}
