import React, { useState } from 'react'
import { useApp, Supplier } from '../store'

export default function Suppliers(){
  const suppliers = useApp(s=> s.suppliers)
  const addSupplier = useApp(s=> s.addSupplier)
  const updateSupplier = useApp(s=> s.updateSupplier)
  const [form, setForm] = useState<Partial<Supplier>>({name:'', category:'', status:'פתוח'})
  const save = ()=>{
    if(!form.name) return
    addSupplier({ id: Math.random().toString(36).slice(2), name: form.name!, category: form.category||'כללי',
      status: (form.status as any)||'פתוח', finalAmount: form.finalAmount, deposit: form.deposit })
    setForm({name:'', category:'', status:'פתוח'})
    alert(form.status==='התחייב' ? 'ספק התחייב—התווסף לתקציב' : 'ספק נשמר')
  }
  return (
    <div className="stack">
      <header className="section-header suppliers">
        <h1 className="section-title">ספקים</h1>
        <p className="section-sub">“התחייב” נכנס מיד לתקציב; “הצעה/פתוח” לא.</p>
      </header>
      <section className="card stack">
        <strong className="label">הוספת ספק</strong>
        <div className="row">
          <input className="input" placeholder="שם הספק" value={form.name||''} onChange={e=> setForm({...form, name:e.target.value})}/>
          <input className="input" placeholder="קטגוריה" value={form.category||''} onChange={e=> setForm({...form, category:e.target.value})}/>
          <select className="input" value={form.status as any} onChange={e=> setForm({...form, status: e.target.value as any})}>
            <option>פתוח</option><option>הצעה</option><option>התחייב</option>
          </select>
        </div>
        {form.status==='התחייב' && (
          <div className="row">
            <input className="number" placeholder="סכום סופי (₪)" type="number" value={form.finalAmount||''} onChange={e=> setForm({...form, finalAmount: Number(e.target.value)})}/>
            <input className="number" placeholder="מקדמה ששולמה (₪)" type="number" value={form.deposit||''} onChange={e=> setForm({...form, deposit: Number(e.target.value)})}/>
          </div>
        )}
        <div className="row" style={{justifyContent:'flex-end'}}><button className="btn primary" onClick={save}>שמירה</button></div>
      </section>
      <section className="card stack">
        <strong className="label">רשימת ספקים</strong>
        <div className="stack">
          {suppliers.map(s=> (
            <div key={s.id} className="row" style={{justifyContent:'space-between',borderBottom:'1px solid #E5E7EB',paddingBlock:8}}>
              <div className="row" style={{gap:8}}><span style={{fontWeight:600}}>{s.name}</span><span className="label">({s.category})</span></div>
              <div className="row" style={{gap:8,alignItems:'center'}}>
                <span className="label">{s.status}</span>
                {s.status!=='התחייב' && (<button className="btn secondary" onClick={()=> updateSupplier(s.id, {status:'התחייב'})}>סמן כהתחייב</button>)}
              </div>
            </div>
          ))}
          {suppliers.length===0 && <div className="section-sub">עוד אין ספקים…</div>}
        </div>
      </section>
    </div>
  )
}
