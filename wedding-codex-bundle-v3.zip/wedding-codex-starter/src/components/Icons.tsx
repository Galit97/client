import React from 'react'
export const BudgetShekelIcon = () => (
  <svg viewBox="0 0 24 24" className="icon" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="12" r="9.2" />
    <path d="M8.5 8.2v5.6c0 1.3 1 2.3 2.3 2.3h2.7" />
    <path d="M15.5 15.8V10.2c0-1.3-1-2.3-2.3-2.3H10.5" />
    <g opacity=".5"><path d="M16.5 6.8l1.8-1.8" /><path d="M18.3 6.8l-1.8-1.8" /></g>
  </svg>
)
export const InviteRSVPIcon = () => (
  <svg viewBox="0 0 24 24" className="icon" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round">
    <rect x="3.5" y="6.5" width="17" height="11" rx="2"/>
    <path d="M4 8l8 5 8-5" />
    <circle cx="17.5" cy="15.5" r="2.2" />
    <path d="M16.6 15.5l.9.9 1.7-1.7" />
  </svg>
)
