import React from 'react'
import { Outlet, NavLink, useNavigate } from 'react-router-dom'
import { BudgetShekelIcon, InviteRSVPIcon } from './components/Icons'

export default function App(){
  const nav = useNavigate()
  return (
    <div className="container" style={{display:'grid',gridTemplateRows:'auto 1fr auto',minHeight:'100dvh'}}>
      <header className="section-header" style={{background:'transparent',borderBottom:'none',padding:'16px 0'}}>
        <div className="row" style={{justifyContent:'space-between'}}>
          <strong>מתחתנים</strong>
          <nav className="row" style={{gap:8}}>
            <button className="btn secondary" aria-label="חזרה" onClick={()=>nav(-1)}>⬅︎ חזרה</button>
            <a className="btn ghost" href="/settings">שיתוף</a>
          </nav>
        </div>
      </header>
      <main style={{paddingBlock:16}}><Outlet/></main>
      <div className="bottom-nav">
        <NavLink to="/" className={({isActive})=>isActive?'active':undefined}>בית</NavLink>
        <NavLink to="/budget" className={({isActive})=>isActive?'active':undefined}><BudgetShekelIcon/></NavLink>
        <NavLink to="/guests" className={({isActive})=>isActive?'active':undefined}><InviteRSVPIcon/></NavLink>
        <NavLink to="/suppliers" className={({isActive})=>isActive?'active':undefined}>ספקים</NavLink>
        <NavLink to="/tasks" className={({isActive})=>isActive?'active':undefined}>משימות</NavLink>
        <NavLink to="/settings" className={({isActive})=>isActive?'active':undefined}>הגדרות</NavLink>
      </div>
    </div>
  )
}
