
  # מתחתנים ניסוי 3

  This is a code bundle for מתחתנים ניסוי 3. The original project is available at https://www.figma.com/design/ed7bygkaQ0U2rSVaiU8x0t/%D7%9E%D7%AA%D7%97%D7%AA%D7%A0%D7%99%D7%9D-%D7%A0%D7%99%D7%A1%D7%95%D7%99-3.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  