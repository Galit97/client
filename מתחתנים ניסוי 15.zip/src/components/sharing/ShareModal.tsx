import React, { useState } from 'react';
import { X, Wrench, Eye } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '../ui/dialog';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Switch } from '../ui/switch';
import { SegmentedControl } from './SegmentedControl';
import { CopyRow } from './CopyRow';
import { MemberListItem, Role } from './MemberListItem';

interface ShareModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  defaultTab?: string;
}

export const ShareModal: React.FC<ShareModalProps> = ({ 
  open, 
  onOpenChange,
  defaultTab = 'link'
}) => {
  const [activeTab, setActiveTab] = useState(defaultTab);
  const [selectedRole, setSelectedRole] = useState<Role>('Partner');
  const [selectedScope, setSelectedScope] = useState('full');
  const [expiry, setExpiry] = useState('7days');
  const [pin, setPin] = useState('');
  const [restrictDevice, setRestrictDevice] = useState(false);
  const [email, setEmail] = useState('');
  const [generatedLink, setGeneratedLink] = useState('');

  const tabs = [
    { id: 'link', label: 'שתפו קישור' },
    { id: 'email', label: 'הזמנה במייל' },
    { id: 'members', label: 'חברים והרשאות' }
  ];

  const roles = [
    { id: 'Partner', label: 'שותף/ה' },
    { id: 'Planner', label: 'מנהל/ת אירוע' },
    { id: 'Viewer', label: 'צפייה' }
  ];

  const scopes = [
    { id: 'full', label: 'כל האפליקציה' },
    { id: 'suppliers-tasks', label: 'ספקים + משימות בלבד (ללא מתנות/תקציב)' },
    { id: 'guests-only', label: 'מוזמנים בלבד (RSVP וסידור ישיבה)' }
  ];

  const expiryOptions = [
    { id: '7days', label: '7 ימים (ברירת מחדל)' },
    { id: '24hours', label: '24 שעות' },
    { id: 'never', label: 'לעולם לא' }
  ];

  const generateLink = () => {
    const linkId = Math.random().toString(36).substring(2, 8);
    setGeneratedLink(`https://app.wedding.co.il/invite/${linkId}`);
  };

  const sendEmailInvite = () => {
    // Mock email send
    console.log('Sending email invite to:', email);
  };

  const mockMembers = [
    { name: 'placeholder', role: 'Owner' as Role, initials: 'אא' }
  ];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="w-full max-w-2xl p-0 overflow-hidden" dir="rtl">
        <DialogHeader className="p-6 pb-4 border-b">
          <DialogTitle className="text-right">שיתוף</DialogTitle>
        </DialogHeader>
        
        <div className="p-6">
          <SegmentedControl
            options={tabs}
            value={activeTab}
            onChange={setActiveTab}
            className="mb-6"
          />

          {activeTab === 'link' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-medium mb-4" style={{ color: 'var(--text-primary)' }}>
                  שיתוף מהיר בקישור
                </h3>
              </div>

              <div>
                <Label className="block mb-3">תפקיד</Label>
                <div className="space-y-2">
                  {roles.map((role) => (
                    <label key={role.id} className="flex items-center gap-3 cursor-pointer">
                      <input
                        type="radio"
                        name="role"
                        value={role.id}
                        checked={selectedRole === role.id}
                        onChange={(e) => setSelectedRole(e.target.value as Role)}
                        className="w-4 h-4 text-brand-primary border-gray-300 focus:ring-brand-primary focus:ring-2"
                      />
                      <span className="flex items-center gap-2">
                        {role.id === 'Planner' && <Wrench size={16} style={{ color: 'var(--text-secondary)' }} />}
                        {role.id === 'Viewer' && <Eye size={16} style={{ color: 'var(--text-secondary)' }} />}
                        {role.label}
                      </span>
                    </label>
                  ))}
                </div>
              </div>

              <div>
                <Label className="block mb-3">טווח גישה</Label>
                <div className="space-y-2">
                  {scopes.map((scope) => (
                    <label key={scope.id} className="flex items-center gap-3 cursor-pointer">
                      <input
                        type="radio"
                        name="scope"
                        value={scope.id}
                        checked={selectedScope === scope.id}
                        onChange={(e) => setSelectedScope(e.target.value)}
                        className="w-4 h-4 text-brand-primary border-gray-300 focus:ring-brand-primary focus:ring-2"
                      />
                      <span>{scope.label}</span>
                    </label>
                  ))}
                </div>
              </div>

              <div className="border-t pt-4">
                <h4 className="font-medium mb-3" style={{ color: 'var(--text-primary)' }}>אבטחה</h4>
                <div className="space-y-4">
                  <div>
                    <Label className="block mb-2">תוקף</Label>
                    <select
                      value={expiry}
                      onChange={(e) => setExpiry(e.target.value)}
                      className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-brand-primary"
                      dir="rtl"
                    >
                      {expiryOptions.map((option) => (
                        <option key={option.id} value={option.id}>
                          {option.label}
                        </option>
                      ))}
                    </select>
                  </div>
                  
                  <div>
                    <Label className="block mb-2">PIN (אופציונלי)</Label>
                    <Input
                      type="text"
                      value={pin}
                      onChange={(e) => setPin(e.target.value)}
                      placeholder="6 ספרות"
                      maxLength={6}
                      className="text-right"
                      dir="rtl"
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label>הגבל למכשיר הראשון בלבד</Label>
                    <Switch
                      checked={restrictDevice}
                      onCheckedChange={setRestrictDevice}
                    />
                  </div>
                </div>
              </div>

              {generatedLink && (
                <div>
                  <Label className="block mb-2">קישור שנוצר</Label>
                  <CopyRow value={generatedLink} placeholder="https://app/…/invite/•••" />
                </div>
              )}

              <div className="flex gap-3 pt-4" dir="rtl">
                <Button onClick={generateLink} className="btn-primary">
                  יצירת קישור
                </Button>
                {generatedLink && (
                  <>
                    <Button variant="outline">
                      העתקה
                    </Button>
                    <Button variant="ghost">
                      שיתוף ב-WhatsApp
                    </Button>
                  </>
                )}
              </div>

              <p className="text-sm mt-4" style={{ color: 'var(--text-muted)' }}>
                מוזמנים יצטרפו עם ההרשאות שבחרתם. אפשר לשנות או לבטל כל קישור בכל רגע.
              </p>
            </div>
          )}

          {activeTab === 'email' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-medium mb-4" style={{ color: 'var(--text-primary)' }}>
                  שליחת הזמנה במייל
                </h3>
              </div>

              <div>
                <Label className="block mb-2">אימייל של המוזמן/ת</Label>
                <Input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="הזינו כתובת אימייל"
                  className="text-right"
                  dir="rtl"
                />
              </div>

              <div>
                <Label className="block mb-3">תפקיד</Label>
                <div className="space-y-2">
                  {roles.map((role) => (
                    <label key={role.id} className="flex items-center gap-3 cursor-pointer">
                      <input
                        type="radio"
                        name="email-role"
                        value={role.id}
                        checked={selectedRole === role.id}
                        onChange={(e) => setSelectedRole(e.target.value as Role)}
                        className="w-4 h-4 text-brand-primary border-gray-300 focus:ring-brand-primary focus:ring-2"
                      />
                      <span className="flex items-center gap-2">
                        {role.id === 'Planner' && <Wrench size={16} style={{ color: 'var(--text-secondary)' }} />}
                        {role.id === 'Viewer' && <Eye size={16} style={{ color: 'var(--text-secondary)' }} />}
                        {role.label}
                      </span>
                    </label>
                  ))}
                </div>
              </div>

              <div>
                <Label className="block mb-3">טווח גישה</Label>
                <div className="space-y-2">
                  {scopes.map((scope) => (
                    <label key={scope.id} className="flex items-center gap-3 cursor-pointer">
                      <input
                        type="radio"
                        name="email-scope"
                        value={scope.id}
                        checked={selectedScope === scope.id}
                        onChange={(e) => setSelectedScope(e.target.value)}
                        className="w-4 h-4 text-brand-primary border-gray-300 focus:ring-brand-primary focus:ring-2"
                      />
                      <span>{scope.label}</span>
                    </label>
                  ))}
                </div>
              </div>

              <Button onClick={sendEmailInvite} className="btn-primary">
                שליחה
              </Button>
            </div>
          )}

          {activeTab === 'members' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-medium mb-4" style={{ color: 'var(--text-primary)' }}>
                  חברים והרשאות
                </h3>
              </div>

              {mockMembers.length === 0 ? (
                <div className="text-center py-8">
                  <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-gray-100 flex items-center justify-center">
                    <svg className="w-8 h-8" style={{ color: 'var(--text-muted)' }} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197m13.5-9a2.25 2.25 0 11-4.5 0 2.25 2.25 0 014.5 0z" />
                    </svg>
                  </div>
                  <p className="text-lg mb-2" style={{ color: 'var(--text-primary)' }}>
                    עדיין אין מצטרפים
                  </p>
                  <p className="mb-4" style={{ color: 'var(--text-secondary)' }}>
                    רוצים לשתף קישור?
                  </p>
                  <Button variant="outline" onClick={() => setActiveTab('link')}>
                    יצירת קישור
                  </Button>
                </div>
              ) : (
                <div className="space-y-2">
                  {mockMembers.map((member, index) => (
                    <MemberListItem
                      key={index}
                      name={member.name}
                      role={member.role}
                      initials={member.initials}
                    />
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};