import React from 'react';
import { CheckCircle, Info, AlertCircle } from 'lucide-react';
import { Button } from '../ui/button';
import { RoleBadge, Role } from './RoleBadge';

interface JoinLandingProps {
  coupleName?: string;
  role: Role;
  permissions: {
    view: string[];
    edit: string[];
    hidden: string[];
  };
  onJoin: () => void;
}

export const JoinLanding: React.FC<JoinLandingProps> = ({
  coupleName = "זוג החתן והכלה",
  role,
  permissions,
  onJoin
}) => {
  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4" dir="rtl">
      <div className="max-w-md w-full bg-white rounded-lg shadow-lg p-8">
        <div className="text-center mb-6">
          <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-blue-100 flex items-center justify-center">
            <svg className="w-8 h-8 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197m13.5-9a2.25 2.25 0 11-4.5 0 2.25 2.25 0 014.5 0z" />
            </svg>
          </div>
          
          <h1 className="text-2xl font-semibold mb-2" style={{ color: 'var(--text-primary)' }}>
            הוזמנת להצטרף לאירוע של {coupleName}
          </h1>
          
          <div className="flex justify-center mb-4">
            <RoleBadge role={role} />
          </div>
        </div>

        <div className="space-y-4 mb-6">
          <div>
            <h3 className="font-medium mb-2" style={{ color: 'var(--text-primary)' }}>
              טווח הגישה שלכם:
            </h3>
            
            {permissions.view.length > 0 && (
              <div className="flex items-start gap-2 mb-2">
                <Info className="w-4 h-4 mt-0.5 text-blue-500 flex-shrink-0" />
                <div>
                  <span className="font-medium text-sm">תוכלו לראות: </span>
                  <span className="text-sm" style={{ color: 'var(--text-secondary)' }}>
                    {permissions.view.join(', ')}
                  </span>
                </div>
              </div>
            )}

            {permissions.edit.length > 0 && (
              <div className="flex items-start gap-2 mb-2">
                <CheckCircle className="w-4 h-4 mt-0.5 text-green-500 flex-shrink-0" />
                <div>
                  <span className="font-medium text-sm">תוכלו לערוך: </span>
                  <span className="text-sm" style={{ color: 'var(--text-secondary)' }}>
                    {permissions.edit.join(', ')}
                  </span>
                </div>
              </div>
            )}

            {permissions.hidden.length > 0 && (
              <div className="flex items-start gap-2">
                <AlertCircle className="w-4 h-4 mt-0.5 text-orange-500 flex-shrink-0" />
                <div>
                  <span className="font-medium text-sm">לא תוכלו לראות: </span>
                  <span className="text-sm" style={{ color: 'var(--text-secondary)' }}>
                    {permissions.hidden.join(', ')}
                  </span>
                </div>
              </div>
            )}
          </div>
        </div>

        <Button onClick={onJoin} className="btn-primary w-full mb-4">
          הצטרפות עם Apple/Google/מייל
        </Button>

        <p className="text-xs text-center" style={{ color: 'var(--text-muted)' }}>
          בכל רגע אפשר להסיר גישה. אין שיתוף נתוני תשלום ללא אישור מפורש.
        </p>
      </div>
    </div>
  );
};