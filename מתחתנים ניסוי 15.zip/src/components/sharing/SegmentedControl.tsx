import React from 'react';

interface SegmentedControlOption {
  id: string;
  label: string;
}

interface SegmentedControlProps {
  options: SegmentedControlOption[];
  value: string;
  onChange: (value: string) => void;
  className?: string;
}

export const SegmentedControl: React.FC<SegmentedControlProps> = ({
  options,
  value,
  onChange,
  className = ""
}) => {
  return (
    <div className={`inline-flex bg-gray-100 rounded-lg p-1 ${className}`} dir="rtl">
      {options.map((option) => (
        <button
          key={option.id}
          onClick={() => onChange(option.id)}
          className={`
            px-4 py-2 rounded-md text-sm font-medium transition-all duration-200
            ${value === option.id 
              ? 'chip-selected' 
              : 'chip-unselected hover:bg-white'
            }
          `}
        >
          {option.label}
        </button>
      ))}
    </div>
  );
};