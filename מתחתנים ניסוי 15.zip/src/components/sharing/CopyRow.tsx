import React, { useState } from 'react';
import { Copy, Check } from 'lucide-react';
import { Input } from '../ui/input';
import { Button } from '../ui/button';

interface CopyRowProps {
  value: string;
  placeholder?: string;
  readOnly?: boolean;
}

export const CopyRow: React.FC<CopyRowProps> = ({ 
  value, 
  placeholder = "",
  readOnly = true 
}) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(value);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  return (
    <div className="flex gap-2" dir="rtl">
      <Input 
        value={value}
        placeholder={placeholder}
        readOnly={readOnly}
        className="flex-1 text-right"
        dir="rtl"
      />
      <Button
        type="button"
        variant="ghost"
        onClick={handleCopy}
        className="px-3"
      >
        {copied ? <Check size={16} /> : <Copy size={16} />}
        <span className="mr-1">{copied ? 'הועתק!' : 'העתקה'}</span>
      </Button>
    </div>
  );
};