import React, { useState } from 'react';
import { Copy, Trash2, Calendar, Link, Mail } from 'lucide-react';
import { Button } from '../ui/button';
import { MemberListItem, Role } from './MemberListItem';

interface MembersPermissionsSettingsProps {
  onBack: () => void;
}

export const MembersPermissionsSettings: React.FC<MembersPermissionsSettingsProps> = ({ onBack }) => {
  const [activeInvites] = useState([
    {
      id: '1',
      label: 'קישור לשותף/ה',
      role: 'Partner' as Role,
      scope: 'כל האפליקציה',
      expiry: '7 ימים',
      link: 'https://app.wedding.co.il/invite/abc123'
    },
    {
      id: '2', 
      label: 'קישור למנהל/ת אירוע',
      role: 'Planner' as Role,
      scope: 'ספקים + משימות בלבד',
      expiry: '24 שעות',
      link: 'https://app.wedding.co.il/invite/def456'
    }
  ]);

  const [teamMembers] = useState([
    {
      name: 'placeholder',
      role: 'Owner' as Role,
      initials: 'אא'
    }
  ]);

  const [recentActivity] = useState([
    {
      id: '1',
      action: 'עודכנה הצעה לספק צילום',
      timestamp: 'לפני שעתיים',
      user: 'placeholder'
    },
    {
      id: '2', 
      action: 'נוספה מקדמה לאולם',
      timestamp: 'לפני 4 שעות',
      user: 'מנהל/ת אירוע'
    },
    {
      id: '3',
      action: 'עודכן RSVP לאורח',
      timestamp: 'לפני יום',
      user: 'שותף/ה'
    }
  ]);

  const copyLink = async (link: string) => {
    try {
      await navigator.clipboard.writeText(link);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50" dir="rtl">
      {/* Header */}
      <div className="section-header-dashboard">
        <div className="flex items-center justify-between min-h-[88px] px-4 relative z-10">
          <Button 
            variant="ghost" 
            onClick={onBack}
            className="hero-text-secondary"
          >
            ← חזרה
          </Button>
          <div className="text-center relative">
            <h1 className="section-title hero-text mb-2">שותפים והרשאות</h1>
          </div>
          <div></div>
        </div>
      </div>

      <div className="p-6 space-y-8">
        {/* Active Invites */}
        <section>
          <h2 className="text-lg font-semibold mb-4" style={{ color: 'var(--text-primary)' }}>
            הזמנות פעילות
          </h2>
          
          {activeInvites.length === 0 ? (
            <div className="card p-6 text-center">
              <p style={{ color: 'var(--text-secondary)' }}>אין הזמנות פעילות כרגע</p>
            </div>
          ) : (
            <div className="card">
              <div className="overflow-hidden">
                <table className="w-full">
                  <thead>
                    <tr className="table-header border-b">
                      <th className="text-right p-4">תווית קישור</th>
                      <th className="text-right p-4">תפקיד</th>
                      <th className="text-right p-4">טווח גישה</th>
                      <th className="text-right p-4">פוקע</th>
                      <th className="text-right p-4">פעולות</th>
                    </tr>
                  </thead>
                  <tbody>
                    {activeInvites.map((invite) => (
                      <tr key={invite.id} className="table-row table-divider">
                        <td className="p-4">
                          <div className="flex items-center gap-2">
                            <Link size={16} style={{ color: 'var(--text-muted)' }} />
                            <span>{invite.label}</span>
                          </div>
                        </td>
                        <td className="p-4">
                          <span className="badge-info-subtle px-2 py-1 rounded text-xs">
                            {invite.role === 'Partner' ? 'שותף/ה' : 
                             invite.role === 'Planner' ? 'מנהל/ת אירוע' : 'צופה'}
                          </span>
                        </td>
                        <td className="p-4">
                          <span style={{ color: 'var(--text-secondary)' }}>{invite.scope}</span>
                        </td>
                        <td className="p-4">
                          <div className="flex items-center gap-1">
                            <Calendar size={14} style={{ color: 'var(--text-muted)' }} />
                            <span style={{ color: 'var(--text-secondary)' }}>{invite.expiry}</span>
                          </div>
                        </td>
                        <td className="p-4">
                          <div className="flex gap-2">
                            <Button 
                              variant="ghost" 
                              size="sm"
                              onClick={() => copyLink(invite.link)}
                            >
                              <Copy size={14} />
                              העתקה
                            </Button>
                            <Button variant="ghost" size="sm" className="text-red-600">
                              <Trash2 size={14} />
                              ביטול
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </section>

        {/* Team Members */}
        <section>
          <h2 className="text-lg font-semibold mb-4" style={{ color: 'var(--text-primary)' }}>
            חברי צוות
          </h2>
          
          <div className="card">
            {teamMembers.length === 0 ? (
              <div className="p-6 text-center">
                <p style={{ color: 'var(--text-secondary)' }}>אין חברי צוות נוספים כרגע</p>
              </div>
            ) : (
              <div className="p-4">
                {teamMembers.map((member, index) => (
                  <MemberListItem
                    key={index}
                    name={member.name}
                    role={member.role}
                    initials={member.initials}
                  />
                ))}
              </div>
            )}
          </div>
        </section>

        {/* Recent Activity */}
        <section>
          <h2 className="text-lg font-semibold mb-4" style={{ color: 'var(--text-primary)' }}>
            פעילויות אחרונות
          </h2>
          
          <div className="card">
            {recentActivity.length === 0 ? (
              <div className="p-6 text-center">
                <p style={{ color: 'var(--text-secondary)' }}>אין פעילויות אחרונות</p>
              </div>
            ) : (
              <div className="p-4 space-y-3">
                {recentActivity.map((activity) => (
                  <div key={activity.id} className="flex items-start justify-between py-2">
                    <div className="flex-1">
                      <p style={{ color: 'var(--text-primary)' }}>{activity.action}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-sm" style={{ color: 'var(--text-muted)' }}>
                          {activity.user}
                        </span>
                        <span className="text-sm" style={{ color: 'var(--text-muted)' }}>•</span>
                        <span className="text-sm" style={{ color: 'var(--text-muted)' }}>
                          {activity.timestamp}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </section>
      </div>
    </div>
  );
};