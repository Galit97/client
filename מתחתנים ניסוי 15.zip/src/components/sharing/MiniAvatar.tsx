import React from 'react';

interface MiniAvatarProps {
  initials?: string;
  className?: string;
}

export const MiniAvatar: React.FC<MiniAvatarProps> = ({ 
  initials = "אא", 
  className = "" 
}) => {
  return (
    <div className={`
      w-6 h-6 rounded-full flex items-center justify-center
      bg-gray-100 text-xs font-medium
      ${className}
    `} style={{ 
      color: 'var(--text-primary)',
      backgroundColor: 'var(--surface-sky-50)'
    }}>
      {initials}
    </div>
  );
};