import React from 'react';
import { Eye, Wrench } from 'lucide-react';

export type Role = 'Owner' | 'Partner' | 'Planner' | 'Viewer';

interface RoleBadgeProps {
  role: Role;
  className?: string;
}

export const RoleBadge: React.FC<RoleBadgeProps> = ({ role, className = "" }) => {
  const getRoleConfig = (role: Role) => {
    switch (role) {
      case 'Owner':
        return { label: 'בעל/ת', icon: null };
      case 'Partner':
        return { label: 'שותף/ה', icon: null };
      case 'Planner':
        return { label: 'מנהל/ת אירוע', icon: <Wrench size={12} /> };
      case 'Viewer':
        return { label: 'צופה', icon: <Eye size={12} /> };
      default:
        return { label: role, icon: null };
    }
  };

  const config = getRoleConfig(role);

  return (
    <div className={`
      inline-flex items-center gap-1 px-2 py-1 rounded-md text-xs
      border border-subtle bg-white
      ${className}
    `} style={{ color: 'var(--text-primary)' }} dir="rtl">
      {config.icon}
      <span>{config.label}</span>
    </div>
  );
};