import React from 'react';
import { MoreHorizontal } from 'lucide-react';
import { MiniAvatar } from './MiniAvatar';
import { RoleBadge, Role } from './RoleBadge';

interface MemberListItemProps {
  name: string;
  role: Role;
  initials?: string;
  onMenuClick?: () => void;
}

export const MemberListItem: React.FC<MemberListItemProps> = ({
  name,
  role,
  initials,
  onMenuClick
}) => {
  return (
    <div className="flex items-center justify-between p-3 hover:bg-gray-50 rounded-lg transition-colors" dir="rtl">
      <div className="flex items-center gap-3">
        <MiniAvatar initials={initials} />
        <div className="flex flex-col">
          <span className="text-sm font-medium" style={{ color: 'var(--text-primary)' }}>
            {name}
          </span>
        </div>
        <RoleBadge role={role} />
      </div>
      <button 
        onClick={onMenuClick}
        className="p-1 hover:bg-gray-100 rounded transition-colors"
      >
        <MoreHorizontal size={16} style={{ color: 'var(--text-secondary)' }} />
      </button>
    </div>
  );
};