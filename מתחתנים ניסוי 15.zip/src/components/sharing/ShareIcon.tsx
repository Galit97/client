import React from 'react';

interface ShareIconProps {
  className?: string;
  size?: number;
}

export const ShareIcon: React.FC<ShareIconProps> = ({ 
  className = "", 
  size = 20 
}) => {
  return (
    <svg 
      width={size} 
      height={size} 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth={1.75} 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      className={className}
    >
      <circle cx="18" cy="5" r="3"/>
      <circle cx="6" cy="12" r="3"/>
      <circle cx="18" cy="19" r="3"/>
      <path d="m8.59 13.51 6.83 3.98"/>
      <path d="m15.41 6.51-6.82 3.98"/>
    </svg>
  );
};