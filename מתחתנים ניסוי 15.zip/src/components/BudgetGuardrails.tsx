import { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Slider } from './ui/slider';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Separator } from './ui/separator';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { 
  ArrowRight, 
  ArrowLeft, 
  Target, 
  CheckCircle,
  Edit,
  Plus,
  AlertTriangle,
  Info
} from 'lucide-react';
import { toast } from 'sonner';

interface BudgetCategory {
  id: string;
  name: string;
  percentage: number;
  amount: number;
  editable?: boolean;
}

interface BudgetGuardrailsProps {
  onComplete: (budgetData: any) => void;
  onSignInRequired?: () => void;
  isDemoMode?: boolean;
}

// Fixed category split that sums to 100%
const DEFAULT_CATEGORIES = [
  { id: '1', name: 'אולם וקייטרינג', percentage: 50, editable: true },
  { id: '2', name: 'צילום ווידאו', percentage: 10, editable: true },
  { id: '3', name: 'מוזיקה/DJ', percentage: 8, editable: true },
  { id: '4', name: 'פרחים ועיצוב', percentage: 6, editable: true },
  { id: '5', name: 'שמלה וחליפה', percentage: 6, editable: true },
  { id: '6', name: 'טבעות', percentage: 2, editable: true },
  { id: '7', name: 'רב/חופה', percentage: 1, editable: true },
  { id: '8', name: 'הדפסה', percentage: 2, editable: true },
  { id: '9', name: 'כרית ביטחון/שונות', percentage: 15, editable: false }, // Buffer
];

export function BudgetGuardrails({ onComplete, onSignInRequired, isDemoMode = false }: BudgetGuardrailsProps) {
  const [currentStep, setCurrentStep] = useState(1);
  const [budgetRange, setBudgetRange] = useState([120000, 180000]);
  const [budgetMode, setBudgetMode] = useState<'lean' | 'balanced' | 'stretch'>('balanced');
  const [categories, setCategories] = useState<BudgetCategory[]>([]);
  const [customCategories, setCustomCategories] = useState<BudgetCategory[]>([]);

  const totalSteps = 3;
  const progress = (currentStep / totalSteps) * 100;

  // Calculate target based on range and mode
  const getTargetAmount = () => {
    switch (budgetMode) {
      case 'lean':
        return budgetRange[0];
      case 'stretch':
        return budgetRange[1];
      case 'balanced':
      default:
        return Math.round((budgetRange[0] + budgetRange[1]) / 2);
    }
  };

  // Initialize categories when range or mode changes
  useEffect(() => {
    const target = getTargetAmount();
    const initialCategories = DEFAULT_CATEGORIES.map(cat => ({
      ...cat,
      amount: Math.round((target * cat.percentage) / 100),
    }));
    setCategories(initialCategories);
  }, [budgetRange, budgetMode]);

  const formatNumber = (num: number): string => {
    return new Intl.NumberFormat('he-IL').format(num);
  };

  const handleNext = () => {
    if (currentStep < totalSteps) {
      setCurrentStep(currentStep + 1);
    } else {
      // Save logic
      if (isDemoMode && onSignInRequired) {
        onSignInRequired();
      } else {
        const budgetData = {
          range: budgetRange,
          mode: budgetMode,
          target: getTargetAmount(),
          categories: [...categories, ...customCategories],
        };
        onComplete(budgetData);
      }
    }
  };

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const updateCategoryAmount = (id: string, newAmount: number) => {
    setCategories(prev => prev.map(cat => 
      cat.id === id ? { ...cat, amount: newAmount } : cat
    ));
  };

  const resetToDefaults = () => {
    const target = getTargetAmount();
    const resetCategories = DEFAULT_CATEGORIES.map(cat => ({
      ...cat,
      amount: Math.round((target * cat.percentage) / 100),
    }));
    setCategories(resetCategories);
    setCustomCategories([]);
    toast.success('חזרנו להמלצה המקורית');
  };

  const addCustomCategory = () => {
    const bufferCategory = categories.find(cat => cat.id === '9');
    if (!bufferCategory || bufferCategory.amount < bufferCategory.amount * 0.05) {
      toast.warning('מומלץ להשאיר כרית ביטחון של לפחות 5%');
      return;
    }

    const newCategoryAmount = Math.round(bufferCategory.amount * 0.02); // Take 2% from buffer
    const newCategory: BudgetCategory = {
      id: `custom-${Date.now()}`,
      name: 'קטגוריה חדשה',
      percentage: 2,
      amount: newCategoryAmount,
      editable: true,
    };

    // Reduce buffer by the new category amount
    setCategories(prev => prev.map(cat =>
      cat.id === '9' ? { ...cat, amount: cat.amount - newCategoryAmount } : cat
    ));
    setCustomCategories(prev => [...prev, newCategory]);
  };

  const removeCustomCategory = (id: string) => {
    const categoryToRemove = customCategories.find(cat => cat.id === id);
    if (categoryToRemove) {
      // Return amount to buffer
      setCategories(prev => prev.map(cat =>
        cat.id === '9' ? { ...cat, amount: cat.amount + categoryToRemove.amount } : cat
      ));
      setCustomCategories(prev => prev.filter(cat => cat.id !== id));
    }
  };

  const renderStep = () => {
    switch (currentStep) {
      case 1:
        return (
          <div className="space-y-6">
            <div className="text-center space-y-2">
              <Target className="w-12 h-12 text-primary mx-auto mb-4" />
              <h2>טווח תקציב</h2>
              <p className="text-muted-foreground">
                מה הטווח התקציבי שמתאים לכם?
              </p>
            </div>

            <div className="space-y-6">
              {/* Range Slider */}
              <div>
                <Label>טווח תקציב (₪)</Label>
                <div className="mt-4 px-3">
                  <Slider
                    value={budgetRange}
                    onValueChange={setBudgetRange}
                    min={30000}
                    max={500000}
                    step={5000}
                    className="range-slider"
                  />
                  <div className="flex justify-between text-xs text-muted-foreground mt-2">
                    <span>₪30,000</span>
                    <span>₪500,000</span>
                  </div>
                </div>
                
                <div className="mt-4 text-center p-4 bg-secondary/20 rounded-lg">
                  <p className="font-medium">
                    בחרתם: ₪{formatNumber(budgetRange[0])}–{formatNumber(budgetRange[1])}
                  </p>
                </div>
              </div>

              {/* Budget Mode Selection */}
              <div>
                <Label>בחרו גישה</Label>
                <RadioGroup 
                  value={budgetMode} 
                  onValueChange={(value: 'lean' | 'balanced' | 'stretch') => setBudgetMode(value)}
                  className="mt-4 space-y-3"
                >
                  <div className="flex items-center space-x-3 space-x-reverse p-4 border rounded-lg hover:bg-secondary/20 transition-colors">
                    <RadioGroupItem 
                      value="lean" 
                      id="lean"
                      className="focus:ring-2 focus:ring-primary"
                    />
                    <Label htmlFor="lean" className="flex-1 cursor-pointer">
                      <div className="font-medium">Lean (רזה)</div>
                      <div className="text-sm text-muted-foreground">
                        תקציב חסכני - ₪{formatNumber(budgetRange[0])}
                      </div>
                    </Label>
                  </div>
                  
                  <div className="flex items-center space-x-3 space-x-reverse p-4 border rounded-lg hover:bg-secondary/20 transition-colors">
                    <RadioGroupItem 
                      value="balanced" 
                      id="balanced"
                      className="focus:ring-2 focus:ring-primary"
                    />
                    <Label htmlFor="balanced" className="flex-1 cursor-pointer">
                      <div className="font-medium">Balanced (מאוזן)</div>
                      <div className="text-sm text-muted-foreground">
                        תקציב מאוזן - ₪{formatNumber(Math.round((budgetRange[0] + budgetRange[1]) / 2))}
                      </div>
                    </Label>
                  </div>
                  
                  <div className="flex items-center space-x-3 space-x-reverse p-4 border rounded-lg hover:bg-secondary/20 transition-colors">
                    <RadioGroupItem 
                      value="stretch" 
                      id="stretch"
                      className="focus:ring-2 focus:ring-primary"
                    />
                    <Label htmlFor="stretch" className="flex-1 cursor-pointer">
                      <div className="font-medium">Stretch (משודרג)</div>
                      <div className="text-sm text-muted-foreground">
                        תקציב מורחב - ₪{formatNumber(budgetRange[1])}
                      </div>
                    </Label>
                  </div>
                </RadioGroup>
              </div>

              {/* Target Display */}
              <div className="p-4 bg-primary/5 border border-primary/20 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <Target className="w-4 h-4 text-primary" />
                  <span className="font-medium text-primary">היעד הנוכחי:</span>
                </div>
                <div className="text-2xl font-bold text-primary">
                  ₪{formatNumber(getTargetAmount())}
                </div>
              </div>
            </div>
          </div>
        );

      case 2:
        const totalAmount = categories.reduce((sum, cat) => sum + cat.amount, 0) + 
                           customCategories.reduce((sum, cat) => sum + cat.amount, 0);
        
        return (
          <div className="space-y-6">
            <div className="text-center space-y-2">
              <CheckCircle className="w-12 h-12 text-primary mx-auto mb-4" />
              <h2>תוכנית אוטומטית</h2>
              <p className="text-muted-foreground">
                חלוקה מומלצת לפי ₪{formatNumber(getTargetAmount())}
              </p>
            </div>

            <div className="space-y-4">
              {/* Action Buttons */}
              <div className="flex gap-3">
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={resetToDefaults}
                  className="focus:ring-2 focus:ring-primary"
                >
                  חזרה להמלצה
                </Button>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={addCustomCategory}
                  className="focus:ring-2 focus:ring-primary"
                >
                  <Plus className="w-4 h-4 ml-2" />
                  הוסף קטגוריה
                </Button>
              </div>

              {/* Categories List */}
              <div className="space-y-3">
                {categories.map((category) => (
                  <Card key={category.id} className="hover:bg-secondary/20 transition-colors">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <h4 className="font-medium">{category.name}</h4>
                          <p className="text-sm text-muted-foreground">
                            {category.percentage.toFixed(0)}% מהתקציב
                          </p>
                        </div>
                        <div className="flex items-center gap-3">
                          <div className="relative w-32">
                            <Input
                              type="number"
                              inputMode="numeric"
                              value={category.amount}
                              onChange={(e) => updateCategoryAmount(category.id, parseInt(e.target.value) || 0)}
                              className="text-left pl-8 focus:ring-2 focus:ring-primary"
                              disabled={!category.editable}
                            />
                            <span className="absolute left-2 top-1/2 transform -translate-y-1/2 text-sm text-muted-foreground">₪</span>
                          </div>
                          {category.editable && (
                            <Button 
                              variant="ghost" 
                              size="sm"
                              className="text-muted-foreground hover:text-foreground focus:ring-2 focus:ring-primary"
                            >
                              <Edit className="w-4 h-4" />
                              <span className="sr-only">ערכו סכום</span>
                            </Button>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}

                {/* Custom Categories */}
                {customCategories.map((category) => (
                  <Card key={category.id} className="border-dashed">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <Input
                            value={category.name}
                            onChange={(e) => {
                              setCustomCategories(prev => prev.map(cat =>
                                cat.id === category.id ? { ...cat, name: e.target.value } : cat
                              ));
                            }}
                            className="font-medium border-none p-0 h-auto focus:ring-2 focus:ring-primary"
                            placeholder="שם הקטגוריה"
                          />
                        </div>
                        <div className="flex items-center gap-3">
                          <div className="relative w-32">
                            <Input
                              type="number"
                              inputMode="numeric"
                              value={category.amount}
                              onChange={(e) => {
                                const newAmount = parseInt(e.target.value) || 0;
                                setCustomCategories(prev => prev.map(cat =>
                                  cat.id === category.id ? { ...cat, amount: newAmount } : cat
                                ));
                              }}
                              className="text-left pl-8 focus:ring-2 focus:ring-primary"
                            />
                            <span className="absolute left-2 top-1/2 transform -translate-y-1/2 text-sm text-muted-foreground">₪</span>
                          </div>
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => removeCustomCategory(category.id)}
                            className="text-destructive hover:text-destructive focus:ring-2 focus:ring-primary"
                          >
                            ×
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Total Display */}
              <Separator />
              <div className="flex justify-between items-center font-semibold">
                <span>סה״כ תקציב:</span>
                <div className="flex items-center gap-2">
                  {Math.abs(totalAmount - getTargetAmount()) > 1000 && (
                    <AlertTriangle className="w-4 h-4 text-warning" />
                  )}
                  <span className={totalAmount > getTargetAmount() ? 'text-destructive' : ''}>
                    ₪{formatNumber(totalAmount)}
                  </span>
                </div>
              </div>
              
              {totalAmount !== getTargetAmount() && (
                <p className="text-sm text-muted-foreground text-center">
                  {totalAmount > getTargetAmount() 
                    ? `חריגה: ₪${formatNumber(totalAmount - getTargetAmount())}`
                    : `חיסכון: ₪${formatNumber(getTargetAmount() - totalAmount)}`
                  }
                </p>
              )}
            </div>
          </div>
        );

      case 3:
        const finalTotal = categories.reduce((sum, cat) => sum + cat.amount, 0) + 
                           customCategories.reduce((sum, cat) => sum + cat.amount, 0);
        
        return (
          <div className="space-y-6">
            <div className="text-center space-y-2">
              <CheckCircle className="w-12 h-12 text-success mx-auto mb-4" />
              <h2>סקירה ושמירה</h2>
              <p className="text-muted-foreground">
                בדקו את התוכנית לפני השמירה
              </p>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>סיכום התקציב</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="text-center p-4 bg-secondary/20 rounded-lg">
                    <div className="text-3xl font-bold text-primary">₪{formatNumber(finalTotal)}</div>
                    <div className="text-sm text-muted-foreground">
                      יעד: ₪{formatNumber(getTargetAmount())} ({budgetMode})
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="grid grid-cols-3 gap-4 text-xs font-medium text-muted-foreground border-b pb-2">
                      <div>קטגוריה</div>
                      <div className="text-center">יעד (₪)</div>
                      <div className="text-left">נותר (₪)</div>
                    </div>
                    
                    {[...categories, ...customCategories]
                      .filter(cat => cat.amount > 0)
                      .sort((a, b) => b.amount - a.amount)
                      .map((category) => (
                        <div key={category.id} className="grid grid-cols-3 gap-4 py-2 border-b border-border/50">
                          <div className="text-sm">{category.name}</div>
                          <div className="text-sm text-center">₪{formatNumber(category.amount)}</div>
                          <div className="text-sm text-left text-muted-foreground">₪{formatNumber(category.amount)}</div>
                        </div>
                      ))}
                  </div>
                </div>
              </CardContent>
            </Card>

            {isDemoMode && (
              <div className="p-3 bg-info/5 border border-info/20 rounded-lg">
                <div className="flex items-start gap-2">
                  <Info className="w-4 h-4 text-info mt-0.5" />
                  <div className="text-sm">
                    <span className="text-info font-medium">מצב תצוגה</span>
                    <p className="text-muted-foreground mt-1">
                      לשמירת התוכנית נדרשת התחברות
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-background flex items-start justify-center p-4">
      <div className="w-full max-w-2xl mt-8">
        {/* Progress indicator */}
        <div className="mb-8">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm text-muted-foreground">שלב {currentStep} מתוך {totalSteps}</span>
            {isDemoMode && (
              <Badge variant="outline" className="text-xs">מצב תצוגה</Badge>
            )}
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        {/* Step content */}
        <div className="mb-8">
          {renderStep()}
        </div>

        {/* Navigation */}
        <div className="flex gap-3">
          {currentStep > 1 && (
            <Button 
              variant="outline" 
              onClick={handleBack}
              className="focus:ring-2 focus:ring-primary min-h-[44px]"
            >
              <ArrowLeft className="w-4 h-4 ml-2" />
              חזרה
            </Button>
          )}
          <Button 
            onClick={handleNext} 
            className="flex-1 min-h-[44px] focus:ring-2 focus:ring-primary"
          >
            {currentStep === totalSteps ? 'שמרו את התוכנית' : 'המשך'}
            {currentStep < totalSteps && <ArrowRight className="w-4 h-4 mr-2" />}
          </Button>
          {currentStep === 1 && (
            <Button 
              variant="ghost" 
              onClick={handleNext}
              className="focus:ring-2 focus:ring-primary min-h-[44px]"
            >
              דלגו כרגע
            </Button>
          )}
        </div>

        {/* Secondary option for step 3 */}
        {currentStep === 3 && (
          <div className="mt-4 text-center">
            <button
              onClick={() => onComplete({
                range: budgetRange,
                mode: budgetMode,
                target: getTargetAmount(),
                categories: [...categories, ...customCategories],
              })}
              className="text-sm text-muted-foreground hover:text-foreground transition-colors focus:ring-2 focus:ring-primary focus:outline-none rounded px-2 py-1"
            >
              נעדכן בהמשך
            </button>
          </div>
        )}
      </div>
    </div>
  );
}