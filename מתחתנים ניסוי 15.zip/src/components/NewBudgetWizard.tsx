import React, { useState, useEffect } from 'react';
import { ArrowRight, ArrowLeft, X } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { Slider } from './ui/slider';

interface NewBudgetWizardProps {
  onComplete: (data: any) => void;
  onCancel: () => void;
  budgetVars: any;
  setBudgetVars: (vars: any) => void;
  suppliersVars: any;
  onNavigate: (screen: string) => void;
}

export const NewBudgetWizard: React.FC<NewBudgetWizardProps> = ({
  onComplete,
  onCancel,
  budgetVars,
  setBudgetVars,
  suppliersVars,
  onNavigate
}) => {
  // Local state for the wizard - start empty
  const [wizardData, setWizardData] = useState({
    guestsMin: budgetVars.guestsMin || 50,
    guestsMax: budgetVars.guestsMax || 150,
    guestsExact: budgetVars.guestsExact || 0,
    giftAvg: budgetVars.giftAvg || 200,
    targetMode: budgetVars.targetMode || 'reset',
    ownContribution: budgetVars.ownContribution || 0,
    savePercent: budgetVars.savePercent || 10
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  // Update local state when props change
  useEffect(() => {
    setWizardData({
      guestsMin: budgetVars.guestsMin || 50,
      guestsMax: budgetVars.guestsMax || 150,
      guestsExact: budgetVars.guestsExact || 0,
      giftAvg: budgetVars.giftAvg || 200,
      targetMode: budgetVars.targetMode || 'reset',
      ownContribution: budgetVars.ownContribution || 0,
      savePercent: budgetVars.savePercent || 10
    });
  }, [budgetVars]);

  const handleInputChange = (field: string, value: any) => {
    setWizardData(prev => ({ ...prev, [field]: value }));
    // Clear error when user starts typing
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const validateField = (field: string, value: any): string => {
    switch (field) {
      case 'guestsMin':
        if (value < 50) return 'מינימום 50 אורחים';
        if (value > 600) return 'מקסימום 600 אורחים';
        if (value >= wizardData.guestsMax) return 'מינימום חייב להיות קטן מהמקסימום';
        break;
      case 'guestsMax':
        if (value < 50) return 'מינימום 50 אורחים';
        if (value > 600) return 'מקסימום 600 אורחים';
        if (value <= wizardData.guestsMin) return 'מקסימום חייב להיות גדול מהמינימום';
        break;
      case 'guestsExact':
        if (value > 0 && (value < 50 || value > 600)) return 'בטווח 50-600 אורחים';
        break;
      case 'giftAvg':
        if (value < 100) return 'מינימום ₪100';
        if (value > 600) return 'מקסימום ₪600';
        break;
      case 'ownContribution':
        if (wizardData.targetMode === 'add' && value <= 0) return 'נדרש סכום';
        break;
      case 'savePercent':
        if (value < 5) return 'מינימום 5%';
        if (value > 30) return 'מקסימום 30%';
        break;
    }
    return '';
  };

  const handleComplete = () => {
    // No live calculations - just save the inputs
    const finalData = {
      ...wizardData,
      giftsMin: wizardData.guestsMin * wizardData.giftAvg,
      giftsMax: wizardData.guestsMax * wizardData.giftAvg,
      targetExact: wizardData.guestsExact > 0 ? wizardData.guestsExact * wizardData.giftAvg : 0,
      targetMin: wizardData.guestsMin * wizardData.giftAvg,
      targetMax: wizardData.guestsMax * wizardData.giftAvg,
    };
    
    setBudgetVars(prev => ({ ...prev, ...finalData }));
    onComplete(finalData);
  };

  // Quick value chips for gift average
  const quickGiftValues = [200, 300, 400];

  const handleQuickGiftSelect = (value: number) => {
    handleInputChange('giftAvg', value);
  };

  // Tick marks for range slider
  const tickMarks = [100, 150, 200, 250, 300, 350, 400, 450, 500, 600];

  // Target mode explanations
  const getTargetModeExplanation = (mode: string) => {
    switch (mode) {
      case 'reset':
        return 'מתכננים סביב יעד מוגדר.';
      case 'add':
        return 'מוסיפים סכום שישלים את הצורך.';
      case 'save':
        return 'מגדירים יעד נמוך כדי להישאר ביתרה.';
      default:
        return '';
    }
  };

  return (
    <div className="min-h-screen" style={{backgroundColor: 'var(--base-bg)'}} dir="rtl">
      {/* Header */}
      <div className="section-header-budget">
        <div className="flex items-center justify-between min-h-[88px] px-6 relative z-10">
          <Button 
            variant="ghost" 
            onClick={onCancel} 
            className="hero-text-secondary focus-ring"
            style={{color: 'var(--text-primary)'}}
          >
            <X size={20} />
            <span className="mr-2">ביטול</span>
          </Button>
          <div className="text-center relative">
            <h1 className="section-title text-primary mb-2">מאסטר התקציב</h1>
            {/* Decorative sparkles */}
            <div className="absolute -top-2 -left-6 w-1.5 h-1.5 rotate-45 opacity-40" style={{backgroundColor: '#F7D7A3'}}></div>
            <div className="absolute top-1 -right-8 w-2 h-2 rotate-45 opacity-50" style={{backgroundColor: '#A7C7E7'}}></div>
          </div>
          <div className="w-16"></div>
        </div>
      </div>

      {/* Main Content */}
      <div className="p-6 max-w-2xl mx-auto space-y-8">
        <Card>
          <CardContent className="p-8 space-y-8">
            
            {/* Section: אורחים */}
            <div className="space-y-6">
              {/* Caption Chip */}
              <div className="flex items-center gap-3 mb-6">
                <div className="chip-selected px-4 py-2">
                  <span style={{color: 'var(--brand-primary)'}}>אורחים</span>
                </div>
                <div className="flex-1 h-px" style={{backgroundColor: 'var(--border-subtle)'}}></div>
              </div>

              {/* Dual Range Slider */}
              <div>
                <Label className="block mb-3">מספר מוזמנים (טווח ראשוני)</Label>
                <div className="space-y-4">
                  {/* Numeric Inputs */}
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="block mb-2 text-sm" style={{color: 'var(--text-secondary)'}}>מינימום</Label>
                      <Input
                        type="number"
                        value={wizardData.guestsMin}
                        onChange={(e) => {
                          const value = parseInt(e.target.value) || 50;
                          handleInputChange('guestsMin', value);
                        }}
                        onBlur={(e) => {
                          const error = validateField('guestsMin', parseInt(e.target.value));
                          if (error) setErrors(prev => ({ ...prev, guestsMin: error }));
                        }}
                        min="50"
                        max="600"
                        step="10"
                        className="text-right focus-ring"
                        dir="rtl"
                        aria-describedby="guests-min-error"
                      />
                      {errors.guestsMin && (
                        <p id="guests-min-error" className="text-sm mt-1" style={{color: 'var(--semantic-danger-text)'}}>
                          {errors.guestsMin}
                        </p>
                      )}
                    </div>
                    <div>
                      <Label className="block mb-2 text-sm" style={{color: 'var(--text-secondary)'}}>מקסימום</Label>
                      <Input
                        type="number"
                        value={wizardData.guestsMax}
                        onChange={(e) => {
                          const value = parseInt(e.target.value) || 150;
                          handleInputChange('guestsMax', value);
                        }}
                        onBlur={(e) => {
                          const error = validateField('guestsMax', parseInt(e.target.value));
                          if (error) setErrors(prev => ({ ...prev, guestsMax: error }));
                        }}
                        min="50"
                        max="600"
                        step="10"
                        className="text-right focus-ring"
                        dir="rtl"
                        aria-describedby="guests-max-error"
                      />
                      {errors.guestsMax && (
                        <p id="guests-max-error" className="text-sm mt-1" style={{color: 'var(--semantic-danger-text)'}}>
                          {errors.guestsMax}
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Dual Range Slider */}
                  <div className="px-2">
                    <Slider
                      value={[wizardData.guestsMin, wizardData.guestsMax]}
                      onValueChange={(values) => {
                        handleInputChange('guestsMin', values[0]);
                        handleInputChange('guestsMax', values[1]);
                      }}
                      min={50}
                      max={600}
                      step={10}
                      className="range-slider"
                      aria-label="טווח מספר אורחים"
                      onKeyDown={(e) => {
                        // Enhanced keyboard support
                        if (e.shiftKey) {
                          e.preventDefault();
                          const currentValues = [wizardData.guestsMin, wizardData.guestsMax];
                          if (e.key === 'ArrowLeft' || e.key === 'ArrowRight') {
                            const step = e.key === 'ArrowRight' ? 50 : -50;
                            const newMin = Math.max(50, Math.min(550, currentValues[0] + step));
                            const newMax = Math.max(100, Math.min(600, currentValues[1] + step));
                            if (newMin < newMax) {
                              handleInputChange('guestsMin', newMin);
                              handleInputChange('guestsMax', newMax);
                            }
                          }
                        }
                      }}
                    />
                    
                    {/* Tick Marks */}
                    <div className="flex justify-between mt-2 text-xs" style={{color: 'var(--text-muted)'}}>
                      {tickMarks.map(tick => (
                        <span key={tick}>{tick}</span>
                      ))}
                    </div>
                  </div>

                  <p className="text-sm" style={{color: 'var(--text-muted)'}}>
                    טווח התחלתי. בהמשך תזינו מספר מדויק.
                  </p>
                </div>
              </div>

              {/* Exact Number (Optional) */}
              <div>
                <Label className="block mb-3">מספר מוזמנים (מדויק) (אופציונלי)</Label>
                <div className="space-y-4">
                  <Input
                    type="number"
                    value={wizardData.guestsExact || ''}
                    onChange={(e) => handleInputChange('guestsExact', parseInt(e.target.value) || 0)}
                    onBlur={(e) => {
                      const error = validateField('guestsExact', parseInt(e.target.value) || 0);
                      if (error) setErrors(prev => ({ ...prev, guestsExact: error }));
                    }}
                    placeholder="אופציונלי - מספר מדויק"
                    min="50"
                    max="600"
                    step="5"
                    className="text-right focus-ring max-w-48"
                    dir="rtl"
                    aria-describedby="guests-exact-error guests-exact-help"
                  />
                  {errors.guestsExact && (
                    <p id="guests-exact-error" className="text-sm" style={{color: 'var(--semantic-danger-text)'}}>
                      {errors.guestsExact}
                    </p>
                  )}

                  {wizardData.guestsExact > 0 && (
                    <div className="px-2">
                      <Slider
                        value={[wizardData.guestsExact]}
                        onValueChange={(values) => handleInputChange('guestsExact', values[0])}
                        min={50}
                        max={600}
                        step={5}
                        className="range-slider"
                        aria-label="מספר אורחים מדויק"
                      />
                    </div>
                  )}

                  <p id="guests-exact-help" className="text-sm" style={{color: 'var(--text-muted)'}}>
                    אפשר לדלג ולחזור לזה לקראת אישורי הגעה.
                  </p>
                </div>
              </div>
            </div>

            {/* Section: מתנה צפויה */}
            <div className="space-y-6">
              {/* Caption Chip */}
              <div className="flex items-center gap-3 mb-6">
                <div className="chip-selected px-4 py-2">
                  <span style={{color: 'var(--brand-primary)'}}>מתנה צפויה</span>
                </div>
                <div className="flex-1 h-px" style={{backgroundColor: 'var(--border-subtle)'}}></div>
              </div>

              <div>
                <Label className="block mb-3">מתנה ממוצעת לאורח (₪)</Label>
                <div className="space-y-4">
                  {/* Quick Chips */}
                  <div className="flex gap-3">
                    {quickGiftValues.map(value => (
                      <Button
                        key={value}
                        variant={wizardData.giftAvg === value ? "default" : "outline"}
                        size="sm"
                        onClick={() => handleQuickGiftSelect(value)}
                        className="focus-ring min-h-[44px] min-w-[44px]"
                      >
                        ₪{value}
                      </Button>
                    ))}
                  </div>

                  {/* Numeric Input */}
                  <Input
                    type="number"
                    value={wizardData.giftAvg || ''}
                    onChange={(e) => handleInputChange('giftAvg', parseInt(e.target.value) || 100)}
                    onBlur={(e) => {
                      const error = validateField('giftAvg', parseInt(e.target.value));
                      if (error) setErrors(prev => ({ ...prev, giftAvg: error }));
                    }}
                    placeholder="סכום בשקלים"
                    min="100"
                    max="600"
                    step="10"
                    className="text-right focus-ring max-w-48"
                    dir="rtl"
                    aria-describedby="gift-avg-error gift-avg-help"
                  />
                  {errors.giftAvg && (
                    <p id="gift-avg-error" className="text-sm" style={{color: 'var(--semantic-danger-text)'}}>
                      {errors.giftAvg}
                    </p>
                  )}

                  {/* Slider */}
                  <div className="px-2">
                    <Slider
                      value={[wizardData.giftAvg]}
                      onValueChange={(values) => handleInputChange('giftAvg', values[0])}
                      min={100}
                      max={600}
                      step={10}
                      className="range-slider"
                      aria-label="מתנה ממוצעת לאורח"
                    />
                  </div>

                  <p id="gift-avg-help" className="text-sm" style={{color: 'var(--text-muted)'}}>
                    זה רק עוגן לתכנון — תמיד תוכלו לשנות.
                  </p>
                </div>
              </div>
            </div>

            {/* Section: יעד */}
            <div className="space-y-6">
              {/* Caption Chip */}
              <div className="flex items-center gap-3 mb-6">
                <div className="chip-selected px-4 py-2">
                  <span style={{color: 'var(--brand-primary)'}}>יעד</span>
                </div>
                <div className="flex-1 h-px" style={{backgroundColor: 'var(--border-subtle)'}}></div>
              </div>

              <div>
                <Label className="block mb-3">מצב יעד</Label>
                <RadioGroup
                  value={wizardData.targetMode}
                  onValueChange={(value) => handleInputChange('targetMode', value)}
                  className="space-y-3"
                >
                  <div className="card p-4">
                    <div className="flex items-start gap-3">
                      <RadioGroupItem value="reset" id="reset" className="mt-1" />
                      <div className="flex-1">
                        <Label htmlFor="reset" className="cursor-pointer">
                          ניצמד
                        </Label>
                        <p className="text-sm mt-1" style={{color: 'var(--text-muted)'}}>
                          {getTargetModeExplanation('reset')}
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="card p-4">
                    <div className="flex items-start gap-3">
                      <RadioGroupItem value="add" id="add" className="mt-1" />
                      <div className="flex-1">
                        <Label htmlFor="add" className="cursor-pointer">
                          כיס אישי
                        </Label>
                        <p className="text-sm mt-1" style={{color: 'var(--text-muted)'}}>
                          {getTargetModeExplanation('add')}
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="card p-4">
                    <div className="flex items-start gap-3">
                      <RadioGroupItem value="save" id="save" className="mt-1" />
                      <div className="flex-1">
                        <Label htmlFor="save" className="cursor-pointer">
                          נרוויח
                        </Label>
                        <p className="text-sm mt-1" style={{color: 'var(--text-muted)'}}>
                          {getTargetModeExplanation('save')}
                        </p>
                      </div>
                    </div>
                  </div>
                </RadioGroup>

                {/* Additional fields based on target mode */}
                {wizardData.targetMode === 'add' && (
                  <div className="mt-4 p-4 card">
                    <Label className="block mb-3">סכום מכיס אישי (₪)</Label>
                    <Input
                      type="number"
                      value={wizardData.ownContribution || ''}
                      onChange={(e) => handleInputChange('ownContribution', parseInt(e.target.value) || 0)}
                      onBlur={(e) => {
                        const error = validateField('ownContribution', parseInt(e.target.value));
                        if (error) setErrors(prev => ({ ...prev, ownContribution: error }));
                      }}
                      className="text-right focus-ring max-w-48"
                      dir="rtl"
                      placeholder="הזינו סכום"
                      min="0"
                      aria-describedby="contribution-error"
                    />
                    {errors.ownContribution && (
                      <p id="contribution-error" className="text-sm mt-1" style={{color: 'var(--semantic-danger-text)'}}>
                        {errors.ownContribution}
                      </p>
                    )}
                  </div>
                )}

                {wizardData.targetMode === 'save' && (
                  <div className="mt-4 p-4 card space-y-4">
                    <Label className="block">אחוז חיסכון (%)</Label>
                    
                    <div className="flex items-center gap-4">
                      <Input
                        type="number"
                        value={wizardData.savePercent}
                        onChange={(e) => handleInputChange('savePercent', parseInt(e.target.value) || 5)}
                        onBlur={(e) => {
                          const error = validateField('savePercent', parseInt(e.target.value));
                          if (error) setErrors(prev => ({ ...prev, savePercent: error }));
                        }}
                        className="text-right focus-ring w-20"
                        dir="rtl"
                        min="5"
                        max="30"
                        step="5"
                        aria-describedby="save-percent-error"
                      />
                      <span style={{color: 'var(--text-secondary)'}} className="text-sm">%</span>
                    </div>

                    <div className="px-2">
                      <Slider
                        value={[wizardData.savePercent]}
                        onValueChange={(values) => handleInputChange('savePercent', values[0])}
                        min={5}
                        max={30}
                        step={5}
                        className="range-slider"
                        aria-label="אחוז חיסכון"
                        renderValue={(value) => `${value}%`}
                      />
                      <div className="flex justify-between mt-2 text-xs" style={{color: 'var(--text-muted)'}}>
                        <span>5%</span>
                        <span>15%</span>
                        <span>30%</span>
                      </div>
                    </div>

                    {errors.savePercent && (
                      <p id="save-percent-error" className="text-sm" style={{color: 'var(--semantic-danger-text)'}}>
                        {errors.savePercent}
                      </p>
                    )}
                  </div>
                )}
              </div>
            </div>

            {/* Footer CTAs */}
            <div className="flex flex-col sm:flex-row gap-3 pt-6 border-t" style={{borderColor: 'var(--border-subtle)'}}>
              <Button 
                onClick={() => onNavigate('suppliers')}
                variant="outline"
                className="flex-1 sm:flex-none focus-ring min-h-[44px]"
              >
                לעמוד ספקים
              </Button>
              <Button 
                onClick={handleComplete}
                className="btn-primary flex-1 sm:flex-none focus-ring min-h-[44px]"
              >
                שמירה וצפייה בתקציב
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};