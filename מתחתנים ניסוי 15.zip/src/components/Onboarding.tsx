import { useState, useEffect, useRef } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Alert, AlertDescription } from './ui/alert';
import { Calendar, Users, Heart, Info } from 'lucide-react';

export interface OnboardingData {
  eventDate: string;
  guestCount: number;
  coupleName1: string;
  coupleName2: string;
  contactPhone: string;
  contactEmail: string;
}

interface OnboardingProps {
  onComplete: (data: OnboardingData) => void;
}

const STORAGE_KEY = 'wedding-onboarding-draft';

export function Onboarding({ onComplete }: OnboardingProps) {
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState<Partial<OnboardingData>>({});
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [hasDraft, setHasDraft] = useState(false);
  const [showDraftBanner, setShowDraftBanner] = useState(false);
  const firstInvalidFieldRef = useRef<HTMLInputElement>(null);

  // Load draft on mount
  useEffect(() => {
    const savedDraft = localStorage.getItem(STORAGE_KEY);
    if (savedDraft) {
      try {
        const draft = JSON.parse(savedDraft);
        if (Object.keys(draft).length > 0) {
          setHasDraft(true);
          setShowDraftBanner(true);
        }
      } catch (e) {
        localStorage.removeItem(STORAGE_KEY);
      }
    }
  }, []);

  // Save draft on form changes
  useEffect(() => {
    if (Object.keys(formData).length > 0) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(formData));
    }
  }, [formData]);

  const loadDraft = () => {
    const savedDraft = localStorage.getItem(STORAGE_KEY);
    if (savedDraft) {
      try {
        const draft = JSON.parse(savedDraft);
        setFormData(draft);
        setShowDraftBanner(false);
        // Go to the first incomplete step
        if (!draft.eventDate) setCurrentStep(1);
        else if (!draft.guestCount) setCurrentStep(2);
        else setCurrentStep(3);
      } catch (e) {
        localStorage.removeItem(STORAGE_KEY);
        setShowDraftBanner(false);
      }
    }
  };

  const dismissDraft = () => {
    localStorage.removeItem(STORAGE_KEY);
    setShowDraftBanner(false);
    setHasDraft(false);
  };

  const validateStep = (step: number): boolean => {
    const newErrors: Record<string, string> = {};

    switch (step) {
      case 1:
        if (!formData.eventDate) {
          newErrors.eventDate = 'יש לבחור תאריך אירוע';
        } else {
          const selectedDate = new Date(formData.eventDate);
          const today = new Date();
          today.setHours(0, 0, 0, 0);
          if (selectedDate < today) {
            newErrors.eventDate = 'תאריך האירוע חייב להיות בעתיד';
          }
        }
        break;
      case 2:
        if (!formData.guestCount || formData.guestCount < 1) {
          newErrors.guestCount = 'יש להזין מספר מוזמנים תקין';
        } else if (formData.guestCount > 1000) {
          newErrors.guestCount = 'מספר המוזמנים לא יכול לעלות על 1000';
        }
        break;
      case 3:
        if (!formData.coupleName1?.trim()) {
          newErrors.coupleName1 = 'יש להזין שם ראשון';
        } else if (formData.coupleName1.trim().length < 2) {
          newErrors.coupleName1 = 'השם חייב להכיל לפחות 2 תווים';
        }
        if (!formData.coupleName2?.trim()) {
          newErrors.coupleName2 = 'יש להזין שם שני';
        } else if (formData.coupleName2.trim().length < 2) {
          newErrors.coupleName2 = 'השם חייב להכיל לפחות 2 תווים';
        }
        if (!formData.contactPhone?.trim()) {
          newErrors.contactPhone = 'יש להזין מספר טלפון';
        } else if (!/^[\d\-\s\+\(\)]{9,}$/.test(formData.contactPhone.trim())) {
          newErrors.contactPhone = 'מספר טלפון לא תקין';
        }
        if (!formData.contactEmail?.trim()) {
          newErrors.contactEmail = 'יש להזין כתובת מייל';
        } else if (!/\S+@\S+\.\S+/.test(formData.contactEmail)) {
          newErrors.contactEmail = 'כתובת מייל לא תקינה';
        }
        break;
    }

    setErrors(newErrors);
    
    // Focus first invalid field
    if (Object.keys(newErrors).length > 0) {
      setTimeout(() => {
        const firstErrorField = Object.keys(newErrors)[0];
        const element = document.getElementById(firstErrorField) as HTMLInputElement;
        if (element) {
          element.focus();
          element.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
      }, 100);
    }

    return Object.keys(newErrors).length === 0;
  };

  const handleNext = () => {
    if (validateStep(currentStep)) {
      if (currentStep < 3) {
        setCurrentStep(currentStep + 1);
      } else {
        // Clear draft on completion
        localStorage.removeItem(STORAGE_KEY);
        onComplete(formData as OnboardingData);
      }
    }
  };

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const updateFormData = (field: keyof OnboardingData, value: string | number) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    // Clear error when user starts typing
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const renderStep = () => {
    switch (currentStep) {
      case 1:
        return (
          <div className="space-y-6">
            <div className="text-center space-y-2">
              <div className="w-16 h-16 bg-secondary rounded-full flex items-center justify-center mx-auto mb-4">
                <Calendar className="w-8 h-8 text-foreground" />
              </div>
              <h2>תאריך האירוע</h2>
              <p className="text-muted-foreground">מתי מתוכננת החתונה שלכם?</p>
            </div>
            
            <div className="space-y-4">
              <div>
                <Label htmlFor="eventDate">תאריך האירוע</Label>
                <Input
                  id="eventDate"
                  type="date"
                  value={formData.eventDate || ''}
                  onChange={(e) => updateFormData('eventDate', e.target.value)}
                  className={`min-h-[44px] ${errors.eventDate ? 'border-destructive focus:ring-destructive' : 'focus:ring-2 focus:ring-primary'}`}
                  aria-invalid={!!errors.eventDate}
                  aria-describedby={errors.eventDate ? 'eventDate-error' : undefined}
                />
                {errors.eventDate && (
                  <p id="eventDate-error" className="text-sm text-destructive mt-1" role="alert">
                    {errors.eventDate}
                  </p>
                )}
              </div>
            </div>
          </div>
        );

      case 2:
        return (
          <div className="space-y-6">
            <div className="text-center space-y-2">
              <div className="w-16 h-16 bg-secondary rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="w-8 h-8 text-foreground" />
              </div>
              <h2>מספר מוזמנים</h2>
              <p className="text-muted-foreground">כמה אנשים אתם מתכננים להזמין?</p>
            </div>
            
            <div className="space-y-4">
              <div>
                <Label htmlFor="guestCount">מספר מוזמנים משוער</Label>
                <Input
                  id="guestCount"
                  type="number"
                  min="1"
                  max="1000"
                  inputMode="numeric"
                  value={formData.guestCount || ''}
                  onChange={(e) => updateFormData('guestCount', parseInt(e.target.value) || 0)}
                  placeholder="לדוגמה: 120"
                  className={`min-h-[44px] ${errors.guestCount ? 'border-destructive focus:ring-destructive' : 'focus:ring-2 focus:ring-primary'}`}
                  aria-invalid={!!errors.guestCount}
                  aria-describedby={errors.guestCount ? 'guestCount-error guestCount-help' : 'guestCount-help'}
                />
                {errors.guestCount && (
                  <p id="guestCount-error" className="text-sm text-destructive mt-1" role="alert">
                    {errors.guestCount}
                  </p>
                )}
                <p id="guestCount-help" className="text-sm text-muted-foreground mt-1">
                  ניתן לעדכן מספר זה בהמשך
                </p>
              </div>
            </div>
          </div>
        );

      case 3:
        return (
          <div className="space-y-6">
            <div className="text-center space-y-2">
              <div className="w-16 h-16 bg-secondary rounded-full flex items-center justify-center mx-auto mb-4">
                <Heart className="w-8 h-8 text-foreground" />
              </div>
              <h2>פרטי הזוג</h2>
              <p className="text-muted-foreground">בואו נכיר - איך קוראים לכם?</p>
            </div>
            
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="coupleName1">שם ראשון</Label>
                  <Input
                    id="coupleName1"
                    value={formData.coupleName1 || ''}
                    onChange={(e) => updateFormData('coupleName1', e.target.value)}
                    placeholder="שם ראשון"
                    className={`min-h-[44px] ${errors.coupleName1 ? 'border-destructive focus:ring-destructive' : 'focus:ring-2 focus:ring-primary'}`}
                    aria-invalid={!!errors.coupleName1}
                    aria-describedby={errors.coupleName1 ? 'coupleName1-error' : undefined}
                  />
                  {errors.coupleName1 && (
                    <p id="coupleName1-error" className="text-sm text-destructive mt-1" role="alert">
                      {errors.coupleName1}
                    </p>
                  )}
                </div>
                <div>
                  <Label htmlFor="coupleName2">שם שני</Label>
                  <Input
                    id="coupleName2"
                    value={formData.coupleName2 || ''}
                    onChange={(e) => updateFormData('coupleName2', e.target.value)}
                    placeholder="שם שני"
                    className={`min-h-[44px] ${errors.coupleName2 ? 'border-destructive focus:ring-destructive' : 'focus:ring-2 focus:ring-primary'}`}
                    aria-invalid={!!errors.coupleName2}
                    aria-describedby={errors.coupleName2 ? 'coupleName2-error' : undefined}
                  />
                  {errors.coupleName2 && (
                    <p id="coupleName2-error" className="text-sm text-destructive mt-1" role="alert">
                      {errors.coupleName2}
                    </p>
                  )}
                </div>
              </div>
              
              <div>
                <Label htmlFor="contactPhone">טלפון ליצירת קשר</Label>
                <Input
                  id="contactPhone"
                  type="tel"
                  inputMode="tel"
                  value={formData.contactPhone || ''}
                  onChange={(e) => updateFormData('contactPhone', e.target.value)}
                  placeholder="050-1234567"
                  className={`min-h-[44px] ${errors.contactPhone ? 'border-destructive focus:ring-destructive' : 'focus:ring-2 focus:ring-primary'}`}
                  aria-invalid={!!errors.contactPhone}
                  aria-describedby={errors.contactPhone ? 'contactPhone-error' : undefined}
                />
                {errors.contactPhone && (
                  <p id="contactPhone-error" className="text-sm text-destructive mt-1" role="alert">
                    {errors.contactPhone}
                  </p>
                )}
              </div>
              
              <div>
                <Label htmlFor="contactEmail">כתובת מייל</Label>
                <Input
                  id="contactEmail"
                  type="email"
                  inputMode="email"
                  value={formData.contactEmail || ''}
                  onChange={(e) => updateFormData('contactEmail', e.target.value)}
                  placeholder="example@email.com"
                  className={`min-h-[44px] ${errors.contactEmail ? 'border-destructive focus:ring-destructive' : 'focus:ring-2 focus:ring-primary'}`}
                  aria-invalid={!!errors.contactEmail}
                  aria-describedby={errors.contactEmail ? 'contactEmail-error' : undefined}
                />
                {errors.contactEmail && (
                  <p id="contactEmail-error" className="text-sm text-destructive mt-1" role="alert">
                    {errors.contactEmail}
                  </p>
                )}
              </div>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Draft banner */}
        {showDraftBanner && (
          <Alert className="mb-6 border-info bg-info/5">
            <Info className="h-4 w-4 text-info" />
            <AlertDescription className="text-info">
              נמצאה טיוטה — המשיכו מאיפה שהפ��קתם
              <div className="flex gap-2 mt-2">
                <Button 
                  size="sm" 
                  variant="outline" 
                  onClick={loadDraft}
                  className="h-8 text-xs border-info text-info hover:bg-info hover:text-white focus:ring-2 focus:ring-info"
                >
                  המשך
                </Button>
                <Button 
                  size="sm" 
                  variant="ghost" 
                  onClick={dismissDraft}
                  className="h-8 text-xs text-info hover:bg-info/10 focus:ring-2 focus:ring-info"
                >
                  התחל מחדש
                </Button>
              </div>
            </AlertDescription>
          </Alert>
        )}

        {/* Progress indicator */}
        <div className="mb-8">
          <div className="flex justify-between mb-2" dir="ltr">
            {[1, 2, 3].map((step) => (
              <div
                key={step}
                className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium transition-colors ${
                  step <= currentStep
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-secondary text-muted-foreground'
                }`}
                aria-label={`שלב ${step} ${step <= currentStep ? 'הושלם' : 'ממתין'}`}
              >
                {step}
              </div>
            ))}
          </div>
          <div className="h-2 bg-secondary rounded-full overflow-hidden">
            <div
              className="h-full bg-primary transition-all duration-300"
              style={{ width: `${(currentStep / 3) * 100}%` }}
              role="progressbar"
              aria-valuenow={currentStep}
              aria-valuemin={1}
              aria-valuemax={3}
              aria-label={`התקדמות: שלב ${currentStep} מתוך 3`}
            />
          </div>
          <p className="text-sm text-muted-foreground text-center mt-2">
            שלב {currentStep} מתוך 3
          </p>
        </div>

        {/* Step content */}
        <div className="mb-8">
          {renderStep()}
        </div>

        {/* Navigation */}
        <div className="flex gap-3">
          {currentStep > 1 && (
            <Button
              variant="outline"
              onClick={handleBack}
              className="flex-1 min-h-[44px] focus:ring-2 focus:ring-primary"
            >
              חזרה
            </Button>
          )}
          <Button
            onClick={handleNext}
            className="flex-1 min-h-[44px] focus:ring-2 focus:ring-primary"
          >
            {currentStep === 3 ? 'התחילו לתכנן' : 'המשך'}
          </Button>
        </div>

        {/* Skip option for final step - now secondary */}
        {currentStep === 3 && (
          <div className="mt-4 text-center">
            <button
              onClick={() => onComplete(formData as OnboardingData)}
              className="text-sm text-muted-foreground hover:text-foreground transition-colors focus:ring-2 focus:ring-primary focus:outline-none rounded px-2 py-1"
            >
              דלגו כרגע
            </button>
          </div>
        )}
      </div>
    </div>
  );
}