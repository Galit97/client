import { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Calendar } from './ui/calendar';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { CalendarDays, ArrowLeft } from 'lucide-react';
import { toast } from 'sonner';

interface AppState {
  isAuthenticated: boolean;
  isViewOnly: boolean;
  hasEventDate: boolean;
  coupleName: string;
}

interface Event {
  eventName: string;
  eventNameEdited: boolean;
  eventDate: string;
}

interface Countdown {
  daysLeft: number;
}

interface EventDateSelectorProps {
  appState: AppState;
  setAppState: React.Dispatch<React.SetStateAction<AppState>>;
  event: Event;
  setEvent: React.Dispatch<React.SetStateAction<Event>>;
  countdown: Countdown;
  setCountdown: React.Dispatch<React.SetStateAction<Countdown>>;
  onDateSet: (eventData: {date: Date, eventName: string, daysLeft: number}) => void;
  onSkip: () => void;
}

export function EventDateSelector({ 
  appState, 
  setAppState, 
  event, 
  setEvent, 
  countdown, 
  setCountdown, 
  onDateSet, 
  onSkip 
}: EventDateSelectorProps) {
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(undefined);

  // Auto-generate event name when couple name changes (only if not manually edited)
  useEffect(() => {
    if (!event.eventNameEdited && appState.coupleName !== "") {
      setEvent(prev => ({
        ...prev,
        eventName: "החתונה של " + appState.coupleName
      }));
    }
  }, [appState.coupleName, event.eventNameEdited, setEvent]);

  const handleCoupleNameChange = (value: string) => {
    setAppState(prev => ({
      ...prev,
      coupleName: value
    }));
  };

  const handleEventNameChange = (value: string) => {
    setEvent(prev => ({
      ...prev,
      eventName: value
    }));
  };

  const handleEventNameFocus = () => {
    // Mark as manually edited when user focuses on the field for the first time
    if (!event.eventNameEdited) {
      setEvent(prev => ({
        ...prev,
        eventNameEdited: true
      }));
    }
  };

  const handleDateSelect = (date: Date | undefined) => {
    if (date) {
      // Ensure the date is in the future
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      if (date < today) {
        toast.error('נא בחרו תאריך עתידי');
        return;
      }
      
      setSelectedDate(date);
      
      // Calculate days left
      const timeDiff = date.getTime() - today.getTime();
      const daysLeft = Math.ceil(timeDiff / (1000 * 3600 * 24));
      
      setCountdown(prev => ({
        ...prev,
        daysLeft: daysLeft
      }));
      
      setEvent(prev => ({
        ...prev,
        eventDate: date.toISOString().split('T')[0]
      }));
    }
  };

  const handleConfirm = () => {
    if (selectedDate) {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const timeDiff = selectedDate.getTime() - today.getTime();
      const daysLeft = Math.ceil(timeDiff / (1000 * 3600 * 24));
      
      onDateSet({
        date: selectedDate,
        eventName: event.eventName,
        daysLeft: daysLeft
      });
      toast.success('תאריך החתונה נשמר בהצלחה!');
    }
  };

  const formatSelectedDate = (date: Date) => {
    return date.toLocaleDateString('he-IL', { 
      weekday: 'long', 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    });
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-md space-y-6">
        {/* Header */}
        <div className="text-center space-y-2">
          <CalendarDays className="w-12 h-12 text-primary mx-auto mb-4" />
          <h1>בחירת תאריך החתונה</h1>
          <p className="text-muted-foreground">
            בחרו את התאריך המתוכנן לחתונה שלכם
          </p>
        </div>

        {/* Input Fields Card */}
        <Card className="border-border">
          <CardContent className="space-y-4 pt-6">
            {/* Couple Name Input */}
            <div className="space-y-2">
              <Label htmlFor="couple-name" className="text-right block">שם הזוג</Label>
              <Input
                id="couple-name"
                type="text"
                value={appState.coupleName}
                onChange={(e) => handleCoupleNameChange(e.target.value)}
                placeholder="הזינו את שם הזוג"
                className="text-right focus:ring-2 focus:ring-primary"
                dir="rtl"
              />
            </div>

            {/* Event Name Input */}
            <div className="space-y-2">
              <Label htmlFor="event-name" className="text-right block">שם האירוע</Label>
              <Input
                id="event-name"
                type="text"
                value={event.eventName}
                onChange={(e) => handleEventNameChange(e.target.value)}
                onFocus={handleEventNameFocus}
                placeholder="הזינו את שם האירוע"
                className="text-right focus:ring-2 focus:ring-primary"
                dir="rtl"
              />
            </div>
          </CardContent>
        </Card>

        {/* Calendar Card */}
        <Card className="border-border">
          <CardHeader>
            <CardTitle className="text-center">תאריך האירוע</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-center">
              <Calendar
                mode="single"
                selected={selectedDate}
                onSelect={handleDateSelect}
                disabled={(date) => {
                  const today = new Date();
                  today.setHours(0, 0, 0, 0);
                  return date < today;
                }}
                initialFocus
                className="rounded-md border border-border"
              />
            </div>
            
            {selectedDate && (
              <div className="text-center p-4 bg-secondary/20 rounded-lg border border-border">
                <p className="text-sm text-muted-foreground">תאריך נבחר:</p>
                <p className="font-semibold text-primary">
                  {formatSelectedDate(selectedDate)}
                </p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Live Preview */}
        <div className="text-center text-sm text-muted-foreground space-y-1">
          <div>
            שם האירוע: {event.eventName || "—"} · תאריך: {event.eventDate || "—"}
          </div>
          {selectedDate && countdown.daysLeft > 0 && (
            <div className="text-primary font-medium">
              {countdown.daysLeft === 0 ? "היום!" : `נשארו ${countdown.daysLeft} ימים`}
            </div>
          )}
          {selectedDate && countdown.daysLeft === 0 && (
            <div className="text-primary font-medium">היום!</div>
          )}
        </div>

        {/* Actions */}
        <div className="flex flex-col gap-3">
          <Button
            onClick={handleConfirm}
            disabled={!selectedDate}
            className="w-full min-h-[44px] focus:ring-2 focus:ring-primary"
          >
            שמרו תאריך
          </Button>
          
          <div className="flex gap-3">
            <Button
              variant="outline"
              onClick={onSkip}
              className="flex-1 min-h-[44px] focus:ring-2 focus:ring-primary"
            >
              <ArrowLeft className="w-4 h-4 ml-2" />
              חזור
            </Button>
            
            <button
              onClick={onSkip}
              className="flex-1 text-sm text-muted-foreground hover:text-foreground transition-colors focus:ring-2 focus:ring-primary focus:outline-none rounded px-2 py-1"
            >
              דלגו כרגע
            </button>
          </div>
        </div>

        {/* Helper Text */}
        <div className="text-center text-xs text-muted-foreground">
          ניתן תמיד לשנות את התאריך מההגדרות
        </div>
      </div>
    </div>
  );
}