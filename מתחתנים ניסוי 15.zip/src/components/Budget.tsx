import React, { useState } from 'react';
import { BackButton } from './ui/back-button';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { CheckCircle, Target, PlusCircle, TrendingDown, Info, BarChart } from 'lucide-react';

interface BudgetVars {
  guestsMin: number;
  guestsMax: number;
  guestsExact: number;
  giftAvg: number;
  targetMode: string; // "reset" | "add" | "save"
  ownContribution: number;
  savePercent: number;
  giftsMin: number;
  giftsMax: number;
  targetExact: number;
  targetMin: number;
  targetMax: number;
  forecastTotal: number;
}

interface BudgetProps {
  budgetVars: BudgetVars;
  onBack: () => void;
  onNavigate: (screen: string) => void;
}

const TARGET_MODES = [
  {
    id: 'reset',
    title: 'ניצמד לתקציב (איפוס)',
    description: 'החתונה תעלה בדיוק כמו שנכנס ממתנות',
    icon: Target,
    color: 'var(--accent-sage)',
    bgColor: 'var(--surface-sage-50)'
  },
  {
    id: 'add',
    title: 'נוסיף מכיס אישי',
    description: 'נוסיף כסף משלנו בנוסף למתנות',
    icon: PlusCircle,
    color: 'var(--accent-sky)',
    bgColor: 'var(--surface-sky-50)'
  },
  {
    id: 'save',
    title: 'נכוון נמוך כדי להרווח',
    description: 'נשמור כסף ונרוויח מהחתונה',
    icon: TrendingDown,
    color: 'var(--accent-gold)',
    bgColor: 'var(--surface-gold-50)'
  }
];

export function Budget({ budgetVars, onBack, onNavigate }: BudgetProps) {
  const [selectedMode, setSelectedMode] = useState(budgetVars.targetMode || '');
  const [showDetails, setShowDetails] = useState(budgetVars.targetMode !== '');

  const handleModeSelect = (mode: string) => {
    setSelectedMode(mode);
  };

  const handleContinue = () => {
    if (selectedMode) {
      setShowDetails(true);
    }
  };

  const formatCurrency = (amount: number): string => {
    if (amount === 0) return "—";
    return new Intl.NumberFormat('he-IL', {
      style: 'currency',
      currency: 'ILS',
      minimumFractionDigits: 0
    }).format(amount);
  };

  const selectedModeData = TARGET_MODES.find(mode => mode.id === selectedMode);

  if (!showDetails) {
    // Step 1: Mode Selection
    return (
      <>
        {/* Header with Back Button */}
        <div style={{backgroundColor: '#EDF8F4', minHeight: '88px'}} className="relative">
          <div className="flex items-center justify-between px-6 py-4 relative z-10">
            <BackButton onBack={onBack} />
            <div className="text-center relative">
              <h1 className="section-title text-primary">
                תקציב
              </h1>
              {/* Decorative sparkles */}
              <div
                className="absolute -top-2 -left-6 w-1.5 h-1.5 rotate-45 opacity-40"
                style={{ backgroundColor: "#6FBFA8" }}
              ></div>
              <div
                className="absolute top-1 -right-8 w-2 h-2 rotate-45 opacity-50"
                style={{ backgroundColor: "#A7C7E7" }}
              ></div>
              <div
                className="absolute -bottom-1 left-8 w-1 h-1 rotate-45 opacity-45"
                style={{ backgroundColor: "#6FBFA8" }}
              ></div>
            </div>
            <div className="w-20"></div>
          </div>
        </div>

        <div className="p-6 space-y-6">
          {/* Introduction */}
          <div className="max-w-md mx-auto text-center">
            <div
              className="w-16 h-16 mx-auto rounded-full flex items-center justify-center mb-4"
              style={{ backgroundColor: 'var(--surface-sage-50)' }}
            >
              <Target className="w-8 h-8" style={{ color: 'var(--accent-sage)' }} />
            </div>
            <h2 style={{ color: 'var(--text-primary)' }} className="mb-3">
              איך אתם רוצים להתקצב?
            </h2>
            <p style={{ color: 'var(--text-secondary)' }} className="mb-6">
              בחרו את השיטה שהכי מתאימה לכם
            </p>
          </div>

          {/* Mode Selection Cards */}
          <div className="space-y-4 max-w-md mx-auto">
            {TARGET_MODES.map((mode) => {
              const IconComponent = mode.icon;
              const isSelected = selectedMode === mode.id;
              
              return (
                <Card
                  key={mode.id}
                  className={`cursor-pointer transition-all duration-200 ${
                    isSelected ? 'ring-2' : 'hover:shadow-lg'
                  }`}
                  style={{
                    borderColor: isSelected ? mode.color : 'var(--border-subtle)',
                    backgroundColor: isSelected ? mode.bgColor : 'var(--base-white)'
                  }}
                  onClick={() => handleModeSelect(mode.id)}
                >
                  <CardContent className="p-4">
                    <div className="flex items-start gap-4" dir="rtl">
                      <div
                        className="w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0"
                        style={{
                          backgroundColor: isSelected ? mode.color : mode.bgColor
                        }}
                      >
                        <IconComponent 
                          className="w-6 h-6" 
                          style={{ 
                            color: isSelected ? 'var(--text-inverse)' : mode.color 
                          }} 
                        />
                      </div>
                      <div className="flex-1 text-right">
                        <div className="flex items-center justify-between mb-2">
                          <h3 
                            className="font-medium"
                            style={{ color: 'var(--text-primary)' }}
                          >
                            {mode.title}
                          </h3>
                          {isSelected && (
                            <CheckCircle 
                              className="w-5 h-5" 
                              style={{ color: mode.color }} 
                            />
                          )}
                        </div>
                        <p 
                          className="text-sm"
                          style={{ color: 'var(--text-secondary)' }}
                        >
                          {mode.description}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* Continue Button */}
          {selectedMode && (
            <div className="max-w-md mx-auto pt-4">
              <Button
                onClick={handleContinue}
                className="w-full focus:ring-2 focus:ring-ring"
                style={{
                  backgroundColor: 'var(--brand-primary)',
                  color: 'var(--text-inverse)'
                }}
              >
                המשיכו עם השיטה שנבחרה
              </Button>
            </div>
          )}

          {/* Helper Text */}
          <div 
            className="max-w-md mx-auto p-4 rounded-lg text-center"
            style={{
              backgroundColor: 'var(--semantic-info-bg)',
              color: 'var(--semantic-info-text)'
            }}
          >
            <Info className="w-4 h-4 mx-auto mb-2" />
            <p className="text-sm">
              תוכלו לשנות את השיטה בכל זמן מהאשף החדש
            </p>
          </div>
        </div>
      </>
    );
  }

  // Step 2: Budget Details Display
  return (
    <>
      {/* Header with Back Button */}
      <div style={{backgroundColor: '#EDF8F4', minHeight: '88px'}} className="relative">
        <div className="flex items-center justify-between px-6 py-4 relative z-10">
          <BackButton onBack={onBack} />
          <div className="text-center relative">
            <h1 className="section-title text-primary">
              תקציב
            </h1>
            {/* Decorative sparkles */}
            <div
              className="absolute -top-2 -left-6 w-1.5 h-1.5 rotate-45 opacity-40"
              style={{ backgroundColor: "#6FBFA8" }}
            ></div>
            <div
              className="absolute top-1 -right-8 w-2 h-2 rotate-45 opacity-50"
              style={{ backgroundColor: "#A7C7E7" }}
            ></div>
            <div
              className="absolute -bottom-1 left-8 w-1 h-1 rotate-45 opacity-45"
              style={{ backgroundColor: "#6FBFA8" }}
            ></div>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowDetails(false)}
            className="focus:ring-2 focus:ring-ring"
          >
            שנו שיטה
          </Button>
        </div>
      </div>

      <div className="p-6 space-y-6">
        {/* Selected Mode Header */}
        {selectedModeData && (
          <Card className="max-w-md mx-auto">
            <CardContent className="p-4">
              <div className="flex items-center gap-3 text-center justify-center" dir="rtl">
                <div
                  className="w-8 h-8 rounded-full flex items-center justify-center"
                  style={{ backgroundColor: selectedModeData.bgColor }}
                >
                  <selectedModeData.icon 
                    className="w-4 h-4" 
                    style={{ color: selectedModeData.color }} 
                  />
                </div>
                <div>
                  <h3 style={{ color: 'var(--text-primary)' }}>
                    {selectedModeData.title}
                  </h3>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Budget Summary Cards */}
        <div className="grid grid-cols-1 gap-4 max-w-md mx-auto">
          {/* Target Budget */}
          <Card>
            <CardContent className="p-4 text-center">
              <h3 style={{ color: 'var(--text-secondary)' }} className="text-sm mb-2">
                יעד תקציב
              </h3>
              <div style={{ color: 'var(--text-primary)' }} className="text-2xl font-semibold">
                {budgetVars.targetExact > 0 
                  ? formatCurrency(budgetVars.targetExact)
                  : budgetVars.targetMin > 0 && budgetVars.targetMax > 0
                    ? `${formatCurrency(budgetVars.targetMin)}–${formatCurrency(budgetVars.targetMax)}`
                    : "—"
                }
              </div>
            </CardContent>
          </Card>

          {/* Current Forecast */}
          <Card>
            <CardContent className="p-4 text-center">
              <h3 style={{ color: 'var(--text-secondary)' }} className="text-sm mb-2">
                תחזית נוכחית
              </h3>
              <div style={{ color: 'var(--text-primary)' }} className="text-2xl font-semibold">
                {formatCurrency(budgetVars.forecastTotal)}
              </div>
            </CardContent>
          </Card>

          {/* Budget Status */}
          {budgetVars.forecastTotal > 0 && (budgetVars.targetExact > 0 || budgetVars.targetMin > 0) && (
            <Card>
              <CardContent className="p-4 text-center">
                <h3 style={{ color: 'var(--text-secondary)' }} className="text-sm mb-2">
                  מצב התקציב
                </h3>
                {(() => {
                  const target = budgetVars.targetExact || budgetVars.targetMin;
                  const percentage = target > 0 ? (budgetVars.forecastTotal / target) * 100 : 0;
                  const status = percentage <= 80 ? 'בגבול' : 
                                percentage <= 100 ? 'בסיכון' : 'חריגה';
                  
                  return (
                    <div className="flex items-center justify-center gap-2">
                      {status === 'בגבול' && <CheckCircle className="w-4 h-4 text-green-600" />}
                      {status === 'בסיכון' && <Info className="w-4 h-4 text-amber-600" />}
                      {status === 'חריגה' && <Info className="w-4 h-4 text-red-600" />}
                      <span 
                        style={{ 
                          color: status === 'בגבול' ? 'var(--semantic-success-text)' :
                                status === 'בסיכון' ? 'var(--semantic-warning-text)' :
                                'var(--semantic-danger-text)'
                        }}
                      >
                        {status} ({Math.round(percentage)}%)
                      </span>
                    </div>
                  );
                })()}
              </CardContent>
            </Card>
          )}
        </div>

        {/* Action Buttons */}
        <div className="space-y-3 max-w-md mx-auto">
          <Button
            onClick={() => onNavigate('budget-overview')}
            className="w-full focus:ring-2 focus:ring-ring"
            style={{
              backgroundColor: 'var(--brand-primary)',
              color: 'var(--text-inverse)'
            }}
          >
            <BarChart className="w-4 h-4 ml-2" />
            צפייה מפורטת בתקציב
          </Button>

          <Button
            variant="outline"
            onClick={() => onNavigate('new-budget-wizard')}
            className="w-full focus:ring-2 focus:ring-ring"
          >
            ערכו הגדרות תקציב
          </Button>

          <Button
            variant="outline"
            onClick={() => onNavigate('suppliers')}
            className="w-full focus:ring-2 focus:ring-ring"
          >
            נהלו ספקים
          </Button>
        </div>

        {/* No Data State */}
        {budgetVars.forecastTotal === 0 && (budgetVars.targetExact === 0 && budgetVars.targetMin === 0) && (
          <Card className="max-w-md mx-auto">
            <CardContent className="p-6 text-center">
              <div
                className="w-12 h-12 mx-auto rounded-full flex items-center justify-center mb-4"
                style={{ backgroundColor: 'var(--surface-sky-50)' }}
              >
                <Info className="w-6 h-6" style={{ color: 'var(--accent-sky)' }} />
              </div>
              <h3 style={{ color: 'var(--text-primary)' }} className="mb-2">
                עדיין אין נתוני תקציב
              </h3>
              <p style={{ color: 'var(--text-secondary)' }} className="text-sm mb-4">
                השלימו את הגדרת התקציב כדי לראות נתונים מפורטים
              </p>
              <Button
                variant="outline"
                onClick={() => onNavigate('new-budget-wizard')}
                className="focus:ring-2 focus:ring-ring"
              >
                השלימו הגדרת תקציב
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </>
  );
}