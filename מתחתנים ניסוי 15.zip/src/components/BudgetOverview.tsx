import React from 'react';
import { ArrowRight, Edit3, Briefcase } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { BudgetRingShekel } from './ui/budget-ring-shekel';

interface BudgetOverviewProps {
  budgetVars: any;
  suppliersVars: any;
  onEdit: () => void;
  onBack: () => void;
}

export const BudgetOverview: React.FC<BudgetOverviewProps> = ({
  budgetVars,
  suppliersVars,
  onEdit,
  onBack
}) => {
  const formatCurrency = (amount: number): string => {
    if (amount === 0) return "—";
    return new Intl.NumberFormat('he-IL', {
      style: 'currency',
      currency: 'ILS',
      minimumFractionDigits: 0
    }).format(amount);
  };

  const hasCommittedSuppliers = suppliersVars.committedCount > 0;
  const hasBudgetData = budgetVars.targetExact > 0 || budgetVars.targetMin > 0;

  return (
    <div className="min-h-screen" style={{backgroundColor: '#FFFFFF'}} dir="rtl">
      {/* Header Band - Sage.50 */}
      <div style={{backgroundColor: '#EDF8F4'}} className="relative">
        <div className="section-header-budget">
          <div className="flex items-center justify-between px-4 py-6 responsive-md:px-6 responsive-lg:px-8 relative z-10">
            {/* Back Button */}
            <Button 
              variant="ghost" 
              onClick={onBack} 
              className="focus-ring responsive-xs:min-h-[48px] responsive-md:min-h-[44px]"
              style={{color: 'var(--text-primary)'}}
            >
              <span className="text-lg">←</span>
              <span className="mr-2 responsive-xs:hidden responsive-md:inline">חזרה</span>
            </Button>

            {/* Desktop Title + Edit Button */}
            <div className="hidden responsive-lg:flex items-center gap-4">
              <div className="text-center relative">
                <h1 className="section-title text-primary">תקציב</h1>
              </div>
              <Button 
                variant="outline" 
                onClick={onEdit} 
                className="focus-ring responsive-xs:min-h-[48px] responsive-md:min-h-[44px]"
                size="sm"
              >
                <Edit3 size={16} />
                <span className="mr-2">עריכת התקציב</span>
              </Button>
            </div>

            {/* Mobile/Tablet Title */}
            <div className="responsive-lg:hidden text-center relative">
              <h1 className="section-title text-primary">תקציב</h1>
            </div>

            <div className="w-16 responsive-lg:w-auto"></div>
          </div>

          {/* Mobile/Tablet Edit Button - Below Title */}
          <div className="responsive-lg:hidden flex justify-center pb-4">
            <Button 
              variant="outline" 
              onClick={onEdit} 
              className="focus-ring responsive-xs:min-h-[48px] responsive-md:min-h-[44px]"
              size="sm"
            >
              <Edit3 size={16} />
              <span className="mr-2">עריכת התקציב</span>
            </Button>
          </div>

          {/* Decorative sparkles */}
          <div
            className="absolute -top-2 -left-6 w-1.5 h-1.5 rotate-45 opacity-40"
            style={{ backgroundColor: "#6FBFA8" }}
          ></div>
          <div
            className="absolute top-1 -right-8 w-2 h-2 rotate-45 opacity-50"
            style={{ backgroundColor: "#A7C7E7" }}
          ></div>
          <div
            className="absolute -bottom-1 left-8 w-1 h-1 rotate-45 opacity-45"
            style={{ backgroundColor: "#6FBFA8" }}
          ></div>
        </div>
      </div>

      <div className="px-4 py-6 responsive-md:px-6 responsive-lg:px-8 space-y-8">
        <div className="max-w-7xl mx-auto">
          
          {/* Budget Summary KPIs */}
          {hasBudgetData && (
            <div className="grid grid-cols-1 responsive-md:grid-cols-2 responsive-lg:grid-cols-3 gap-6">
              <Card>
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 mx-auto rounded-full flex items-center justify-center mb-4" 
                       style={{ backgroundColor: 'var(--surface-sage-50)' }}>
                    <BudgetRingShekel size={24} variant="default" />
                  </div>
                  <h3 className="font-medium mb-2 responsive-xs:text-sm responsive-md:text-base" style={{ color: 'var(--text-secondary)' }}>
                    יעד התקציב
                  </h3>
                  <p className="text-2xl responsive-xs:text-xl font-semibold mb-1" style={{ color: 'var(--text-primary)' }}>
                    {formatCurrency(budgetVars.targetExact || budgetVars.targetMin)}
                  </p>
                  {budgetVars.targetMin > 0 && budgetVars.targetMax > budgetVars.targetMin && (
                    <p className="text-sm responsive-xs:text-xs" style={{ color: 'var(--text-muted)' }}>
                      טווח: {formatCurrency(budgetVars.targetMin)}–{formatCurrency(budgetVars.targetMax)}
                    </p>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 mx-auto rounded-full flex items-center justify-center mb-4" 
                       style={{ backgroundColor: 'var(--surface-sky-50)' }}>
                    <BudgetRingShekel size={24} variant="active" />
                  </div>
                  <h3 className="font-medium mb-2 responsive-xs:text-sm responsive-md:text-base" style={{ color: 'var(--text-secondary)' }}>
                    צפוי כרגע
                  </h3>
                  <p className="text-2xl responsive-xs:text-xl font-semibold" style={{ color: 'var(--text-primary)' }}>
                    {formatCurrency(budgetVars.forecastTotal)}
                  </p>
                </CardContent>
              </Card>

              <Card className="responsive-md:col-span-2 responsive-lg:col-span-1">
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 mx-auto rounded-full flex items-center justify-center mb-4" 
                       style={{ backgroundColor: 'var(--surface-rose-50)' }}>
                    <div className="w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold"
                         style={{ backgroundColor: 'var(--accent-rose)', color: 'white' }}>
                      %
                    </div>
                  </div>
                  <h3 className="font-medium mb-2 responsive-xs:text-sm responsive-md:text-base" style={{ color: 'var(--text-secondary)' }}>
                    אחוז מתוך היעד
                  </h3>
                  <p className="text-2xl responsive-xs:text-xl font-semibold" style={{ color: 'var(--text-primary)' }}>
                    {budgetVars.targetExact > 0 || budgetVars.targetMin > 0
                      ? `${Math.round((budgetVars.forecastTotal / (budgetVars.targetExact || budgetVars.targetMin)) * 100)}%`
                      : "—"
                    }
                  </p>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Main Content */}
          {!hasCommittedSuppliers ? (
            /* Empty State - No Committed Suppliers */
            <Card>
              <CardContent className="p-8 responsive-xs:p-6 text-center space-y-6">
                <div className="w-20 h-20 responsive-xs:w-16 responsive-xs:h-16 mx-auto rounded-full flex items-center justify-center mb-6" 
                     style={{ backgroundColor: 'var(--surface-sky-50)' }}>
                  <Briefcase className="w-10 h-10 responsive-xs:w-8 responsive-xs:h-8" style={{ color: 'var(--accent-sky)' }} />
                </div>
                
                <div className="space-y-3 max-w-md mx-auto">
                  <h2 className="text-xl responsive-xs:text-lg font-semibold" style={{ color: 'var(--text-primary)' }}>
                    עדיין אין התחייבויות בתקציב
                  </h2>
                  <p className="leading-relaxed responsive-xs:text-sm" style={{ color: 'var(--text-secondary)' }}>
                    רק ספקים בסטטוס 'התחייב' נכנסים לתקציב.
                  </p>
                </div>

                <Button 
                  variant="outline"
                  onClick={() => window.dispatchEvent(new CustomEvent('navigate', { detail: 'suppliers' }))}
                  className="focus-ring responsive-xs:min-h-[48px] responsive-md:min-h-[44px] responsive-xs:w-full responsive-md:w-auto"
                >
                  <span className="ml-2">הוספת ספק ראשון</span>
                  <ArrowRight size={16} />
                </Button>
              </CardContent>
            </Card>
          ) : (
            /* Budget Breakdown */
            <div className="space-y-6">
              <Card>
                <CardHeader className="pb-4">
                  <CardTitle className="responsive-xs:text-lg responsive-md:text-xl">פירוט קטגוריות</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {/* Vendors list */}
                    {Array.from({ length: 8 }, (_, i) => i + 1)
                      .filter(vendorNum => {
                        const visible = suppliersVars[`vendor${vendorNum}_visible`];
                        const status = suppliersVars[`vendor${vendorNum}_status`];
                        return visible && status === 'התחייב';
                      })
                      .map(vendorNum => {
                        const name = suppliersVars[`vendor${vendorNum}_name`] || `ספק ${vendorNum}`;
                        const category = suppliersVars[`vendor${vendorNum}_category`] || 'כללי';
                        const total = suppliersVars[`vendor${vendorNum}_totalForecast`] || 0;
                        const deposit = suppliersVars[`vendor${vendorNum}_deposit`] || 0;
                        const remaining = total - deposit;

                        return (
                          <div key={vendorNum} className="card p-4">
                            <div className="flex flex-col responsive-md:flex-row responsive-md:items-center responsive-md:justify-between gap-3">
                              <div className="flex-1">
                                <h3 className="font-medium mb-1 responsive-xs:text-sm responsive-md:text-base" style={{ color: 'var(--text-primary)' }}>
                                  {name}
                                </h3>
                                <p className="text-sm responsive-xs:text-xs" style={{ color: 'var(--text-secondary)' }}>
                                  {category}
                                </p>
                              </div>
                              <div className="text-right responsive-md:text-left">
                                <p className="font-semibold responsive-xs:text-sm responsive-md:text-base" style={{ color: 'var(--text-primary)' }}>
                                  {formatCurrency(total)}
                                </p>
                                {deposit > 0 && (
                                  <div className="text-sm responsive-xs:text-xs mt-1" style={{ color: 'var(--text-muted)' }}>
                                    <div className="responsive-xs:flex responsive-xs:justify-between responsive-md:block responsive-xs:space-x-4 responsive-md:space-x-0">
                                      <span>שולם: {formatCurrency(deposit)}</span>
                                      <span>יתרה: {formatCurrency(remaining)}</span>
                                    </div>
                                  </div>
                                )}
                              </div>
                            </div>
                          </div>
                        );
                      })}
                  </div>
                </CardContent>
              </Card>

              {/* Progress Chart */}
              <Card>
                <CardHeader className="pb-4">
                  <CardTitle className="responsive-xs:text-lg responsive-md:text-xl">התקדמות תשלומים</CardTitle>
                </CardHeader>
                <CardContent className="p-8 responsive-xs:p-6 text-center">
                  <div className="w-32 h-32 responsive-xs:w-24 responsive-xs:h-24 mx-auto rounded-full border-8 flex items-center justify-center mb-4"
                       style={{borderColor: 'var(--border-subtle)'}}>
                    <div className="text-center">
                      <div className="text-2xl responsive-xs:text-xl font-bold" style={{ color: 'var(--text-primary)' }}>
                        {Math.round((budgetVars.forecastTotal / (budgetVars.targetExact || budgetVars.targetMin || 1)) * 100)}%
                      </div>
                      <div className="text-xs responsive-xs:text-xs" style={{ color: 'var(--text-muted)' }}>
                        מהיעד
                      </div>
                    </div>
                  </div>
                  <p className="responsive-xs:text-sm" style={{ color: 'var(--text-secondary)' }}>
                    {formatCurrency(budgetVars.forecastTotal)} מתוך {formatCurrency(budgetVars.targetExact || budgetVars.targetMin)}
                  </p>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};