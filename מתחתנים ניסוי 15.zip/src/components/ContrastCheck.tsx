import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { CheckCircle, AlertTriangle, Info } from 'lucide-react';

interface ContrastTest {
  name: string;
  foreground: string;
  background: string;
  expectedRatio: number;
  actualRatio: number;
  passes: boolean;
  isLargeText?: boolean;
}

// Calculate contrast ratio between two colors
function getLuminance(r: number, g: number, b: number): number {
  const [rs, gs, bs] = [r, g, b].map(c => {
    c = c / 255;
    return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
  });
  return 0.2126 * rs + 0.7152 * gs + 0.0722 * bs;
}

function hexToRgb(hex: string): { r: number; g: number; b: number } | null {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return result ? {
    r: parseInt(result[1], 16),
    g: parseInt(result[2], 16),
    b: parseInt(result[3], 16)
  } : null;
}

function getContrastRatio(color1: string, color2: string): number {
  const rgb1 = hexToRgb(color1);
  const rgb2 = hexToRgb(color2);
  
  if (!rgb1 || !rgb2) return 1;
  
  const lum1 = getLuminance(rgb1.r, rgb1.g, rgb1.b);
  const lum2 = getLuminance(rgb2.r, rgb2.g, rgb2.b);
  
  const lightest = Math.max(lum1, lum2);
  const darkest = Math.min(lum1, lum2);
  
  return (lightest + 0.05) / (darkest + 0.05);
}

export function ContrastCheck() {
  const tests: ContrastTest[] = [
    {
      name: 'Primary CTA (white on brand.primary)',
      foreground: '#FFFFFF',
      background: '#0B2F6A',
      expectedRatio: 4.5,
      actualRatio: getContrastRatio('#FFFFFF', '#0B2F6A'),
      passes: getContrastRatio('#FFFFFF', '#0B2F6A') >= 4.5,
    },
    {
      name: 'Text on soft background (text.primary on brand.secondarySoft)',
      foreground: '#111111',
      background: '#EEF2F6',
      expectedRatio: 4.5,
      actualRatio: getContrastRatio('#111111', '#EEF2F6'),
      passes: getContrastRatio('#111111', '#EEF2F6') >= 4.5,
    },
    {
      name: 'White on semantic.info',
      foreground: '#FFFFFF',
      background: '#1570EF',
      expectedRatio: 4.5,
      actualRatio: getContrastRatio('#FFFFFF', '#1570EF'),
      passes: getContrastRatio('#FFFFFF', '#1570EF') >= 4.5,
    },
    {
      name: 'White on semantic.success',
      foreground: '#FFFFFF',
      background: '#198754',
      expectedRatio: 4.5,
      actualRatio: getContrastRatio('#FFFFFF', '#198754'),
      passes: getContrastRatio('#FFFFFF', '#198754') >= 4.5,
    },
    {
      name: 'White on semantic.warning',
      foreground: '#FFFFFF',
      background: '#B54708',
      expectedRatio: 4.5,
      actualRatio: getContrastRatio('#FFFFFF', '#B54708'),
      passes: getContrastRatio('#FFFFFF', '#B54708') >= 4.5,
    },
    {
      name: 'White on semantic.error',
      foreground: '#FFFFFF',
      background: '#B42318',
      expectedRatio: 4.5,
      actualRatio: getContrastRatio('#FFFFFF', '#B42318'),
      passes: getContrastRatio('#FFFFFF', '#B42318') >= 4.5,
    },
    {
      name: 'Border on white (border.subtle on base.white)',
      foreground: '#7A8699',
      background: '#FFFFFF',
      expectedRatio: 3.0,
      actualRatio: getContrastRatio('#7A8699', '#FFFFFF'),
      passes: getContrastRatio('#7A8699', '#FFFFFF') >= 3.0,
    },
    {
      name: 'Secondary text (text.secondary on base.white)',
      foreground: '#333333',
      background: '#FFFFFF',
      expectedRatio: 4.5,
      actualRatio: getContrastRatio('#333333', '#FFFFFF'),
      passes: getContrastRatio('#333333', '#FFFFFF') >= 4.5,
    },
    {
      name: 'Large text on brand.primary (20px+)',
      foreground: '#FFFFFF',
      background: '#0B2F6A',
      expectedRatio: 3.0,
      actualRatio: getContrastRatio('#FFFFFF', '#0B2F6A'),
      passes: getContrastRatio('#FFFFFF', '#0B2F6A') >= 3.0,
      isLargeText: true,
    },
  ];

  const getComplianceLevel = (ratio: number, isLargeText = false): string => {
    const aaRequirement = isLargeText ? 3.0 : 4.5;
    const aaaRequirement = isLargeText ? 4.5 : 7.0;
    
    if (ratio >= aaaRequirement) return 'AAA';
    if (ratio >= aaRequirement) return 'AA';
    return 'FAIL';
  };

  return (
    <div className="space-y-6 p-6 max-w-4xl mx-auto">
      <div className="text-center space-y-2">
        <h1>בדיקת קונטרסט - WCAG 2.2</h1>
        <p className="text-muted-foreground">
          וידוא עמידה בתקני נגישות לכל צירופי הצבעים במערכת
        </p>
      </div>

      <div className="grid gap-4">
        {tests.map((test, index) => (
          <Card key={index} className={`${!test.passes ? 'border-destructive' : ''}`}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  {test.passes ? (
                    <CheckCircle className="w-5 h-5 text-success" />
                  ) : (
                    <AlertTriangle className="w-5 h-5 text-destructive" />
                  )}
                  <span className="font-medium">{test.name}</span>
                  {test.isLargeText && (
                    <Badge variant="outline" className="text-xs">
                      טקסט גדול
                    </Badge>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  <Badge 
                    variant={test.passes ? "default" : "destructive"}
                    className={test.passes ? "bg-success text-white" : ""}
                  >
                    {getComplianceLevel(test.actualRatio, test.isLargeText)}
                  </Badge>
                  <span className="text-sm text-muted-foreground">
                    {test.actualRatio.toFixed(2)}:1
                  </span>
                </div>
              </div>
              
              <div className="flex items-center gap-4">
                <div 
                  className="w-16 h-12 rounded border flex items-center justify-center text-sm font-medium"
                  style={{ 
                    backgroundColor: test.background,
                    color: test.foreground,
                  }}
                >
                  טקסט
                </div>
                <div className="flex-1 space-y-1">
                  <div className="text-sm">
                    <span className="text-muted-foreground">רקע:</span> {test.background}
                    <span className="text-muted-foreground mx-2">|</span>
                    <span className="text-muted-foreground">טקסט:</span> {test.foreground}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    נדרש: {test.expectedRatio}:1 לרמת AA
                    {test.isLargeText && ' (טקסט גדול)'}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Summary */}
      <Card className="bg-secondary/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Info className="w-5 h-5 text-primary" />
            סיכום בדיקת נגישות
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
            <div>
              <div className="text-2xl font-semibold text-success">
                {tests.filter(t => t.passes).length}
              </div>
              <div className="text-sm text-muted-foreground">עברו בהצלחה</div>
            </div>
            <div>
              <div className="text-2xl font-semibold text-destructive">
                {tests.filter(t => !t.passes).length}
              </div>
              <div className="text-sm text-muted-foreground">נכשלו</div>
            </div>
            <div>
              <div className="text-2xl font-semibold">
                {tests.filter(t => getComplianceLevel(t.actualRatio, t.isLargeText) === 'AAA').length}
              </div>
              <div className="text-sm text-muted-foreground">ברמת AAA</div>
            </div>
          </div>
          
          <div className="mt-4 p-3 bg-background rounded-lg">
            <p className="text-sm text-muted-foreground">
              <strong>הסבר רמות תקן:</strong>
            </p>
            <ul className="text-sm text-muted-foreground mt-2 space-y-1">
              <li>• <strong>AA:</strong> רמה נדרשת לאתרים ציבוריים (4.5:1 טקסט רגיל, 3:1 טקסט גדול)</li>
              <li>• <strong>AAA:</strong> רמה מתקדמת לנגישות מיטבית (7:1 טקסט רגיל, 4.5:1 טקסט גדול)</li>
              <li>• <strong>אלמנטים לא-טקסטואליים:</strong> נדרש יחס של 3:1 לגבולות ואייקונים</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}