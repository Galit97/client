import React from 'react';
import { Button } from './ui/button';

interface SettingsProps {
  onNavigate: (screen: string) => void;
}

export function Settings({ onNavigate }: SettingsProps) {
  return (
    <div className="min-h-screen" style={{backgroundColor: '#FFFFFF'}} dir="rtl">
      {/* Header Band - Sky.50 with responsive sparkles */}
      <div style={{backgroundColor: '#EFF5FB'}} className="relative">
        <div className="section-header-suppliers">
          <div className="flex items-center justify-center px-4 py-6 responsive-md:px-6 responsive-lg:px-8 relative z-10">
            <div className="text-center relative">
              <h1 className="section-title text-primary">
                הגדרות
              </h1>
              {/* Decorative sparkles positioned away from text baseline */}
              <div
                className="absolute -top-1 -left-4 w-1.5 h-1.5 rotate-45 opacity-45"
                style={{ backgroundColor: "#89B3E0" }}
              ></div>
              <div
                className="absolute top-0 -right-6 w-2 h-2 rotate-45 opacity-40"
                style={{ backgroundColor: "#F7D7A3" }}
              ></div>
              <div
                className="absolute -bottom-1 left-8 w-1 h-1 rotate-45 opacity-50"
                style={{ backgroundColor: "#89B3E0" }}
              ></div>
            </div>
          </div>
        </div>
      </div>

      <div className="px-4 py-6 responsive-md:px-6 responsive-lg:px-8">
        <div className="max-w-2xl mx-auto">
          <div className="grid gap-6">
            
            {/* Members & Permissions Card */}
            <div
              className="card cursor-pointer hover:shadow-lg transition-all duration-200"
              onClick={() => onNavigate("members-permissions")}
            >
              <div className="p-6 responsive-xs:p-4 text-center" dir="rtl">
                <div
                  className="w-16 h-16 responsive-xs:w-12 responsive-xs:h-12 mx-auto rounded-full flex items-center justify-center mb-4 transition-all duration-300 hover:scale-110"
                  style={{
                    backgroundColor: "var(--surface-sky-50)",
                  }}
                >
                  <svg
                    className="w-8 h-8 responsive-xs:w-6 responsive-xs:h-6"
                    style={{ color: "var(--accent-sky)" }}
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={1.5}
                      d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197m13.5-9a2.25 2.25 0 11-4.5 0 2.25 2.25 0 014.5 0z"
                    />
                  </svg>
                </div>
                <h3
                  className="mb-3 responsive-xs:text-lg responsive-md:text-xl"
                  style={{ color: "var(--text-primary)" }}
                >
                  שותפים והרשאות
                </h3>
                <p
                  className="responsive-xs:text-sm responsive-md:text-base"
                  style={{ color: "var(--text-secondary)" }}
                >
                  נהלו מוזמנים, הזמנות וגישות לחברי הצוות
                </p>
              </div>
            </div>

            {/* General Settings (Coming Soon) */}
            <div className="card opacity-50">
              <div
                className="p-6 responsive-xs:p-4 text-center space-y-4"
                dir="rtl"
              >
                <div
                  className="w-16 h-16 responsive-xs:w-12 responsive-xs:h-12 mx-auto rounded-full flex items-center justify-center transition-all duration-300 hover:scale-105 hover:rotate-6"
                  style={{
                    backgroundColor: "var(--surface-gold-50)",
                  }}
                >
                  <svg
                    className="w-8 h-8 responsive-xs:w-6 responsive-xs:h-6 transition-all duration-220"
                    style={{
                      color: "var(--accent-gold)",
                      transitionTimingFunction: "cubic-bezier(.2,.8,.2,1)",
                    }}
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"
                    />
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"
                    />
                  </svg>
                </div>
                <h3
                  className="responsive-xs:text-lg responsive-md:text-xl"
                  style={{ color: "var(--text-primary)" }}
                >
                  הגדרות כלליות
                </h3>
                <p
                  className="responsive-xs:text-sm responsive-md:text-base"
                  style={{ color: "var(--text-muted)" }}
                >
                  מודול בקרוב...
                </p>
                <div
                  className="p-4 rounded-lg transition-all duration-300 hover:scale-[1.02]"
                  style={{
                    color: "var(--text-muted)",
                    backgroundColor: "rgba(30,90,120,0.06)",
                    fontSize: "var(--text-meta)",
                    border: "1px solid rgba(167,199,231,0.2)",
                  }}
                >
                  <div className="responsive-xs:text-xs responsive-md:text-sm">
                    יכלול: העדפות אישיות, התראות, גיבויים
                  </div>
                </div>
              </div>
            </div>

            {/* Data & Export (Coming Soon) */}
            <div className="card opacity-50">
              <div
                className="p-6 responsive-xs:p-4 text-center space-y-4"
                dir="rtl"
              >
                <div
                  className="w-16 h-16 responsive-xs:w-12 responsive-xs:h-12 mx-auto rounded-full flex items-center justify-center transition-all duration-300 hover:scale-105"
                  style={{
                    backgroundColor: "var(--surface-sage-50)",
                  }}
                >
                  <svg
                    className="w-8 h-8 responsive-xs:w-6 responsive-xs:h-6"
                    style={{ color: "var(--accent-sage)" }}
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                    />
                  </svg>
                </div>
                <h3
                  className="responsive-xs:text-lg responsive-md:text-xl"
                  style={{ color: "var(--text-primary)" }}
                >
                  נתונים וייצוא
                </h3>
                <p
                  className="responsive-xs:text-sm responsive-md:text-base"
                  style={{ color: "var(--text-muted)" }}
                >
                  מודול בקרוב...
                </p>
                <div
                  className="p-4 rounded-lg transition-all duration-300 hover:scale-[1.02]"
                  style={{
                    color: "var(--text-muted)",
                    backgroundColor: "rgba(30,90,120,0.06)",
                    fontSize: "var(--text-meta)",
                    border: "1px solid rgba(167,199,231,0.2)",
                  }}
                >
                  <div className="responsive-xs:text-xs responsive-md:text-sm">
                    יכלול: גיבוי נתונים, ייצוא לקובץ, מחיקת חשבון
                  </div>
                </div>
              </div>
            </div>

            {/* Support & Help */}
            <div className="card">
              <div
                className="p-6 responsive-xs:p-4 text-center space-y-4"
                dir="rtl"
              >
                <div
                  className="w-16 h-16 responsive-xs:w-12 responsive-xs:h-12 mx-auto rounded-full flex items-center justify-center transition-all duration-300 hover:scale-105"
                  style={{
                    backgroundColor: "var(--surface-rose-50)",
                  }}
                >
                  <svg
                    className="w-8 h-8 responsive-xs:w-6 responsive-xs:h-6"
                    style={{ color: "var(--accent-rose)" }}
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                    />
                  </svg>
                </div>
                <h3
                  className="responsive-xs:text-lg responsive-md:text-xl"
                  style={{ color: "var(--text-primary)" }}
                >
                  עזרה ותמיכה
                </h3>
                <p
                  className="responsive-xs:text-sm responsive-md:text-base"
                  style={{ color: "var(--text-secondary)" }}
                >
                  מדריכי שימוש, שאלות נפוצות ותמיכה טכנית
                </p>
                <Button
                  variant="outline"
                  className="responsive-xs:w-full responsive-md:w-auto responsive-xs:min-h-[48px] responsive-md:min-h-[44px]"
                  style={{ color: "var(--text-primary)" }}
                >
                  פתח מרכז עזרה
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}