import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Checkbox } from './ui/checkbox';
import { Separator } from './ui/separator';
import { Alert, AlertDescription } from './ui/alert';
import { Apple, Chrome, Mail, Info } from 'lucide-react';
import { toast } from 'sonner';

interface AuthProps {
  onAuthSuccess: (coupleName?: string) => void;
  onDemoMode: () => void;
}

export function Auth({ onAuthSuccess, onDemoMode }: AuthProps) {
  const [email, setEmail] = useState('');
  const [coupleName, setCoupleName] = useState('');
  const [coupleNameError, setCoupleNameError] = useState('');
  const [agreedToTerms, setAgreedToTerms] = useState(false);
  const [isEmailLoading, setIsEmailLoading] = useState(false);
  const [emailSent, setEmailSent] = useState(false);

  // Couple name validation
  const validateCoupleName = (name: string) => {
    if (!name.trim()) {
      setCoupleNameError('');
      return true; // Optional field
    }

    if (name.length < 2) {
      setCoupleNameError('נא הזינו שם קצר עד 40 תווים');
      return false;
    }

    if (name.length > 40) {
      setCoupleNameError('נא הזינו שם קצר עד 40 תווים');
      return false;
    }

    // Allowed characters: Hebrew/English letters, spaces, &, en/em dash, apostrophe
    const allowedPattern = /^[א-ת\u0590-\u05FF\u200F\u200Ea-zA-Z\s&\-–—']+$/;
    if (!allowedPattern.test(name)) {
      setCoupleNameError('תווים לא נתמכים — נסו אותיות, רווחים, & או מקף');
      return false;
    }

    setCoupleNameError('');
    return true;
  };

  const handleCoupleNameChange = (value: string) => {
    setCoupleName(value);
    validateCoupleName(value);
  };

  const handleAppleSignIn = () => {
    // Mock Apple sign-in
    toast.success('מתחבר עם Apple...');
    setTimeout(() => {
      onAuthSuccess(coupleName.trim() || undefined);
    }, 1500);
  };

  const handleGoogleSignIn = () => {
    // Mock Google sign-in
    toast.success('מתחבר עם Google...');
    setTimeout(() => {
      onAuthSuccess(coupleName.trim() || undefined);
    }, 1500);
  };

  const handleEmailSignIn = async () => {
    if (!email.trim()) {
      toast.error('יש להזין כתובת אימייל');
      return;
    }

    if (!email.includes('@')) {
      toast.error('כתובת אימייל לא תקינה');
      return;
    }

    if (!agreedToTerms) {
      toast.error('יש להסכים לתנאים ולמדיניות הפרטיות');
      return;
    }

    // Validate couple name if provided
    if (coupleName.trim() && !validateCoupleName(coupleName)) {
      return;
    }

    setIsEmailLoading(true);
    
    // Mock email magic link sending
    setTimeout(() => {
      setIsEmailLoading(false);
      setEmailSent(true);
      toast.success('קישור כניסה נשלח לאימייל');
    }, 2000);
  };

  const handleDemoClick = () => {
    toast.info('פותח מצב תצוגה בלבד');
    onDemoMode();
  };

  if (emailSent) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <div className="w-full max-w-md space-y-6">
          <div className="text-center space-y-4">
            <div className="w-16 h-16 bg-secondary rounded-full flex items-center justify-center mx-auto">
              <Mail className="w-8 h-8 text-primary" />
            </div>
            <div>
              <h1>קישור נשלח!</h1>
              <p className="text-muted-foreground mt-2">
                בדקו את תיבת המייל שלכם ולחצו על הקישור להתחברות
              </p>
            </div>
          </div>

          <Alert className="border-info bg-info/5">
            <Info className="h-4 w-4 text-info" />
            <AlertDescription className="text-info">
              הקישור תקף ל-15 דקות בלבד
            </AlertDescription>
          </Alert>

          <div className="space-y-4">
            <Button 
              variant="outline" 
              onClick={() => setEmailSent(false)}
              className="w-full min-h-[44px] focus:ring-2 focus:ring-primary"
            >
              שלחו שוב
            </Button>
            
            <div className="text-center">
              <button
                onClick={handleDemoClick}
                className="text-sm text-muted-foreground hover:text-foreground transition-colors focus:ring-2 focus:ring-primary focus:outline-none rounded px-2 py-1"
              >
                להצצה בלי חשבון
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-md space-y-8">
        {/* Header */}
        <div className="text-center">
          <h1>ברוכים הבאים</h1>
          <p className="text-muted-foreground mt-2">
            תכננו את החתונה שלכם בקלות ובפשטות
          </p>
        </div>

        {/* Social Sign-in Buttons */}
        <div className="space-y-4">
          <Button
            onClick={handleAppleSignIn}
            className="w-full min-h-[44px] bg-foreground hover:bg-foreground/90 text-background focus:ring-2 focus:ring-primary"
          >
            <Apple className="w-5 h-5 ml-3" />
            התחברות עם Apple
          </Button>

          <Button
            onClick={handleGoogleSignIn}
            variant="outline"
            className="w-full min-h-[44px] focus:ring-2 focus:ring-primary"
          >
            <Chrome className="w-5 h-5 ml-3" />
            התחברות עם Google
          </Button>
        </div>

        {/* Divider */}
        <div className="relative">
          <div className="absolute inset-0 flex items-center">
            <Separator className="w-full" />
          </div>
          <div className="relative flex justify-center text-xs uppercase">
            <span className="bg-background px-2 text-muted-foreground">או</span>
          </div>
        </div>

        {/* Email Option */}
        <div className="space-y-4">
          <div>
            <Label htmlFor="email">אימייל</Label>
            <Input
              id="email"
              type="email"
              inputMode="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="example@email.com"
              className="min-h-[44px] focus:ring-2 focus:ring-primary"
              dir="ltr"
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  handleEmailSignIn();
                }
              }}
            />
          </div>

          {/* Couple Name Field */}
          <div>
            <Label htmlFor="coupleName">שם הזוג (אופציונלי)</Label>
            <Input
              id="coupleName"
              type="text"
              value={coupleName}
              onChange={(e) => handleCoupleNameChange(e.target.value)}
              placeholder="למשל: נועה & תומר"
              className={`min-h-[44px] focus:ring-2 focus:ring-primary text-right ${
                coupleNameError ? 'border-destructive focus:ring-destructive' : ''
              }`}
              dir="rtl"
            />
            {coupleNameError && (
              <p className="text-sm text-destructive mt-1 text-right">
                {coupleNameError}
              </p>
            )}
          </div>

          <Button
            onClick={handleEmailSignIn}
            disabled={isEmailLoading}
            className="w-full min-h-[44px] focus:ring-2 focus:ring-primary"
          >
            {isEmailLoading ? (
              <>
                <div className="w-4 h-4 border-2 border-primary-foreground border-t-transparent rounded-full animate-spin ml-2" />
                שולח קישור...
              </>
            ) : (
              <>
                <Mail className="w-4 h-4 ml-2" />
                שלחו קישור כניסה
              </>
            )}
          </Button>
        </div>

        {/* Terms Checkbox */}
        <div className="flex items-start space-x-2 space-x-reverse">
          <Checkbox
            id="terms"
            checked={agreedToTerms}
            onCheckedChange={(checked) => setAgreedToTerms(checked as boolean)}
            className="mt-1 focus:ring-2 focus:ring-primary"
          />
          <div className="grid gap-1.5 leading-none">
            <Label
              htmlFor="terms"
              className="text-sm cursor-pointer"
            >
              אני מסכים/ה ל
              <button
                onClick={() => toast.info('תנאי השירות יפתחו כאן')}
                className="text-primary hover:underline focus:ring-2 focus:ring-primary focus:outline-none rounded mx-1"
              >
                תנאים
              </button>
              ול
              <button
                onClick={() => toast.info('מדיניות הפרטיות תפתח כאן')}
                className="text-primary hover:underline focus:ring-2 focus:ring-primary focus:outline-none rounded mx-1"
              >
                מדיניות הפרטיות
              </button>
            </Label>
          </div>
        </div>

        {/* Demo Link */}
        <div className="text-center">
          <button
            onClick={handleDemoClick}
            className="text-sm text-muted-foreground hover:text-foreground transition-colors focus:ring-2 focus:ring-primary focus:outline-none rounded px-2 py-1"
          >
            להצצה בלי חשבון
          </button>
        </div>
      </div>
    </div>
  );
}