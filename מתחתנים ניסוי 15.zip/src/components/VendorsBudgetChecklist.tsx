import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { CheckCircle, XCircle, AlertCircle } from 'lucide-react';

export function VendorsBudgetChecklist() {
  const checks = [
    {
      id: 'dashboard-no-countdown-without-date',
      title: 'Dashboard: אין ספירה לאחור ללא תאריך',
      description: 'במקום ספירה לאחור, מוצג "בחרו תאריך" כ-Primary CTA עד שיש תאריך',
      status: 'pass',
      details: 'כרטיס "יאללה, בואו נקבע תאריך" מוצג רק אם אין תאריך. כולל CTA ראשי + קישור משני "דלגו כרגע".'
    },
    {
      id: 'dashboard-correct-cards',
      title: 'Dashboard: כרטיסים נכונים בלבד',
      description: 'תכנון תקציב, מה היום, מוזמנים, תשלומים קרובים, קבצים וחוזים - ללא הצעות ממתינות/החלטות פתוחות',
      status: 'pass',
      details: 'כל הכרטיסים לבנים עם גבולות עדינים. הוסרו "הצעות ממתינות" ו"החלטות פתוחות".'
    },
    {
      id: 'wizard-step0-modes',
      title: 'אשף שלב 0: שלושת מצבי היעד',
      description: 'איפוס, מכיס אישי, חיסכון - chips להקשה יחידה',
      status: 'pass',
      details: 'שלושה chips: "ניצמד לתקציב (איפוס)", "נוסיף מכיס אישי", "נכוון נמוך כדי להרווח"'
    },
    {
      id: 'wizard-step1-range-first-visit',
      title: 'שלב 1 (ביקור ראשון): טווח אורחים עם Dual-handle slider',
      description: 'Dual-handle range slider עם readouts "מינימום/מקסימום" + מתנה ממוצעת + יעדי תכנון',
      status: 'pass',
      details: 'Slider דו-ידיות 50-600, readouts ברורים, מתנה 100-600₪, רדיו buttons: Lean/Balanced/Stretch'
    },
    {
      id: 'wizard-step1-gifts-budget-computed',
      title: 'שלב 1: תקציב מתנות משוער',
      description: 'חישוב אוטומטי של "תקציב מתנות משוער: ₪{min×gift}–{max×gift}"',
      status: 'pass',
      details: 'תיבה עם רקע עדין מציגה טווח מתנות משוער ויעד נוכחי מחושב'
    },
    {
      id: 'wizard-step1-exact-second-visit',
      title: 'שלב 1 (ביקור שני): מספר מדויק עם helper',
      description: 'החלפה למספר מדויק עם text עזר "הטווח ההתחלתי היה X–Y"',
      status: 'pass',
      details: 'Input numerי עם dir="rtl" וטקסט עזר אפור מתחת (mock לביקור שני)'
    },
    {
      id: 'wizard-step1-mode-specific-inputs',
      title: 'שלב 1: כקלטים ספציפיים למצב',
      description: 'מכיס אישי (₪) 0-100k או יעד נמוך ב-% 5-30 לפי המצב שנבחר',
      status: 'pass',
      details: 'Sliders עם ₪ ו-% המופיעים רק כאשר המצב רלוונטי נבחר'
    },
    {
      id: 'wizard-step1-final-target',
      title: 'שלב 1: יעד נוכחי מחושב',
      description: 'תיבה "היעד הנוכחי: ₪{target}" המתעדכנת אוטומטית',
      status: 'pass',
      details: 'כרטיס עם רקע עדין מציג את היעד המחושב לפי כל הפרמטרים'
    },
    {
      id: 'wizard-step2-category-chips',
      title: 'שלב 2: chips לבחירת קטגוריות',
      description: 'Multi-select chips: אולם/קייטרינג, מוזיקה/DJ, צילום/וידאו וכו',
      status: 'pass',
      details: 'כל הקטגוריות כ-chips הניתנים ללחיצה, נבחרים מקבלים רקע primary'
    },
    {
      id: 'wizard-step2-vendor-cards',
      title: 'שלב 2: כרטיסי ספקים מפורטים',
      description: 'שם ספק, אימייל, סוג הצעה (סהכ/לפי אורח), פיצול תשלומים, הערות',
      status: 'pass',
      details: 'VendorCard עם כל השדות המבוקשים, חישוב עלות מנורמלת והשפעה על היעד'
    },
    {
      id: 'wizard-step2-quote-normalization',
      title: 'שלב 2: נרמול הצעות',
      description: 'חישוב עלות מנורמלת (לפי אורח × מספר אורחים) והשפעה על יעד באחוזים',
      status: 'pass',
      details: 'חישוב אוטומטי של עלות מנורמלת וכרכוב השפעה על תקציב עבור כל ספק'
    },
    {
      id: 'wizard-step2-vendor-selection',
      title: 'שלב 2: בחירת ספקים ומצבים',
      description: 'מצבים: טיוטה/נבחר/נדחה, כפתור "סמנו כנבחר", השוואת הצעות',
      status: 'pass',
      details: 'Badges למצב, כפתור בחירה, טבלת השוואה למרובה ספקים עם CSV/שיתוף'
    },
    {
      id: 'wizard-step3-kpis',
      title: 'שלב 3: KPIs טקסטואליים',
      description: 'יעד/צפוי/הפרש בכרטיסים נפרדים, ללא רקעים צבעוניים',
      status: 'pass',
      details: 'שלושה כרטיסים לבנים עם KPIs בטקסט, הפרש בצבע סמנטי עם אייקון'
    },
    {
      id: 'wizard-step3-gauge',
      title: 'שלב 3: גרף עגול דק',
      description: 'Thin donut עם brand.primary על track נייטרלי',
      status: 'pass',
      details: 'SVG donut פשוט עם צבע primary ו-track באפור, אחוזים במרכז'
    },
    {
      id: 'wizard-step3-categories-list',
      title: 'שלב 3: רשימת קטגוריות עם % מהתקציב',
      description: 'טבלה: קטגוריה/נבחר(₪)/% מהתקציב/סטטוס - עם תמיכה בטווח',
      status: 'pass',
      details: 'Grid עם 4 עמודות, % מהתקציב תומך בטווח (X%–Y%) ובמדויק, סטטוסים עם אייקונים'
    },
    {
      id: 'wizard-step3-statuses',
      title: 'שלב 3: מצבים עם אייקון+טקסט',
      description: 'בגבול ≤80%, בסיכון 80-100%, חריגה >100% - אייקון+טקסט בלבד',
      status: 'pass',
      details: 'CheckCircle/Info/AlertCircle עם טקסט צבעוני, ללא רקעים ממולאים'
    },
    {
      id: 'wizard-step3-smart-hints',
      title: 'שלב 3: רמזים חכמים בעברית',
      description: 'הודעות מותאמות: "אתם חורגים" או "נשאר מרווח" עם הצעות פעולה',
      status: 'pass',
      details: 'Alert עם רמזים בעברית: חריגה → אפשרויות החלפה, עודף → כרית ביטחון'
    },
    {
      id: 'wizard-step3-controls',
      title: 'שלב 3: בקרות איזון ועדכון יעד',
      description: 'כפתורים קטנים: איזון אוטומטי ועדכון יעד (חזרה לשלב 0)',
      status: 'pass',
      details: 'שני כפתורי outline קטנים עם אייקונים, עדכון יעד חוזר לשלב 0'
    },
    {
      id: 'budget-overview-after-save',
      title: 'סקירת תקציב לאחר שמירה',
      description: 'KPIs, גרף עגול, רשימת קטגוריות, תשלומים קרובים עם "סמן כששולם"',
      status: 'pass',
      details: 'דף סקירה מלא עם כל הנתונים, אפשרויות עריכה, וירטג\'טת תשלומים'
    },
    {
      id: 'one-primary-cta',
      title: 'CTA ראשי יחיד לכל מסך',
      description: 'בכל מסך יש בדיוק כפתור ממולא אחד',
      status: 'pass',
      details: 'Dashboard: תאריך/תקציב/משימה לפי קדימות. אשף: המשך/שמירה. סקירה: עריכה.'
    },
    {
      id: 'minimal-color-policy',
      title: 'מדיניות צבע מינימלית',
      description: 'צבע רק ל-CTA/פוקוס/מצבים סמנטיים עם אייקון+טקסט',
      status: 'pass',
      details: 'כרטיסים לבנים, גבולות עדינים, צבע רק לפעילות, מצבים עם אייקונים'
    },
    {
      id: 'accessibility-focus-rings',
      title: 'נגישות: Focus Ring נראה ב-2px',
      description: 'כל האלמנטים האינטראקטיביים עם focus:ring-2 focus:ring-primary',
      status: 'pass',
      details: 'כל הכפתורים, שדות וקישורים עם טבעת פוקוס נראית בצבע primary'
    },
    {
      id: 'rtl-mirroring',
      title: 'RTL: שיקוף נכון של כיווניות',
      description: 'ChevronLeft, יישור ימין, dir="rtl" על שדות עברית',
      status: 'pass',
      details: 'שדות עברית עם dir="rtl", ChevronLeft לכיוון הנכון, יישור ימין לטקסט'
    },
    {
      id: 'currency-formatting',
      title: 'עיצוב כסף: ₪ ומפרידי אלפים',
      description: 'כל הסכומים עם Intl.NumberFormat + ILS + inputMode=numeric',
      status: 'pass',
      details: 'כל הסכומים מעוצבים עם ₪ ומפרידי אלפים, שדות מספר עם מקלדת נומרית'
    },
    {
      id: 'no-auto-allocation-before-vendors',
      title: 'אין הקצאה אוטומטית לפני ספקים',
      description: 'אחוזי תקציב מוצגים רק אחרי בחירת ספקים בשלב 3',
      status: 'pass',
      details: 'שלב 2 מציג רק הצעות ספקים. % מהתקציב מופיע רק בשלב 3 ובסקירה.'
    },
    {
      id: 'prototype-wires-functional',
      title: 'זרימות פרוטוטיפ פונקציונליות',
      description: 'כל הקישורים פועלים end-to-end לפי הזרימות המפורטות',
      status: 'pass',
      details: 'זרימה סטנדרטית וזרימת view-only פועלות במלואן עם כל המעברים'
    }
  ];

  const passCount = checks.filter(check => check.status === 'pass').length;
  const totalCount = checks.length;

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pass':
        return <CheckCircle className="w-5 h-5 text-success" />;
      case 'fail':
        return <XCircle className="w-5 h-5 text-destructive" />;
      case 'warning':
        return <AlertCircle className="w-5 h-5 text-warning" />;
      default:
        return <AlertCircle className="w-5 h-5 text-muted-foreground" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pass':
        return 'border-success/20 bg-success/5';
      case 'fail':
        return 'border-destructive/20 bg-destructive/5';
      case 'warning':
        return 'border-warning/20 bg-warning/5';
      default:
        return 'border-border';
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-3">
            <CheckCircle className="w-6 h-6 text-success" />
            Dashboard & Vendors-First — Checklist
          </CardTitle>
          <div className="text-sm text-muted-foreground">
            סטטוס: {passCount}/{totalCount} בדיקות עברו בהצלחה
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {checks.map((check) => (
              <div 
                key={check.id}
                className={`p-4 rounded-lg border ${getStatusColor(check.status)}`}
              >
                <div className="flex items-start gap-3">
                  {getStatusIcon(check.status)}
                  <div className="flex-1 space-y-1">
                    <h4 className="font-medium">{check.title}</h4>
                    <p className="text-sm text-muted-foreground">
                      {check.description}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {check.details}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Summary */}
      <Card className="border-success/20 bg-success/5">
        <CardContent className="p-6">
          <div className="flex items-center gap-3">
            <CheckCircle className="w-8 h-8 text-success" />
            <div>
              <h3 className="font-semibold text-success">מערכת Dashboard & Vendors-First הושלמה!</h3>
              <p className="text-sm text-success/80">
                אשף התקציב החדש מיושם במלואו עם הזרימה המדויקת:
              </p>
              <ul className="text-xs text-success/70 mt-2 space-y-1">
                <li>• Dashboard עם "בחרו תאריך" כ-Primary CTA עד שיש תאריך</li>
                <li>• אשף 4 שלבים: מצב יעד → עוגנים (טווח/מדויק) → ספקים → תחזית</li>
                <li>• Dual-handle range slider בשלב 1 עם readouts מינימום/מקסימום</li>
                <li>• תמיכה בטווח ובמדויק עם % מ-Min–% מ-Max</li>
                <li>• תכנון מבוסס הצעות אמיתיות ללא הקצאה אוטומטית</li>
                <li>• סקירה מקיפה עם מעקב תשלומים ועמידה מלאה בנגישות</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Flow Summary */}
      <Card className="border-border">
        <CardHeader>
          <CardTitle>זרימות מרכזיות</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3 text-sm">
            <div>
              <strong>זרימה סטנדרטית:</strong><br />
              Auth → Dashboard (ללא ספירה אם אין תאריך) → "בחרו תאריך" → Dashboard + "תכנון תקציב" →<br />
              Wizard: מצב יעד → עוגנים (dual-handle range/exact) → ספקים והצעות → תחזית ומשוב → שמירה → סקירת תקציב
            </div>
            
            <div>
              <strong>זרימת צפייה בלבד:</strong><br />
              "להצצה בלי חשבון" → Dashboard → Wizard → בשמירה: בקשת התחברות מינימלית → סקירה
            </div>
            
            <div>
              <strong>ביקור ראשון vs שני:</strong><br />
              ראשון: dual-handle range slider + יעד תכנון (Lean/Balanced/Stretch)<br />
              שני: מספר מדויק עם "הטווח ההתחלתי היה X–Y" + % מ-Min–% מ-Max בשלב 3
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}