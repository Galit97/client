import React, { useEffect, useMemo, useState } from "react";
import { InviteRSVP } from "./ui/invite-rsvp";

type Guest = {
  id: string;
  name: string;
  side: "כלה" | "חתן" | "משותף";
  status: "טיוטה" | "נשלחה הזמנה" | "מאשר" | "מסרב" | "אולי";
  phone?: string;
  email?: string;
  count: number;           // מספר מקומות
  diet?: "רגיל" | "צמחוני" | "טבעוני" | "ללא גלוטן" | "אחר";
  group?: string;          // משפחה / חברים / עבודה...
  notes?: string;
};

type RSVPVars = {
  invitedCount: number;
  acceptedCount: number;
  maybeCount: number;
  noReplyCount: number;
  declinedCount: number;
};

type DashVars = {
  tasksTodayCount: number;
  guestsCount: number;
  filesCount: number;
  upcomingPaymentsCount: number;
};

type Props = {
  dashVars: DashVars;
  setDashVars: React.Dispatch<React.SetStateAction<DashVars>>;
  rsvpVars: RSVPVars;
  setRsvpVars: React.Dispatch<React.SetStateAction<RSVPVars>>;
};

const STATUSES: Guest["status"][] = ["טיוטה", "נשלחה הזמנה", "מאשר", "מסרב", "אולי"];
const SIDES: Guest["side"][] = ["כלה", "חתן", "משותף"];

function uid() {
  return Math.random().toString(36).slice(2, 9);
}

export function Guests({ dashVars, setDashVars, rsvpVars, setRsvpVars }: Props) {
  const [guests, setGuests] = useState<Guest[]>([]);
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<Guest["status"] | "הכל">("הכל");
  const [sideFilter, setSideFilter] = useState<Guest["side"] | "הכל">("הכל");
  const [showNewModal, setShowNewModal] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);

  // טעינה/שמירה ל-localStorage — בלי דאטה פיקטיבי
  useEffect(() => {
    try {
      const saved = localStorage.getItem("guests");
      if (saved) setGuests(JSON.parse(saved));
    } catch {}
  }, []);
  useEffect(() => {
    try {
      localStorage.setItem("guests", JSON.stringify(guests));
    } catch {}
  }, [guests]);

  // עדכון מונה בדשבורד בכל שינוי רשימה
  useEffect(() => {
    setDashVars((prev) => ({ ...prev, guestsCount: guests.length }));
  }, [guests, setDashVars]);

  // עדכון RSVP vars בכל שינוי
  useEffect(() => {
    const invited = guests.length;
    const accepted = guests.filter((g) => g.status === "מאשר").length;
    const maybe = guests.filter((g) => g.status === "אולי").length;
    const noReply = guests.filter((g) => g.status === "טיוטה" || g.status === "נשלחה הזמנה").length;
    const declined = guests.filter((g) => g.status === "מסרב").length;

    setRsvpVars((prev) => ({
      ...prev,
      invitedCount: invited,
      acceptedCount: accepted,
      maybeCount: maybe,
      noReplyCount: noReply,
      declinedCount: declined,
    }));
  }, [guests, setRsvpVars]);

  const stats = useMemo(() => {
    const total = guests.length;
    const confirm = guests.filter((g) => g.status === "מאשר").length;
    const maybe = guests.filter((g) => g.status === "אולי").length;
    const decline = guests.filter((g) => g.status === "מסרב").length;
    const pending = total - (confirm + maybe + decline);
    const seats = guests.reduce((sum, g) => sum + (g.count || 0), 0);
    return { total, confirm, maybe, decline, pending, seats };
  }, [guests]);

  const filtered = useMemo(() => {
    return guests
      .filter((g) =>
        query
          ? [g.name, g.phone || "", g.email || "", g.group || "", g.notes || ""]
              .join(" ")
              .toLowerCase()
              .includes(query.toLowerCase())
          : true
      )
      .filter((g) => (statusFilter === "הכל" ? true : g.status === statusFilter))
      .filter((g) => (sideFilter === "הכל" ? true : g.side === sideFilter))
      .sort((a, b) => a.name.localeCompare(b.name, "he"));
  }, [guests, query, statusFilter, sideFilter]);

  function openNewModal() {
    setShowNewModal(true);
  }
  function closeNewModal() {
    setShowNewModal(false);
  }

  function addGuest(newGuest: Omit<Guest, "id">) {
    setGuests((prev) => [{ id: uid(), ...newGuest }, ...prev]);
    setShowNewModal(false);
  }

  function updateGuest(id: string, patch: Partial<Guest>) {
    setGuests((prev) => prev.map((g) => (g.id === id ? { ...g, ...patch } : g)));
  }

  function removeGuest(id: string) {
    setGuests((prev) => prev.filter((g) => g.id !== id));
  }

  return (
    <div className="min-h-screen" style={{backgroundColor: '#FFFFFF'}} dir="rtl">
      {/* Header Band - Rose.50 with decorative sparkles */}
      <div style={{backgroundColor: '#FCF3F7'}} className="relative">
        <div className="section-header-guests">
          <div className="flex items-center justify-center px-4 py-6 responsive-md:px-6 responsive-lg:px-8 relative z-10">
            <div className="text-center relative">
              <h1 className="section-title text-primary">
                מוזמנים
              </h1>
              {/* Decorative sparkles positioned away from text baseline */}
              <div
                className="absolute -top-3 -left-12 w-1.5 h-1.5 rotate-45 opacity-45"
                style={{ backgroundColor: "#F7D7A3" }}
              ></div>
              <div
                className="absolute top-2 -right-14 w-2 h-2 rotate-45 opacity-50"
                style={{ backgroundColor: "#DFA2B7" }}
              ></div>
              <div
                className="absolute -bottom-3 left-8 w-1 h-1 rotate-45 opacity-40"
                style={{ backgroundColor: "#F7D7A3" }}
              ></div>
            </div>
          </div>
        </div>
      </div>

      <div className="px-4 py-6 responsive-md:px-6 responsive-lg:px-8 space-y-6">
        <div className="max-w-7xl mx-auto">
          
          {/* כותרת + סיכומי־על */}
          <div className="flex flex-col responsive-lg:flex-row responsive-lg:items-center responsive-lg:justify-between gap-4 flex-wrap">
            <div className="space-y-1">
              <div className="flex items-center gap-3">
                <InviteRSVP size={24} variant="default" />
                <h2 className="responsive-xs:text-lg responsive-md:text-xl" style={{color: 'var(--text-primary)'}}>ניהול מוזמנים</h2>
              </div>
              <p className="text-sm responsive-xs:text-xs" style={{color: 'var(--text-secondary)'}}>
                נהל/י את רשימת המוזמנים, סטטוסים ומספר מקומות. בלי נתוני דוגמה — הכל ריק עד שתוסיפו.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={openNewModal}
                className="btn-primary px-6 py-3 rounded-xl focus-ring transition-all duration-220 hover:scale-[1.02] hover:shadow-lg active:scale-[0.98] responsive-xs:w-full responsive-lg:w-auto responsive-xs:min-h-[48px] responsive-md:min-h-[44px]"
                style={{
                  color: 'var(--text-inverse)',
                  transitionTimingFunction: 'cubic-bezier(.2,.8,.2,1)'
                }}
              >
                + מוזמן חדש
              </button>
            </div>
          </div>

          {/* אם אין מוזמנים - מצב ריק מוקדם */}
          {guests.length === 0 && (
            <div className="card p-8 responsive-xs:p-6 text-center space-y-4">
              <div className="w-16 h-16 responsive-xs:w-12 responsive-xs:h-12 mx-auto rounded-full flex items-center justify-center mb-4" style={{backgroundColor: 'var(--surface-rose-50)'}}>
                <InviteRSVP size={32} variant="default" className="responsive-xs:w-6 responsive-xs:h-6" />
              </div>
              <h2 className="responsive-xs:text-lg responsive-md:text-xl" style={{color: 'var(--text-primary)'}}>עדיין אין מוזמנים</h2>
              <p className="responsive-xs:text-sm" style={{color: 'var(--text-secondary)'}}>
                התחילו בהוספת המוזמנים הראשונים לחתונה שלכם
              </p>
              <button
                onClick={openNewModal}
                className="btn-primary inline-flex items-center gap-2 px-8 py-4 rounded-xl focus-ring transition-all duration-220 hover:scale-[1.02] hover:shadow-lg responsive-xs:w-full responsive-md:w-auto responsive-xs:min-h-[48px]"
                style={{
                  color: 'var(--text-inverse)',
                  transitionTimingFunction: 'cubic-bezier(.2,.8,.2,1)'
                }}
              >
                <span className="text-2xl responsive-xs:text-xl">+</span>
                הוסיפו מוזמן ראשון
              </button>
            </div>
          )}

          {/* תוכן רגיל - רק אם יש מוזמנים */}
          {guests.length > 0 && (
            <>
              {/* כרטיס סטטוסים מהיר */}
              <div className="grid grid-cols-2 responsive-md:grid-cols-3 responsive-lg:grid-cols-5 gap-3">
                <StatCard label="סה״כ" value={stats.total} />
                <StatCard label="מאשרים" value={stats.confirm} />
                <StatCard label="אולי" value={stats.maybe} />
                <StatCard label="מסרבים" value={stats.decline} />
                <StatCard label="ממתינים" value={stats.pending} />
              </div>
              
              <div className="grid grid-cols-1 responsive-md:grid-cols-3 gap-4">
                <div className="p-3 text-sm responsive-xs:text-xs" style={{color: 'var(--text-secondary)'}}>
                  מקומות משוערים: <span className="font-medium" style={{color: 'var(--text-primary)'}}>{stats.seats}</span>
                </div>
                <div className="hidden responsive-md:block"></div> {/* spacer */}
                <div className="flex justify-end">
                  <button
                    onClick={openNewModal}
                    className="btn-secondary px-4 py-2 rounded-lg focus-ring transition-all duration-200 hover:scale-[1.02] text-sm responsive-xs:min-h-[48px] responsive-md:min-h-[44px] responsive-xs:w-full responsive-md:w-auto"
                  >
                    + עוד מוזמן
                  </button>
                </div>
              </div>

              {/* חיפוש ומסננים */}
              <div className="flex flex-col responsive-lg:flex-row items-start responsive-lg:items-center gap-3">
                <input
                  dir="rtl"
                  className="w-full responsive-lg:w-96 px-3 py-2 rounded-lg border focus-ring responsive-xs:min-h-[48px] responsive-md:min-h-[44px]"
                  style={{
                    borderColor: 'var(--border-subtle)',
                    backgroundColor: 'var(--base-white)'
                  }}
                  placeholder="חפשו לפי שם / טלפון / מייל / קבוצה…"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                />
                <div className="flex items-center gap-2 flex-wrap w-full responsive-lg:w-auto">
                  <SelectChip
                    label="סטטוס"
                    value={statusFilter}
                    options={["הכל", ...STATUSES]}
                    onChange={(v) => setStatusFilter(v as any)}
                  />
                  <SelectChip
                    label="צד"
                    value={sideFilter}
                    options={["הכל", ...SIDES]}
                    onChange={(v) => setSideFilter(v as any)}
                  />
                </div>
              </div>

              {/* טבלה (דסקטופ) / כרטיסים (מובייל) */}
              <div className="hidden responsive-lg:block overflow-auto rounded-xl border" style={{borderColor: 'var(--border-subtle)'}}>
                <table className="w-full text-sm">
                  <thead style={{backgroundColor: 'var(--base-white)'}}>
                    <tr className="[&>th]:px-3 [&>th]:py-2 text-right" style={{color: 'var(--text-secondary)'}}>
                      <th>שם</th>
                      <th>צד</th>
                      <th>סטטוס</th>
                      <th>מקומות</th>
                      <th>טלפון</th>
                      <th>אימייל</th>
                      <th>קבוצה</th>
                      <th>הערות</th>
                      <th></th>
                    </tr>
                  </thead>
                  <tbody className="divide-y" style={{borderColor: 'var(--border-subtle)'}}>
                    {filtered.map((g) => (
                      <tr key={g.id} className="bg-white hover:bg-selection-bg">
                        <td className="px-3 py-2 font-medium">{g.name || "—"}</td>
                        <td className="px-3 py-2">{g.side}</td>
                        <td className="px-3 py-2"><StatusBadge status={g.status} /></td>
                        <td className="px-3 py-2">{g.count ?? 0}</td>
                        <td className="px-3 py-2">{g.phone || "—"}</td>
                        <td className="px-3 py-2">{g.email || "—"}</td>
                        <td className="px-3 py-2">{g.group || "—"}</td>
                        <td className="px-3 py-2 truncate max-w-[16ch]" title={g.notes}>{g.notes || "—"}</td>
                        <td className="px-3 py-2">
                          <div className="flex gap-2">
                            <button
                              className="btn-secondary px-2 py-1 rounded-lg focus-ring text-sm min-h-[36px]"
                              onClick={() => setEditId(g.id)}
                            >
                              ערכו
                            </button>
                            <button
                              className="px-2 py-1 rounded-lg border focus-ring text-sm min-h-[36px]"
                              style={{
                                borderColor: 'var(--border-strong)',
                                color: 'var(--semantic-danger-solid)'
                              }}
                              onClick={() => removeGuest(g.id)}
                            >
                              מחקו
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                    {filtered.length === 0 && (
                      <tr>
                        <td colSpan={9} className="px-3 py-10 text-center" style={{color: 'var(--text-secondary)'}}>
                          אין תוצאות — נסו לחפש אחרת או להסיר מסננים.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>

              {/* מובייל/טאבלט: כרטיסים */}
              <div className="responsive-lg:hidden space-y-3">
                {filtered.map((g) => (
                  <div key={g.id} className="card p-4">
                    <div className="flex flex-col responsive-md:flex-row responsive-md:items-center responsive-md:justify-between gap-2 mb-3">
                      <div className="font-medium responsive-xs:text-sm responsive-md:text-base">{g.name || "—"}</div>
                      <StatusBadge status={g.status} />
                    </div>
                    <div className="text-sm responsive-xs:text-xs mb-2" style={{color: 'var(--text-secondary)'}}>
                      {g.side} • מקומות: {g.count ?? 0}
                    </div>
                    <div className="text-sm responsive-xs:text-xs mb-2">{g.phone || "—"} · {g.email || "—"}</div>
                    <div className="text-sm responsive-xs:text-xs mb-2">{g.group || "—"}</div>
                    <div className="text-sm responsive-xs:text-xs line-clamp-2 mb-3">{g.notes || "—"}</div>
                    <div className="flex gap-2">
                      <button
                        className="btn-secondary px-3 py-2 rounded-lg focus-ring text-sm flex-1 responsive-xs:min-h-[48px] responsive-md:min-h-[44px]"
                        onClick={() => setEditId(g.id)}
                      >
                        ערכו
                      </button>
                      <button
                        className="px-3 py-2 rounded-lg border focus-ring text-sm responsive-xs:min-h-[48px] responsive-md:min-h-[44px]"
                        style={{
                          borderColor: 'var(--border-strong)',
                          color: 'var(--semantic-danger-solid)'
                        }}
                        onClick={() => removeGuest(g.id)}
                      >
                        מחקו
                      </button>
                    </div>
                  </div>
                ))}
                {filtered.length === 0 && (
                  <div className="text-center py-8 responsive-xs:text-sm" style={{color: 'var(--text-secondary)'}}>
                    אין מוזמנים עדיין. התחילו עם "מוזמן חדש".
                  </div>
                )}
              </div>
            </>
          )}

          {/* כפתור צף למובייל - רק אם יש מוזמנים */}
          {guests.length > 0 && (
            <div className="responsive-lg:hidden fixed bottom-6 left-6 z-50">
              <button
                onClick={openNewModal}
                className="w-14 h-14 rounded-full shadow-lg hover:shadow-xl focus-ring transition-shadow flex items-center justify-center text-2xl font-light"
                style={{
                  backgroundColor: 'var(--brand-primary)',
                  color: 'var(--text-inverse)'
                }}
                aria-label="הוסף מוזמן חדש"
              >
                +
              </button>
            </div>
          )}

          {/* מודאל הוספה */}
          {showNewModal && (
            <GuestModal
              title="מוזמן חדש"
              onClose={closeNewModal}
              onSave={(payload) => addGuest(payload)}
            />
          )}

          {/* מודאל עריכה */}
          {editId && (
            <GuestModal
              title="עריכת מוזמן"
              initial={guests.find((g) => g.id === editId)!}
              onClose={() => setEditId(null)}
              onSave={(payload) => {
                updateGuest(editId, payload);
                setEditId(null);
              }}
            />
          )}
        </div>
      </div>
    </div>
  );
}

function StatCard({ label, value }: { label: string; value: number }) {
  return (
    <div className="card p-3">
      <div className="text-sm responsive-xs:text-xs" style={{color: 'var(--text-secondary)'}}>{label}</div>
      <div className="text-2xl responsive-xs:text-xl font-semibold" style={{color: 'var(--text-primary)'}}>{value ?? 0}</div>
    </div>
  );
}

function StatusBadge({ status }: { status: Guest["status"] }) {
  const map: Record<Guest["status"], string> = {
    "טיוטה": "text-secondary border-subtle",
    "נשלחה הזמנה": "text-primary border-subtle",
    "מאשר": "text-success border-success/30",
    "מסרב": "text-destructive border-destructive/30",
    "אולי": "text-warning border-warning/30",
  };
  return (
    <span className={`inline-flex items-center px-2 py-1 rounded-full border text-xs responsive-xs:text-xs ${map[status]}`}>
      {status}
    </span>
  );
}

function SelectChip({
  label, value, options, onChange,
}: {
  label: string;
  value: string;
  options: string[];
  onChange: (v: string) => void;
}) {
  return (
    <div className="flex flex-col responsive-md:flex-row responsive-md:items-center gap-2">
      <span className="text-sm responsive-xs:text-xs" style={{color: 'var(--text-secondary)'}}>{label}:</span>
      <div className="flex items-center gap-1 flex-wrap">
        {options.map((opt) => {
          const active = value === opt;
          return (
            <button
              key={opt}
              onClick={() => onChange(opt)}
              className={`px-3 py-1 rounded-full border text-sm responsive-xs:text-xs focus-ring transition-all duration-200 hover:scale-[1.02] responsive-xs:min-h-[36px] responsive-md:min-h-[32px]
                ${active ? "chip-selected" : "chip-unselected"}`}
            >
              {opt}
            </button>
          );
        })}
      </div>
    </div>
  );
}

function GuestModal({
  title,
  initial,
  onClose,
  onSave,
}: {
  title: string;
  initial?: Guest;
  onClose: () => void;
  onSave: (payload: Omit<Guest, "id">) => void;
}) {
  const [name, setName] = useState(initial?.name ?? "");
  const [side, setSide] = useState<Guest["side"]>(initial?.side ?? "משותף");
  const [status, setStatus] = useState<Guest["status"]>(initial?.status ?? "טיוטה");
  const [count, setCount] = useState<number>(initial?.count ?? 1);
  const [phone, setPhone] = useState(initial?.phone ?? "");
  const [email, setEmail] = useState(initial?.email ?? "");
  const [diet, setDiet] = useState<Guest["diet"]>(initial?.diet ?? "רגיל");
  const [group, setGroup] = useState(initial?.group ?? "");
  const [notes, setNotes] = useState(initial?.notes ?? "");

  const canSave = name.trim().length > 0 && count >= 0;

  function handleSave() {
    if (!canSave) return;
    onSave({
      name: name.trim(),
      side,
      status,
      count,
      phone: phone.trim() || undefined,
      email: email.trim() || undefined,
      diet,
      group: group.trim() || undefined,
      notes: notes.trim() || undefined,
    });
  }

  return (
    <div className="fixed inset-0 z-[100] bg-black/30 flex items-end responsive-md:items-center justify-center p-4" onClick={onClose}>
      <div
        className="w-full responsive-md:max-w-2xl bg-white rounded-2xl p-4 space-y-3 responsive-xs:max-h-[90vh] overflow-y-auto"
        dir="rtl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between">
          <h2 className="text-lg responsive-xs:text-base font-semibold">{title}</h2>
          <button onClick={onClose} className="focus-ring rounded-lg px-2 py-1 responsive-xs:min-h-[44px] responsive-md:min-h-[36px]" style={{color: 'var(--text-secondary)'}}>סגור</button>
        </div>

        {/* שני טורים בדסקטופ, אחד במובייל */}
        <div className="grid grid-cols-1 responsive-md:grid-cols-2 gap-3">
          <Field label="שם מלא *">
            <input
              autoFocus
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-3 py-2 rounded-lg border focus-ring responsive-xs:min-h-[48px] responsive-md:min-h-[44px]"
              style={{
                borderColor: 'var(--border-subtle)',
                backgroundColor: 'var(--base-white)'
              }}
              placeholder="יוסי כהן"
              dir="rtl"
            />
          </Field>

          <Field label="צד">
            <select
              value={side}
              onChange={(e) => setSide(e.target.value as Guest["side"])}
              className="w-full px-3 py-2 rounded-lg border focus-ring bg-white responsive-xs:min-h-[48px] responsive-md:min-h-[44px]"
              style={{borderColor: 'var(--border-subtle)'}}
            >
              {SIDES.map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
          </Field>

          <Field label="סטטוס">
            <select
              value={status}
              onChange={(e) => setStatus(e.target.value as Guest["status"])}
              className="w-full px-3 py-2 rounded-lg border focus-ring bg-white responsive-xs:min-h-[48px] responsive-md:min-h-[44px]"
              style={{borderColor: 'var(--border-subtle)'}}
            >
              {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
          </Field>

          <Field label="מקומות">
            <input
              type="number"
              inputMode="numeric"
              min={0}
              value={count}
              onChange={(e) => setCount(parseInt(e.target.value || "0", 10))}
              className="w-full px-3 py-2 rounded-lg border focus-ring responsive-xs:min-h-[48px] responsive-md:min-h-[44px]"
              style={{
                borderColor: 'var(--border-subtle)',
                backgroundColor: 'var(--base-white)'
              }}
            />
          </Field>

          <Field label="טלפון">
            <input
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="w-full px-3 py-2 rounded-lg border focus-ring responsive-xs:min-h-[48px] responsive-md:min-h-[44px]"
              style={{
                borderColor: 'var(--border-subtle)',
                backgroundColor: 'var(--base-white)'
              }}
              placeholder="050-1234567"
              dir="ltr"
            />
          </Field>

          <Field label="אימייל">
            <input
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-3 py-2 rounded-lg border focus-ring responsive-xs:min-h-[48px] responsive-md:min-h-[44px]"
              style={{
                borderColor: 'var(--border-subtle)',
                backgroundColor: 'var(--base-white)'
              }}
              placeholder="name@example.com"
              dir="ltr"
            />
          </Field>

          <Field label="קבוצה (משפחה/חברים/עבודה)">
            <input
              value={group}
              onChange={(e) => setGroup(e.target.value)}
              className="w-full px-3 py-2 rounded-lg border focus-ring responsive-xs:min-h-[48px] responsive-md:min-h-[44px]"
              style={{
                borderColor: 'var(--border-subtle)',
                backgroundColor: 'var(--base-white)'
              }}
              placeholder="משפחה"
            />
          </Field>

          <Field label="תזונה">
            <select
              value={diet}
              onChange={(e) => setDiet(e.target.value as Guest["diet"])}
              className="w-full px-3 py-2 rounded-lg border focus-ring bg-white responsive-xs:min-h-[48px] responsive-md:min-h-[44px]"
              style={{borderColor: 'var(--border-subtle)'}}
            >
              {["רגיל","צמחוני","טבעוני","ללא גלוטן","אחר"].map((d) => <option key={d} value={d}>{d}</option>)}
            </select>
          </Field>

          <Field label="הערות" full>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full h-24 responsive-xs:h-32 px-3 py-2 rounded-lg border focus-ring"
              style={{
                borderColor: 'var(--border-subtle)',
                backgroundColor: 'var(--base-white)'
              }}
              placeholder="הערות חשובות, אלרגיות, ילדים…"
            />
          </Field>
        </div>

        <div className="flex items-center justify-end gap-2 pt-4">
          <button
            onClick={onClose}
            className="btn-secondary px-3 py-2 rounded-lg focus-ring responsive-xs:min-h-[48px] responsive-md:min-h-[44px]"
          >
            ביטול
          </button>
          <button
            onClick={handleSave}
            disabled={!canSave}
            className="btn-primary px-4 py-2 rounded-xl disabled:opacity-50 focus-ring responsive-xs:min-h-[48px] responsive-md:min-h-[44px]"
          >
            שמירה
          </button>
        </div>
      </div>
    </div>
  );
}

function Field({ label, children, full = false }: { label: string; children: React.ReactNode; full?: boolean }) {
  return (
    <label className={`flex flex-col gap-1 ${full ? "responsive-md:col-span-2" : ""}`}>
      <span className="text-sm responsive-xs:text-xs" style={{color: 'var(--text-secondary)'}}>{label}</span>
      {children}
    </label>
  );
}