import React from 'react';
import { Button } from './button';

interface BackButtonProps {
  onBack: () => void;
  className?: string;
  size?: 'default' | 'sm' | 'lg';
  showLabel?: boolean;
}

export function BackButton({ 
  onBack, 
  className = '', 
  size = 'default',
  showLabel = true 
}: BackButtonProps) {
  return (
    <Button
      variant="ghost"
      size={size}
      onClick={onBack}
      className={`focus:ring-2 focus:ring-ring back-button-motion ${className}`}
      style={{ color: 'var(--text-primary)' }}
    >
      {/* RTL Arrow pointing right */}
      <svg
        width="20"
        height="20"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.75"
        strokeLinecap="round"
        strokeLinejoin="round"
        className="transition-transform duration-200"
      >
        <path d="M19 12H5" />
        <path d="m12 19 7-7-7-7" />
      </svg>
      {showLabel && (
        <span className="mr-2">חזרה</span>
      )}
    </Button>
  );
}