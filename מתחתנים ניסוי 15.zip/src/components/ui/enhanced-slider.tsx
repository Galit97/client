import React, { useState, useEffect } from 'react';
import { Slider } from './slider';
import { Input } from './input';
import { Label } from './label';

interface TickMark {
  value: number;
  label: string;
}

interface EnhancedSliderProps {
  value: number[];
  onValueChange: (value: number[]) => void;
  min: number;
  max: number;
  step: number;
  tickMarks?: TickMark[];
  labels?: string[];
  helper?: string;
  className?: string;
  isDual?: boolean;
}

export const EnhancedSlider: React.FC<EnhancedSliderProps> = ({
  value,
  onValueChange,
  min,
  max,
  step,
  tickMarks = [],
  labels = [],
  helper,
  className = "",
  isDual = false
}) => {
  const [inputValues, setInputValues] = useState(value);
  const [showTooltip, setShowTooltip] = useState(false);

  useEffect(() => {
    setInputValues(value);
  }, [value]);

  const handleSliderChange = (newValue: number[]) => {
    setInputValues(newValue);
    onValueChange(newValue);
  };

  const handleInputChange = (index: number, inputValue: string) => {
    const numValue = Math.max(min, Math.min(max, parseInt(inputValue) || min));
    const newValues = [...inputValues];
    newValues[index] = numValue;
    
    // Ensure proper order for dual sliders
    if (isDual && newValues.length === 2) {
      if (index === 0 && newValues[0] > newValues[1]) {
        newValues[1] = newValues[0];
      } else if (index === 1 && newValues[1] < newValues[0]) {
        newValues[0] = newValues[1];
      }
    }
    
    setInputValues(newValues);
    onValueChange(newValues);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowLeft' || e.key === 'ArrowRight') {
      e.preventDefault();
      const direction = e.key === 'ArrowRight' ? 1 : -1;
      const stepSize = e.shiftKey ? step * 5 : step;
      const newValue = Math.max(min, Math.min(max, inputValues[0] + (direction * stepSize)));
      handleSliderChange([newValue]);
    }
  };

  return (
    <div className={`space-y-4 ${className}`} dir="rtl">
      {/* Labels and Inputs */}
      {labels.length > 0 && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
          {labels.map((label, index) => (
            <div key={index} className="space-y-2">
              <Label className="block text-sm sm:text-base">{label}</Label>
              <Input
                type="number"
                inputMode="numeric"
                value={inputValues[index] || ''}
                onChange={(e) => handleInputChange(index, e.target.value)}
                min={min}
                max={max}
                step={step}
                className="text-right text-base sm:text-sm h-12 sm:h-10"
                dir="rtl"
              />
            </div>
          ))}
        </div>
      )}

      {/* Single input for non-dual sliders */}
      {!isDual && labels.length === 0 && (
        <div className="w-full sm:w-48">
          <Input
            type="number"
            inputMode="numeric"
            value={inputValues[0] || ''}
            onChange={(e) => handleInputChange(0, e.target.value)}
            min={min}
            max={max}
            step={step}
            className="text-right w-full text-base sm:text-sm h-12 sm:h-10"
            dir="rtl"
          />
        </div>
      )}

      {/* Slider with enhanced mobile touch targets */}
      <div className="relative px-2 py-4">
        <div
          onMouseEnter={() => setShowTooltip(true)}
          onMouseLeave={() => setShowTooltip(false)}
          onKeyDown={handleKeyDown}
          tabIndex={0}
          className="relative focus:outline-none"
        >
          <Slider
            value={inputValues}
            onValueChange={handleSliderChange}
            min={min}
            max={max}
            step={step}
            className="range-slider w-full"
          />
          
          {/* Tooltip - Hidden on mobile, shown on desktop */}
          {showTooltip && (
            <div className="hidden sm:block absolute -top-10 left-1/2 transform -translate-x-1/2 bg-gray-900 text-white px-2 py-1 rounded text-xs whitespace-nowrap z-10">
              {isDual ? `${inputValues[0]}–${inputValues[1]}` : inputValues[0]}
            </div>
          )}
        </div>

        {/* Tick marks - More spacing on mobile */}
        {tickMarks.length > 0 && (
          <div className="flex justify-between mt-3 px-1">
            {tickMarks.map((tick, index) => (
              <div key={index} className="flex flex-col items-center">
                <div className="w-px h-2 bg-gray-300"></div>
                <span className="text-xs text-gray-500 mt-1 hidden sm:inline">
                  {tick.label}
                </span>
                {/* Show only key tick marks on mobile */}
                {(index === 0 || index === tickMarks.length - 1 || index === Math.floor(tickMarks.length / 2)) && (
                  <span className="text-xs text-gray-500 mt-1 sm:hidden">
                    {tick.label}
                  </span>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Helper text */}
      {helper && (
        <p className="text-xs sm:text-sm leading-relaxed" style={{ color: 'var(--text-muted)' }}>
          {helper}
        </p>
      )}
    </div>
  );
};