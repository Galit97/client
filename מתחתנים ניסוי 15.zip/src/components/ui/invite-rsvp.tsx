import React from 'react';

interface InviteRSVPProps {
  size?: number;
  variant?: 'default' | 'active';
  className?: string;
}

export const InviteRSVP: React.FC<InviteRSVPProps> = ({
  size = 24,
  variant = 'default',
  className = ''
}) => {
  const strokeColor = variant === 'active' ? 'var(--brand-primary)' : 'var(--text-secondary)';
  const badgeColor = variant === 'active' ? 'var(--brand-primary)' : 'var(--text-secondary)';
  const shadowStyle = variant === 'active' ? { filter: 'drop-shadow(0 2px 6px rgba(0,0,0,0.08))' } : {};

  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      className={className}
      style={shadowStyle}
    >
      {/* Envelope outline */}
      <g stroke={strokeColor} strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" fill="none">
        {/* Envelope body */}
        <path d="M4 6 L20 6 L20 18 L4 18 Z" />
        
        {/* Envelope flap - top triangle */}
        <path d="M4 6 L12 13 L20 6" />
        
        {/* Inner lines showing paper/content */}
        <path d="M7 10 L11 10" opacity="0.4" />
        <path d="M7 12 L13 12" opacity="0.4" />
        <path d="M7 14 L10 14" opacity="0.4" />
      </g>
      
      {/* Checkmark badge in top-right corner (6-8px) */}
      <g transform="translate(16, 4)">
        {/* Badge background circle */}
        <circle 
          cx="4" 
          cy="4" 
          r="4" 
          fill={badgeColor}
          stroke="none"
        />
        
        {/* Checkmark inside badge */}
        <path
          d="M2 4 L3.5 5.5 L6 2.5"
          stroke="white"
          strokeWidth="1.5"
          strokeLinecap="round"
          strokeLinejoin="round"
          fill="none"
        />
      </g>
    </svg>
  );
};