import React from 'react';
import { Home, Calculator, Users, Briefcase, CheckSquare, Settings } from 'lucide-react';

type NavigationTab = 'dashboard' | 'budget' | 'guests' | 'suppliers' | 'tasks' | 'settings';

interface BottomNavigationProps {
  activeTab: NavigationTab;
  onNavigate: (screen: string) => void;
}

interface TabConfig {
  id: NavigationTab;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  screen: string;
}

const tabs: TabConfig[] = [
  {
    id: 'dashboard',
    label: 'בית',
    icon: Home,
    screen: 'dashboard'
  },
  {
    id: 'budget',
    label: 'תקציב',
    icon: Calculator,
    screen: 'budget-overview'
  },
  {
    id: 'guests',
    label: 'מוזמנים',
    icon: Users,
    screen: 'guests'
  },
  {
    id: 'suppliers',
    label: 'ספקים',
    icon: Briefcase,
    screen: 'suppliers'
  },
  {
    id: 'tasks',
    label: 'משימות',
    icon: CheckSquare,
    screen: 'tasks'
  },
  {
    id: 'settings',
    label: 'הגדרות',
    icon: Settings,
    screen: 'settings'
  }
];

// Map screens to tab IDs for active state detection
const screenToTab: Record<string, NavigationTab> = {
  'dashboard': 'dashboard',
  'budget': 'budget',
  'budget-overview': 'budget',
  'new-budget-wizard': 'budget',
  'guests': 'guests',
  'suppliers': 'suppliers',
  'tasks': 'tasks',
  'settings': 'settings',
  'members-permissions': 'settings',
  'notification-settings': 'settings'
};

export function BottomNavigation({ activeTab, onNavigate }: BottomNavigationProps) {
  return (
    <nav 
      className="bottom-navigation"
      style={{
        position: 'fixed',
        bottom: 0,
        left: 0,
        right: 0,
        backgroundColor: 'var(--base-white)',
        borderTop: '1px solid var(--border-subtle)',
        paddingTop: '8px',
        paddingBottom: 'calc(8px + var(--safe-area-inset-bottom))',
        paddingLeft: 'var(--safe-area-inset-left)',
        paddingRight: 'var(--safe-area-inset-right)',
        zIndex: 50
      }}
      dir="rtl"
    >
      <div className="flex justify-around items-center max-w-lg mx-auto px-2">
        {tabs.map((tab) => {
          const isActive = activeTab === tab.id;
          const IconComponent = tab.icon;
          
          return (
            <button
              key={tab.id}
              onClick={() => onNavigate(tab.screen)}
              className={`
                flex flex-col items-center justify-center
                min-h-[44px] min-w-[44px] px-2 py-1
                rounded-lg transition-all duration-200
                focus:outline-none focus:ring-2 focus:ring-ring
                ${isActive 
                  ? 'text-brand-primary' 
                  : 'text-text-secondary hover:text-brand-primary hover:bg-selection-bg'
                }
              `}
              style={{
                color: isActive 
                  ? 'var(--brand-primary)' 
                  : 'var(--text-secondary)'
              }}
              aria-label={`עבור ל${tab.label}`}
            >
              <div className="relative">
                <IconComponent 
                  className="w-5 h-5 mb-1" 
                  strokeWidth={isActive ? 2.5 : 1.5}
                />
                {/* Active indicator - tiny underline */}
                {isActive && (
                  <div 
                    className="absolute -bottom-0.5 left-1/2 transform -translate-x-1/2 w-3 h-0.5 rounded-full"
                    style={{
                      backgroundColor: 'var(--brand-primary)'
                    }}
                  />
                )}
              </div>
              <span 
                className="text-xs leading-tight"
                style={{
                  fontSize: 'var(--text-meta)',
                  fontWeight: isActive ? 'var(--font-weight-medium)' : 'var(--font-weight-normal)'
                }}
              >
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}

// Helper function to determine active tab from current screen
export function getActiveTabFromScreen(currentScreen: string): NavigationTab {
  return screenToTab[currentScreen] || 'dashboard';
}