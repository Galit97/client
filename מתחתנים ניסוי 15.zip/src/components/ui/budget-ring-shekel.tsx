import React from 'react';

interface BudgetRingShekelProps {
  size?: number;
  variant?: 'default' | 'active';
  className?: string;
}

export const BudgetRingShekel: React.FC<BudgetRingShekelProps> = ({
  size = 24,
  variant = 'default',
  className = ''
}) => {
  const strokeColor = variant === 'active' ? 'var(--brand-primary-hover)' : 'var(--brand-primary)';
  const shadowStyle = variant === 'active' ? { filter: 'drop-shadow(0 2px 6px rgba(0,0,0,0.08))' } : {};

  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      className={className}
      style={shadowStyle}
    >
      {/* Outer ring (gauge thin circle) */}
      <circle
        cx="12"
        cy="12"
        r="10"
        stroke={strokeColor}
        strokeWidth="1.75"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill="none"
      />
      
      {/* Center symbol: "₪" shekel (vector paths, not font) */}
      <g stroke={strokeColor} strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" fill="none">
        {/* Left vertical line of shekel */}
        <path d="M8 7v10" />
        {/* Right vertical line of shekel */}
        <path d="M16 7v10" />
        {/* Top horizontal line */}
        <path d="M8 9h6" />
        {/* Bottom horizontal line */}
        <path d="M10 15h6" />
      </g>
      
      {/* Small sparkle (diamond 6x6) top-right */}
      <g transform="translate(16, 6)">
        <path
          d="M3 0 L6 3 L3 6 L0 3 Z"
          fill="#F7D7A3"
          fillOpacity="0.5"
          stroke="none"
        />
      </g>
    </svg>
  );
};