import React from 'react';

interface GuestsDancerProps {
  size?: number;
  variant?: 'default' | 'active';
  className?: string;
}

export const GuestsDancer: React.FC<GuestsDancerProps> = ({
  size = 24,
  variant = 'default',
  className = ''
}) => {
  const strokeColor = variant === 'active' ? 'var(--brand-primary-hover)' : 'var(--brand-primary)';
  const accentColor = variant === 'active' ? 'var(--brand-primary-hover)' : 'var(--brand-primary)';
  const shadowStyle = variant === 'active' ? { filter: 'drop-shadow(0 2px 6px rgba(0,0,0,0.08))' } : {};

  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      className={className}
      style={shadowStyle}
    >
      {/* Body and pose - side-step with raised hand, friendly */}
      <g stroke={strokeColor} strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" fill="none">
        {/* Head */}
        <circle cx="12" cy="5" r="2.5" />
        
        {/* Body trunk */}
        <path d="M12 7.5 L12 14" />
        
        {/* Left arm - raised up in celebration/dance */}
        <path d="M12 9 L8 7" />
        
        {/* Right arm - extended to side */}
        <path d="M12 9 L16 10" />
        
        {/* Left leg - side step */}
        <path d="M12 14 L10 19" />
        <path d="M10 19 L9 21" />
        
        {/* Right leg - slight bend, dynamic pose */}
        <path d="M12 14 L14 18" />
        <path d="M14 18 L15 20" />
      </g>
      
      {/* Accent strokes at 60% opacity for duotone effect */}
      <g stroke={accentColor} strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" fill="none" opacity="0.6">
        {/* Movement lines around raised hand */}
        <path d="M7 6 Q6 5 7 4" />
        <path d="M6 7 Q5 6 6 5" />
        
        {/* Movement lines around feet */}
        <path d="M8 21 Q7 20 8 19" />
        <path d="M16 20 Q17 19 16 18" />
      </g>
      
      {/* Small sparkle near shoulder */}
      <g transform="translate(15, 8)" opacity="0.45">
        <path
          d="M3 0 L4.5 1.5 L3 3 L1.5 1.5 Z"
          fill="#F7D7A3"
          stroke="none"
        />
      </g>
    </svg>
  );
};