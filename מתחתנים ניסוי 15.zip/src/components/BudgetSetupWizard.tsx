import { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Slider } from './ui/slider';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { Progress } from './ui/progress';
import { Alert, AlertDescription } from './ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { 
  ArrowRight, 
  ArrowLeft, 
  Calculator, 
  Users as UsersIcon, 
  CheckCircle,
  AlertTriangle,
  Plus,
  Minus,
  RotateCcw,
  Info
} from 'lucide-react';

interface BudgetCategory {
  id: string;
  name: string;
  percentage: number;
  amount: number;
}

interface SimpleBudgetData {
  approach: 'per-guest';
  guestCount: number;
  costPerGuest: number;
  totalBudget: number;
  categories: BudgetCategory[];
}

interface BudgetSetupWizardProps {
  onComplete: (data: SimpleBudgetData) => void;
  onCancel: () => void;
  guestCount: number;
}

const DEFAULT_CATEGORY_PERCENTAGES = [
  { name: 'אולם וקייטרינג', percentage: 50 },
  { name: 'צילום ווידאו', percentage: 10 },
  { name: 'מוזיקה ובידור', percentage: 9 },
  { name: 'שמלה וחליפה', percentage: 8 },
  { name: 'פרחים ועיצוב', percentage: 5 },
  { name: 'טבעות', percentage: 4 },
  { name: 'שיער ואיפור', percentage: 4 },
  { name: 'הדפסות', percentage: 3 },
  { name: 'רב וחופה', percentage: 2 },
  { name: 'תחבורה', percentage: 2 },
  { name: 'מתנות וטיפים', percentage: 2 },
  { name: 'שונות', percentage: 1 },
];

const STORAGE_KEY = 'wedding-simple-budget-draft';

export function BudgetSetupWizard({ onComplete, onCancel, guestCount: initialGuestCount }: BudgetSetupWizardProps) {
  const [currentStep, setCurrentStep] = useState(1);
  const [budgetData, setBudgetData] = useState<SimpleBudgetData>({
    approach: 'per-guest',
    guestCount: initialGuestCount,
    costPerGuest: 400,
    totalBudget: initialGuestCount * 400,
    categories: DEFAULT_CATEGORY_PERCENTAGES.map((cat, index) => ({
      id: `cat-${index}`,
      name: cat.name,
      percentage: cat.percentage,
      amount: Math.round((initialGuestCount * 400 * cat.percentage) / 100),
    })),
  });
  const [showDraftBanner, setShowDraftBanner] = useState(false);

  const totalSteps = 3;
  const progress = (currentStep / totalSteps) * 100;

  // Load draft on mount
  useEffect(() => {
    const savedDraft = localStorage.getItem(STORAGE_KEY);
    if (savedDraft) {
      try {
        const draft = JSON.parse(savedDraft);
        if (Object.keys(draft).length > 0) {
          setShowDraftBanner(true);
        }
      } catch (e) {
        localStorage.removeItem(STORAGE_KEY);
      }
    }
  }, []);

  // Autosave draft on changes
  useEffect(() => {
    if (currentStep > 1) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify({ 
        ...budgetData, 
        currentStep 
      }));
    }
  }, [budgetData, currentStep]);

  const loadDraft = () => {
    const savedDraft = localStorage.getItem(STORAGE_KEY);
    if (savedDraft) {
      try {
        const draft = JSON.parse(savedDraft);
        setBudgetData(draft);
        setCurrentStep(draft.currentStep || 1);
        setShowDraftBanner(false);
      } catch (e) {
        localStorage.removeItem(STORAGE_KEY);
        setShowDraftBanner(false);
      }
    }
  };

  const dismissDraft = () => {
    localStorage.removeItem(STORAGE_KEY);
    setShowDraftBanner(false);
  };

  const formatNumber = (num: number): string => {
    return new Intl.NumberFormat('he-IL').format(num);
  };

  const parseNumberInput = (value: string): number => {
    return parseFloat(value.replace(/[^\d]/g, '')) || 0;
  };

  const updateBudgetData = (updates: Partial<SimpleBudgetData>) => {
    setBudgetData(prev => {
      const newData = { ...prev, ...updates };
      
      // Always recalculate total budget based on guests and cost per guest
      const total = newData.guestCount * newData.costPerGuest;
      newData.totalBudget = total;
      
      // Recalculate categories when total budget changes
      newData.categories = newData.categories.map(cat => ({
        ...cat,
        amount: Math.round((total * cat.percentage) / 100),
      }));
      
      return newData;
    });
  };

  const updateCategoryPercentage = (id: string, change: number) => {
    setBudgetData(prev => {
      const categories = [...prev.categories];
      const targetIndex = categories.findIndex(cat => cat.id === id);
      
      if (targetIndex === -1) return prev;
      
      const newPercentage = Math.max(0, Math.min(100, categories[targetIndex].percentage + change));
      const diff = newPercentage - categories[targetIndex].percentage;
      
      categories[targetIndex].percentage = newPercentage;
      
      // Auto-balance by adjusting other categories proportionally
      const remaining = categories.filter((_, i) => i !== targetIndex);
      const remainingTotal = remaining.reduce((sum, cat) => sum + cat.percentage, 0);
      
      if (remainingTotal > 0 && diff !== 0) {
        remaining.forEach((cat, i) => {
          const adjustedIndex = categories.findIndex(c => c.id === cat.id);
          const adjustment = -(diff * (cat.percentage / remainingTotal));
          categories[adjustedIndex].percentage = Math.max(0, cat.percentage + adjustment);
        });
      }
      
      // Recalculate amounts based on current total
      const total = prev.guestCount * prev.costPerGuest;
      
      categories.forEach(cat => {
        cat.amount = Math.round((total * cat.percentage) / 100);
      });
      
      return { ...prev, categories };
    });
  };

  const autoBalance = () => {
    setBudgetData(prev => {
      const categories = DEFAULT_CATEGORY_PERCENTAGES.map((cat, index) => ({
        id: `cat-${index}`,
        name: cat.name,
        percentage: cat.percentage,
        amount: 0,
      }));
      
      const total = prev.guestCount * prev.costPerGuest;
      
      categories.forEach(cat => {
        cat.amount = Math.round((total * cat.percentage) / 100);
      });
      
      return { ...prev, categories };
    });
  };

  const handleNext = () => {
    if (currentStep < totalSteps) {
      setCurrentStep(currentStep + 1);
    } else {
      localStorage.removeItem(STORAGE_KEY);
      onComplete(budgetData);
    }
  };

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const renderStep = () => {
    switch (currentStep) {
      case 1:
        return (
          <div className="space-y-6">
            <div className="text-center space-y-2">
              <UsersIcon className="w-12 h-12 text-primary mx-auto mb-4" />
              <h2>תכנון התקציב</h2>
              <p className="text-muted-foreground">
                תכנון מבוסס מספר אורחים ועלות ממוצעת לאורח
              </p>
            </div>
            
            <div className="space-y-6">
              <div>
                <Label>מספר מוזמנים: {budgetData.guestCount}</Label>
                <Slider
                  value={[budgetData.guestCount]}
                  onValueChange={(value) => updateBudgetData({ guestCount: value[0] })}
                  min={50}
                  max={600}
                  step={10}
                  className="mt-2"
                />
                <div className="flex justify-between text-xs text-muted-foreground mt-1">
                  <span>50</span>
                  <span>600</span>
                </div>
                <Input
                  type="number"
                  inputMode="numeric"
                  min="50"
                  max="1000"
                  value={budgetData.guestCount}
                  onChange={(e) => updateBudgetData({ guestCount: parseInt(e.target.value) || 50 })}
                  className="mt-2 min-h-[44px] focus:ring-2 focus:ring-primary"
                />
              </div>
              
              <div>
                <Label>עלות ממוצעת לאורח: ₪{formatNumber(budgetData.costPerGuest)}</Label>
                <Slider
                  value={[budgetData.costPerGuest]}
                  onValueChange={(value) => updateBudgetData({ costPerGuest: value[0] })}
                  min={150}
                  max={1200}
                  step={50}
                  className="mt-2"
                />
                <div className="flex justify-between text-xs text-muted-foreground mt-1">
                  <span>₪150</span>
                  <span>₪1,200</span>
                </div>
                <div className="relative mt-2">
                  <Input
                    type="number"
                    inputMode="numeric"
                    min="100"
                    value={budgetData.costPerGuest}
                    onChange={(e) => updateBudgetData({ costPerGuest: parseInt(e.target.value) || 150 })}
                    className="min-h-[44px] focus:ring-2 focus:ring-primary pr-8"
                  />
                  <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground">₪</span>
                </div>
              </div>
              
              <Alert className="border-info bg-info/5">
                <Info className="h-4 w-4 text-info" />
                <AlertDescription className="text-info">
                  <div className="space-y-1">
                    <div>טווח מומלץ לעלות לאורח:</div>
                    <div className="text-sm">• חתונה פשוטה: ₪200-400</div>
                    <div className="text-sm">• חתונה בינונית: ₪400-700</div>
                    <div className="text-sm">• חתונה יוקרתית: ₪700-1,200</div>
                  </div>
                </AlertDescription>
              </Alert>
            </div>
            
            <Card className="bg-secondary/20">
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-semibold text-primary">
                  ₪{formatNumber(budgetData.guestCount * budgetData.costPerGuest)}
                </div>
                <div className="text-sm text-muted-foreground">סה״כ תקציב משוער</div>
              </CardContent>
            </Card>
          </div>
        );

      case 2:
        const totalBudget = budgetData.approach === 'per-guest' 
          ? budgetData.guestCount * budgetData.costPerGuest 
          : budgetData.totalBudget;
        
        return (
          <div className="space-y-6">
            <div className="text-center space-y-2">
              <UsersIcon className="w-12 h-12 text-primary mx-auto mb-4" />
              <h2>חלוקה אוטומטית לקטגוריות</h2>
              <p className="text-muted-foreground">
                עריכה מהירה של החלוקה המוצעת
              </p>
            </div>
            
            <Card>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-base">
                    סה״כ תקציב: ₪{formatNumber(totalBudget)}
                  </CardTitle>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={autoBalance}
                    className="text-muted-foreground hover:text-foreground focus:ring-2 focus:ring-primary"
                  >
                    <RotateCcw className="w-4 h-4 ml-2" />
                    איזון אוטומטי
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                {budgetData.categories.map((category) => (
                  <div key={category.id} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-medium">{category.name}</span>
                      <div className="flex items-center gap-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => updateCategoryPercentage(category.id, -1)}
                          className="h-8 w-8 p-0 focus:ring-2 focus:ring-primary"
                        >
                          <Minus className="w-3 h-3" />
                        </Button>
                        <Badge variant="secondary" className="min-w-[60px] justify-center">
                          {category.percentage.toFixed(0)}%
                        </Badge>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => updateCategoryPercentage(category.id, 1)}
                          className="h-8 w-8 p-0 focus:ring-2 focus:ring-primary"
                        >
                          <Plus className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <div className="relative flex-1 ml-4">
                        <Input
                          type="number"
                          inputMode="numeric"
                          value={category.amount}
                          onChange={(e) => {
                            const newAmount = parseInt(e.target.value) || 0;
                            const newPercentage = (newAmount / totalBudget) * 100;
                            updateCategoryPercentage(category.id, newPercentage - category.percentage);
                          }}
                          className="h-8 text-sm pr-8 focus:ring-2 focus:ring-primary"
                        />
                        <span className="absolute left-2 top-1/2 transform -translate-y-1/2 text-xs text-muted-foreground">₪</span>
                      </div>
                    </div>
                    <div className="w-full bg-secondary rounded-full h-2">
                      <div 
                        className="bg-chart-gray h-2 rounded-full transition-all duration-200" 
                        style={{ width: `${Math.min(100, category.percentage)}%` }}
                      />
                    </div>
                  </div>
                ))}
                
                <Separator />
                
                <div className="flex justify-between items-center font-semibold">
                  <span>סה״כ</span>
                  <span>
                    {budgetData.categories.reduce((sum, cat) => sum + cat.percentage, 0).toFixed(0)}%
                  </span>
                </div>
              </CardContent>
            </Card>
          </div>
        );

      case 3:
        const finalTotal = budgetData.approach === 'per-guest' 
          ? budgetData.guestCount * budgetData.costPerGuest 
          : budgetData.totalBudget;
        
        return (
          <div className="space-y-6">
            <div className="text-center space-y-2">
              <CheckCircle className="w-12 h-12 text-success mx-auto mb-4" />
              <h2>סקירה ושמירה</h2>
              <p className="text-muted-foreground">
                בדקו את פרטי התקציב לפני השמירה
              </p>
            </div>
            
            <Card>
              <CardHeader>
                <CardTitle>סיכום התקציב</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="text-center p-4 bg-secondary/20 rounded-lg">
                    <div className="text-3xl font-bold text-primary">₪{formatNumber(finalTotal)}</div>
                    <div className="text-sm text-muted-foreground">
                      {budgetData.approach === 'per-guest' 
                        ? `${budgetData.guestCount} מוזמנים × ₪${formatNumber(budgetData.costPerGuest)}`
                        : 'תקציב כולל'
                      }
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    {budgetData.categories
                      .sort((a, b) => b.amount - a.amount)
                      .map((category) => (
                        <div key={category.id} className="flex items-center justify-between py-2 border-b border-border/50 last:border-0">
                          <span>{category.name}</span>
                          <div className="flex items-center gap-3">
                            <Badge variant="outline" className="text-xs">
                              {category.percentage.toFixed(0)}%
                            </Badge>
                            <span className="font-medium">₪{formatNumber(category.amount)}</span>
                          </div>
                        </div>
                      ))}
                  </div>
                  
                  <div className="p-3 bg-info/5 border border-info/20 rounded-lg">
                    <div className="flex items-start gap-2">
                      <Info className="w-4 h-4 text-info mt-0.5" />
                      <div className="text-sm">
                        <span className="text-info font-medium">כלול מע״מ 17%</span>
                        <p className="text-muted-foreground mt-1">
                          ניתן לשנות בהגדרות המתקדמות
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-background flex items-start justify-center p-4">
      <div className="w-full max-w-2xl mt-8">
        {/* Draft banner */}
        {showDraftBanner && (
          <Alert className="mb-6 border-info bg-info/5">
            <Info className="h-4 w-4 text-info" />
            <AlertDescription className="text-info">
              נמצאה טיוטה של תכנון תקציב
              <div className="flex gap-2 mt-2">
                <Button 
                  size="sm" 
                  variant="outline" 
                  onClick={loadDraft}
                  className="h-8 text-xs border-info text-info hover:bg-info hover:text-white focus:ring-2 focus:ring-info"
                >
                  המשך מהטיוטה
                </Button>
                <Button 
                  size="sm" 
                  variant="ghost" 
                  onClick={dismissDraft}
                  className="h-8 text-xs text-info hover:bg-info/10 focus:ring-2 focus:ring-info"
                >
                  התחל מחדש
                </Button>
              </div>
            </AlertDescription>
          </Alert>
        )}

        {/* Progress indicator */}
        <div className="mb-8">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm text-muted-foreground">שלב {currentStep} מתוך {totalSteps}</span>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={onCancel}
              className="focus:ring-2 focus:ring-primary"
            >
              ביטול
            </Button>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        {/* Step content */}
        <div className="mb-8">
          {renderStep()}
        </div>

        {/* Navigation - ONE PRIMARY CTA */}
        <div className="flex gap-3">
          {currentStep > 1 && (
            <Button 
              variant="outline" 
              onClick={handleBack}
              className="focus:ring-2 focus:ring-primary min-h-[44px]"
            >
              <ArrowLeft className="w-4 h-4 ml-2" />
              חזור
            </Button>
          )}
          <Button 
            onClick={handleNext} 
            className="flex-1 min-h-[44px] focus:ring-2 focus:ring-primary"
          >
            {currentStep === totalSteps ? 'שמרו את התוכנית' : 'המשך'}
            {currentStep < totalSteps && <ArrowRight className="w-4 h-4 mr-2" />}
          </Button>
          {currentStep === 1 && (
            <Button 
              variant="ghost" 
              onClick={handleNext}
              className="focus:ring-2 focus:ring-primary min-h-[44px]"
            >
              דלגו כרגע
            </Button>
          )}
        </div>

        {/* Secondary option for step 3 */}
        {currentStep === 3 && (
          <div className="mt-4 text-center">
            <button
              onClick={() => onComplete(budgetData)}
              className="text-sm text-muted-foreground hover:text-foreground transition-colors focus:ring-2 focus:ring-primary focus:outline-none rounded px-2 py-1"
            >
              נבצע התאמות אחר-כך
            </button>
          </div>
        )}
      </div>
    </div>
  );
}