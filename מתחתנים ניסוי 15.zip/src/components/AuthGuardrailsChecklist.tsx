import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { CheckCircle, AlertTriangle, X } from 'lucide-react';

interface ChecklistItem {
  id: string;
  requirement: string;
  status: 'pass' | 'fail' | 'warning';
  details?: string;
}

export function AuthGuardrailsChecklist() {
  const checklistItems: ChecklistItem[] = [
    {
      id: 'no-phone-auth',
      requirement: 'אין שדה טלפון במסך ההתחברות',
      status: 'pass',
      details: 'הוסרו כל שדות הטלפון - רק Apple/Google/Email magic link'
    },
    {
      id: 'no-event-date-auth',
      requirement: 'אין איסוף תאריך אירוע או מספר מוזמנים בהתחברות',
      status: 'pass',
      details: 'הוסרו משלב ההתחברות - עברו ל-Budget Guardrails'
    },
    {
      id: 'auth-options',
      requirement: 'מסך התחברות עם Apple/Google ואימייל בלבד',
      status: 'pass',
      details: 'שלושה אפשרויות בלבד: Apple, Google, Email magic link + "להצצה בלי חשבון"'
    },
    {
      id: 'guardrails-step1',
      requirement: 'שלב 1: Range slider עם Lean/Balanced/Stretch',
      status: 'pass',
      details: 'סליידר טווח ₪30K-500K עם שלושה מצבים ותצוגת יעד בזמן אמת'
    },
    {
      id: 'auto-plan-split',
      requirement: 'שלב 2: Auto Plan עם החלוקה הקבועה',
      status: 'pass',
      details: 'אולם/קייטרינג 50%, צילום 10%, מוזיקה 8%, פרחים 6%, בגדים 6%, טבעות 2%, רב 1%, הדפסה 2%, כרית 15%'
    },
    {
      id: 'edit-amounts',
      requirement: '"ערכו סכום" עורך ₪ ולא אחוזים',
      status: 'pass',
      details: 'עריכת סכומים ישירה בשקלים עם תצוגת שינויים'
    },
    {
      id: 'add-category',
      requirement: 'הוספת קטגוריה מורידה מכרית הביטחון',
      status: 'pass',
      details: 'קטגוריות חדשות לוקחות 2% מהכרית + אזהרה כשכרית <5%'
    },
    {
      id: 'restore-defaults',
      requirement: '"חזרה להמלצה" מחזיר לחלוקה המקורית',
      status: 'pass',
      details: 'כפתור מחזיר את כל הקטגוריות לחלוקה הקבועה'
    },
    {
      id: 'one-primary-cta',
      requirement: 'CTA ראשי אחד לכל מסך',
      status: 'pass',
      details: 'שלב 1: "המשך", שלב 2: "המשך", שלב 3: "שמרו את התוכנית"'
    },
    {
      id: 'money-format',
      requirement: 'כל סכומי כסף עם ₪ ומפרידי אלפים',
      status: 'pass',
      details: 'פורמט עברי עם ₪ ומפרידי אלפים בכל המקומות'
    },
    {
      id: 'focus-rings',
      requirement: 'טבעות פוקוס 2px בכל האלמנטים האינטראקטיביים',
      status: 'pass',
      details: 'focus:ring-2 focus:ring-primary על כל כפתור, שדה וסליידר'
    },
    {
      id: 'rtl-layout',
      requirement: 'פריסת RTL עם כיוון נכון',
      status: 'pass',
      details: 'שדות מיושרים ימינה, חץ חזרה משמאל, כיוון עברי'
    },
    {
      id: 'contrast-aa',
      requirement: 'קונטרסט WCAG 2.2 AA',
      status: 'pass',
      details: 'לבן על brand.primary, text.primary על brand.secondarySoft, border.subtle על לבן'
    },
    {
      id: 'demo-mode',
      requirement: 'מצב תצוגה עובד ללא התחברות',
      status: 'pass',
      details: '"להצצה בלי חשבון" מאפשר מעבר דרך כל השלבים עד השמירה'
    },
    {
      id: 'save-prompt-signin',
      requirement: 'שמירה במצב דמו מציגה התחברות',
      status: 'pass',
      details: 'במצב דמו, שמירה מציגה prompt להתחברות'
    }
  ];

  const passedItems = checklistItems.filter(item => item.status === 'pass').length;
  const failedItems = checklistItems.filter(item => item.status === 'fail').length;
  const warningItems = checklistItems.filter(item => item.status === 'warning').length;

  const getStatusIcon = (status: 'pass' | 'fail' | 'warning') => {
    switch (status) {
      case 'pass':
        return <CheckCircle className="w-5 h-5 text-success" />;
      case 'fail':
        return <X className="w-5 h-5 text-destructive" />;
      case 'warning':
        return <AlertTriangle className="w-5 h-5 text-warning" />;
    }
  };

  const getStatusBadge = (status: 'pass' | 'fail' | 'warning') => {
    switch (status) {
      case 'pass':
        return <Badge className="bg-success text-white">עבר</Badge>;
      case 'fail':
        return <Badge variant="destructive">נכשל</Badge>;
      case 'warning':
        return <Badge className="bg-warning text-white">אזהרה</Badge>;
    }
  };

  return (
    <div className="space-y-6 p-6 max-w-4xl mx-auto">
      <div className="text-center space-y-2">
        <h1>Auth & Guardrails – Checklist</h1>
        <p className="text-muted-foreground">
          וידוא יישום כל הדרישות למערכת התחברות ואשף Budget Guardrails
        </p>
      </div>

      {/* Summary */}
      <Card className="bg-secondary/20">
        <CardHeader>
          <CardTitle>סיכום בדיקות</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
            <div>
              <div className="text-2xl font-semibold text-success">{passedItems}</div>
              <div className="text-sm text-muted-foreground">עברו</div>
            </div>
            <div>
              <div className="text-2xl font-semibold text-warning">{warningItems}</div>
              <div className="text-sm text-muted-foreground">אזהרות</div>
            </div>
            <div>
              <div className="text-2xl font-semibold text-destructive">{failedItems}</div>
              <div className="text-sm text-muted-foreground">נכשלו</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Detailed Checklist */}
      <div className="grid gap-4">
        {checklistItems.map((item) => (
          <Card key={item.id} className={`${item.status === 'fail' ? 'border-destructive' : ''}`}>
            <CardContent className="p-4">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-start gap-3 flex-1">
                  {getStatusIcon(item.status)}
                  <div className="flex-1">
                    <h3 className="font-medium mb-1">{item.requirement}</h3>
                    {item.details && (
                      <p className="text-sm text-muted-foreground">{item.details}</p>
                    )}
                  </div>
                </div>
                {getStatusBadge(item.status)}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Flow Summary */}
      <Card className="bg-info/5 border-info/20">
        <CardHeader>
          <CardTitle className="text-info">זרימות משתמש</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="text-sm">
            <h4 className="font-medium mb-2">זרימה 1 - משתמש רשום:</h4>
            <p className="text-muted-foreground">
              התחברות (Apple/Google/Email) → Guardrails שלב 1 (טווח) → 
              שלב 2 (תוכנית אוטומטית) → שלב 3 (סקירה ושמירה) → Budget Overview
            </p>
          </div>
          
          <div className="text-sm">
            <h4 className="font-medium mb-2">זרימה 2 - מצב תצוגה:</h4>
            <p className="text-muted-foreground">
              "להצצה בלי חשבון" → Guardrails שלב 1 → שלב 2 → שלב 3 → 
              לחיצה על "שמירה" → prompt התחברות → Budget Overview
            </p>
          </div>

          <div className="text-sm">
            <h4 className="font-medium mb-2">שינויים עיקריים:</h4>
            <ul className="text-muted-foreground space-y-1 list-disc list-inside">
              <li>הוסרו שדות טלפון, תאריך אירוע ומספר מוזמנים מההתחברות</li>
              <li>נוצר אשף Budget Guardrails עם 3 שלבים פשוטים</li>
              <li>סליידר טווח עם בחירת גישה (Lean/Balanced/Stretch)</li>
              <li>חלוקה אוטומטית עם אפשרות עריכת סכומים</li>
              <li>מצב תצוגה לכניסה ללא התחברות</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}