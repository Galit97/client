import React, { useState } from 'react';
import { Button } from '../ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Switch } from '../ui/switch';
import { Label } from '../ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Bell, BellOff, Clock, Users, CreditCard, CheckSquare, Calendar } from 'lucide-react';

interface NotificationCategory {
  id: string;
  label: string;
  description: string;
  icon: React.ComponentType<{ className?: string }>;
  enabled: boolean;
}

interface QuietHours {
  enabled: boolean;
  startTime: string;
  endTime: string;
}

export function NotificationSettings({ onBack }: { onBack: () => void }) {
  const [categories, setCategories] = useState<NotificationCategory[]>([
    {
      id: 'rsvp',
      label: 'אישורי הגעה',
      description: 'התראות על מוזמנים שמאשרים, מסרבים או משנים סטטוס',
      icon: Users,
      enabled: true
    },
    {
      id: 'suppliers',
      label: 'ספקים',
      description: 'הצעות חדשות, עדכוני מחירים ותאריכי תפוגה',
      icon: CreditCard,
      enabled: true
    },
    {
      id: 'budget',
      label: 'תקציב',
      description: 'חריגות תקציב, תשלומים קרובים והתראות חשובות',
      icon: CheckSquare,
      enabled: true
    },
    {
      id: 'milestones',
      label: 'אבני דרך',
      description: 'תזכורות למשימות חשובות ותאריכים קריטיים',
      icon: Calendar,
      enabled: false
    }
  ]);

  const [quietHours, setQuietHours] = useState<QuietHours>({
    enabled: false,
    startTime: '22:00',
    endTime: '08:00'
  });

  const [muteFor24Hours, setMuteFor24Hours] = useState(false);
  const [muteEndTime, setMuteEndTime] = useState<string | null>(null);

  const toggleCategory = (categoryId: string) => {
    setCategories(prev => 
      prev.map(cat => 
        cat.id === categoryId 
          ? { ...cat, enabled: !cat.enabled }
          : cat
      )
    );
  };

  const handleMute24Hours = () => {
    if (muteFor24Hours) {
      // Unmute
      setMuteFor24Hours(false);
      setMuteEndTime(null);
      if (window.toast) {
        window.toast.success('התראות הופעלו מחדש');
      }
    } else {
      // Mute for 24 hours
      const now = new Date();
      const endTime = new Date(now.getTime() + 24 * 60 * 60 * 1000);
      setMuteFor24Hours(true);
      setMuteEndTime(endTime.toLocaleString('he-IL'));
      if (window.toast) {
        window.toast.info('התראות הושתקו ל-24 שעות', `יופעלו מחדש ב-${endTime.toLocaleString('he-IL')}`);
      }
    }
  };

  // Generate time options (every 30 minutes)
  const timeOptions = [];
  for (let hour = 0; hour < 24; hour++) {
    for (let minute of [0, 30]) {
      const timeString = `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`;
      const displayTime = new Date(`2000-01-01T${timeString}`).toLocaleTimeString('he-IL', {
        hour: '2-digit',
        minute: '2-digit',
        hour12: false
      });
      timeOptions.push({ value: timeString, label: displayTime });
    }
  }

  return (
    <div className="min-h-screen" style={{backgroundColor: '#FFFFFF'}} dir="rtl">
      {/* Header Band */}
      <div style={{backgroundColor: '#EFF5FB'}} className="relative">
        <div className="section-header-suppliers">
          <div className="flex items-center justify-between px-4 py-6 responsive-md:px-6 responsive-lg:px-8 relative z-10">
            <Button 
              variant="ghost" 
              onClick={onBack} 
              className="focus-ring"
              style={{color: 'var(--text-primary)'}}
            >
              <span className="text-lg">←</span>
              <span className="mr-2">חזרה</span>
            </Button>

            <div className="text-center relative">
              <h1 className="section-title text-primary">
                התראות
              </h1>
            </div>

            <div className="w-20"></div>
          </div>

          {/* Decorative sparkles */}
          <div
            className="absolute -top-1 -left-4 w-1.5 h-1.5 rotate-45 opacity-45"
            style={{ backgroundColor: "#89B3E0" }}
          ></div>
          <div
            className="absolute top-0 -right-6 w-2 h-2 rotate-45 opacity-40"
            style={{ backgroundColor: "#F7D7A3" }}
          ></div>
          <div
            className="absolute -bottom-1 left-8 w-1 h-1 rotate-45 opacity-50"
            style={{ backgroundColor: "#89B3E0" }}
          ></div>
        </div>
      </div>

      <div className="px-4 py-6 responsive-md:px-6 responsive-lg:px-8">
        <div className="max-w-2xl mx-auto space-y-6">

          {/* 24-Hour Mute Card */}
          <Card className="card">
            <CardHeader>
              <CardTitle className="flex items-center gap-3">
                {muteFor24Hours ? (
                  <BellOff className="w-5 h-5" style={{color: 'var(--semantic-warning-solid)'}} />
                ) : (
                  <Bell className="w-5 h-5" style={{color: 'var(--text-secondary)'}} />
                )}
                השתקה מהירה
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {muteFor24Hours && muteEndTime && (
                <div 
                  className="p-3 rounded-lg border"
                  style={{
                    backgroundColor: 'var(--semantic-warning-bg)',
                    borderColor: 'var(--semantic-warning-border)',
                    color: 'var(--semantic-warning-text)'
                  }}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <BellOff className="w-4 h-4" />
                    <span className="font-medium">התראות מושתקות</span>
                  </div>
                  <p className="text-sm">יופעלו מחדש ב-{muteEndTime}</p>
                </div>
              )}
              
              <Button
                variant={muteFor24Hours ? "destructive" : "outline"}
                onClick={handleMute24Hours}
                className="w-full focus:ring-2 focus:ring-primary"
              >
                {muteFor24Hours ? 'בטל השתקה' : 'השתק ל-24 שעות'}
              </Button>
            </CardContent>
          </Card>

          {/* Notification Categories */}
          <Card className="card">
            <CardHeader>
              <CardTitle>קטגוריות התראות</CardTitle>
              <p style={{color: 'var(--text-secondary)'}} className="text-sm">
                בחרו איזה סוגי התראות תרצו לקבל
              </p>
            </CardHeader>
            <CardContent className="space-y-4">
              {categories.map((category) => {
                const IconComponent = category.icon;
                return (
                  <div key={category.id} className="flex items-start gap-4 p-4 rounded-lg border" style={{borderColor: 'var(--border-subtle)'}}>
                    <div 
                      className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 mt-1"
                      style={{backgroundColor: 'var(--surface-sky-50)'}}
                    >
                      <IconComponent className="w-5 h-5" style={{color: 'var(--accent-sky)'}} />
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <Label 
                        htmlFor={`category-${category.id}`}
                        className="font-medium block mb-1"
                        style={{color: 'var(--text-primary)'}}
                      >
                        {category.label}
                      </Label>
                      <p className="text-sm" style={{color: 'var(--text-secondary)'}}>
                        {category.description}
                      </p>
                    </div>
                    
                    <Switch
                      id={`category-${category.id}`}
                      checked={category.enabled && !muteFor24Hours}
                      onCheckedChange={() => toggleCategory(category.id)}
                      disabled={muteFor24Hours}
                      className="focus:ring-2 focus:ring-primary"
                    />
                  </div>
                );
              })}
            </CardContent>
          </Card>

          {/* Quiet Hours */}
          <Card className="card">
            <CardHeader>
              <CardTitle className="flex items-center gap-3">
                <Clock className="w-5 h-5" style={{color: 'var(--text-secondary)'}} />
                שעות שקטות
              </CardTitle>
              <p style={{color: 'var(--text-secondary)'}} className="text-sm">
                הגדירו תקופה בה לא תתקבלו התראות
              </p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <Label htmlFor="quiet-hours-toggle" className="font-medium">
                  הפעל שעות שקטות
                </Label>
                <Switch
                  id="quiet-hours-toggle"
                  checked={quietHours.enabled}
                  onCheckedChange={(checked) => 
                    setQuietHours(prev => ({ ...prev, enabled: checked }))
                  }
                  className="focus:ring-2 focus:ring-primary"
                />
              </div>

              {quietHours.enabled && (
                <div className="grid grid-cols-2 gap-4 p-4 rounded-lg" style={{backgroundColor: 'var(--base-bg)'}}>
                  <div>
                    <Label htmlFor="start-time" className="text-sm mb-2 block">
                      התחלה
                    </Label>
                    <Select
                      value={quietHours.startTime}
                      onValueChange={(value) => 
                        setQuietHours(prev => ({ ...prev, startTime: value }))
                      }
                    >
                      <SelectTrigger className="focus:ring-2 focus:ring-primary">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {timeOptions.map(option => (
                          <SelectItem key={option.value} value={option.value}>
                            {option.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="end-time" className="text-sm mb-2 block">
                      סיום
                    </Label>
                    <Select
                      value={quietHours.endTime}
                      onValueChange={(value) => 
                        setQuietHours(prev => ({ ...prev, endTime: value }))
                      }
                    >
                      <SelectTrigger className="focus:ring-2 focus:ring-primary">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {timeOptions.map(option => (
                          <SelectItem key={option.value} value={option.value}>
                            {option.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Test Notifications */}
          <Card className="card">
            <CardHeader>
              <CardTitle>בדיקת התראות</CardTitle>
              <p style={{color: 'var(--text-secondary)'}} className="text-sm">
                שלחו התראות דוגמה כדי לבדוק שהגדרות עובדות
              </p>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-3">
                <Button
                  variant="outline"
                  onClick={() => {
                    if (window.toast) {
                      window.toast.info('בדיקה', 'זוהי התראת מידע לדוגמה');
                    }
                  }}
                  className="focus:ring-2 focus:ring-primary"
                >
                  בדיקת מידע
                </Button>
                <Button
                  variant="outline"
                  onClick={() => {
                    if (window.toast) {
                      window.toast.success('בדיקה', 'זוהי התראת הצלחה לדוגמה');
                    }
                  }}
                  className="focus:ring-2 focus:ring-primary"
                >
                  בדיקת הצלחה
                </Button>
                <Button
                  variant="outline"
                  onClick={() => {
                    if (window.toast) {
                      window.toast.warning('בדיקה', 'זוהי התראת אזהרה לדוגמה');
                    }
                  }}
                  className="focus:ring-2 focus:ring-primary"
                >
                  בדיקת אזהרה
                </Button>
                <Button
                  variant="outline"
                  onClick={() => {
                    if (window.toast) {
                      window.toast.error('בדיקה', 'זוהי התראת שגיאה לדוגמה');
                    }
                  }}
                  className="focus:ring-2 focus:ring-primary"
                >
                  בדיקת שגיאה
                </Button>
              </div>
            </CardContent>
          </Card>

        </div>
      </div>
    </div>
  );
}