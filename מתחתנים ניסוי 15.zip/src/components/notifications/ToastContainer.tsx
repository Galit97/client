import React, { useState, useCallback } from 'react';
import { Toast, ToastProps, ToastType } from './Toast';

export interface ToastData {
  type: ToastType;
  title: string;
  message?: string;
  action?: {
    label: string;
    onClick: () => void;
  };
  autoClose?: boolean;
  duration?: number;
}

let toastCounter = 0;

export function ToastContainer() {
  const [toasts, setToasts] = useState<ToastProps[]>([]);

  const addToast = useCallback((data: ToastData) => {
    const id = `toast-${++toastCounter}`;
    const toast: ToastProps = {
      id,
      ...data,
      onDismiss: (dismissId) => {
        setToasts(prev => prev.filter(t => t.id !== dismissId));
      }
    };
    
    setToasts(prev => [...prev, toast]);
    return id;
  }, []);

  const removeToast = useCallback((id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  }, []);

  const removeAllToasts = useCallback(() => {
    setToasts([]);
  }, []);

  // Expose API globally for easy access
  React.useEffect(() => {
    (window as any).toast = {
      show: addToast,
      info: (title: string, message?: string, action?: ToastData['action']) => 
        addToast({ type: 'info', title, message, action }),
      success: (title: string, message?: string, action?: ToastData['action']) => 
        addToast({ type: 'success', title, message, action }),
      warning: (title: string, message?: string, action?: ToastData['action']) => 
        addToast({ type: 'warning', title, message, action }),
      error: (title: string, message?: string, action?: ToastData['action']) => 
        addToast({ type: 'negative', title, message, action }),
      remove: removeToast,
      clear: removeAllToasts
    };
  }, [addToast, removeToast, removeAllToasts]);

  if (toasts.length === 0) return null;

  return (
    <div className="fixed top-4 left-4 z-50 flex flex-col gap-2 pointer-events-none">
      {toasts.map(toast => (
        <div key={toast.id} className="pointer-events-auto">
          <Toast {...toast} />
        </div>
      ))}
    </div>
  );
}

// Type definitions for global toast API
declare global {
  interface Window {
    toast: {
      show: (data: ToastData) => string;
      info: (title: string, message?: string, action?: ToastData['action']) => string;
      success: (title: string, message?: string, action?: ToastData['action']) => string;
      warning: (title: string, message?: string, action?: ToastData['action']) => string;
      error: (title: string, message?: string, action?: ToastData['action']) => string;
      remove: (id: string) => void;
      clear: () => void;
    };
  }
}