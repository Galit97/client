import React, { useState } from 'react';
import { X, AlertTriangle, Info, AlertCircle } from 'lucide-react';
import { Button } from '../ui/button';

export type BannerType = 'info' | 'warning' | 'alert';

export interface TopBannerProps {
  id: string;
  type: BannerType;
  title: string;
  message?: string;
  action?: {
    label: string;
    onClick: () => void;
  };
  dismissible?: boolean;
  onDismiss?: (id: string) => void;
}

const bannerStyles: Record<BannerType, {
  bgColor: string;
  borderColor: string;
  iconColor: string;
  textColor: string;
  icon: React.ComponentType<{ className?: string }>;
}> = {
  info: {
    bgColor: 'var(--semantic-info-bg)',
    borderColor: 'var(--semantic-info-border)',
    iconColor: 'var(--semantic-info-solid)',
    textColor: 'var(--semantic-info-text)',
    icon: Info
  },
  warning: {
    bgColor: 'var(--semantic-warning-bg)',
    borderColor: 'var(--semantic-warning-border)',
    iconColor: 'var(--semantic-warning-solid)',
    textColor: 'var(--semantic-warning-text)',
    icon: AlertTriangle
  },
  alert: {
    bgColor: 'var(--semantic-danger-bg)',
    borderColor: 'var(--semantic-danger-border)',
    iconColor: 'var(--semantic-danger-solid)',
    textColor: 'var(--semantic-danger-text)',
    icon: AlertCircle
  }
};

export function TopBanner({
  id,
  type,
  title,
  message,
  action,
  dismissible = true,
  onDismiss
}: TopBannerProps) {
  const [isVisible, setIsVisible] = useState(true);
  const [isLeaving, setIsLeaving] = useState(false);

  const style = bannerStyles[type];
  const IconComponent = style.icon;

  const handleDismiss = () => {
    if (!dismissible || !onDismiss) return;
    
    setIsLeaving(true);
    setTimeout(() => {
      setIsVisible(false);
      onDismiss(id);
    }, 200);
  };

  if (!isVisible) return null;

  return (
    <div
      className={`
        banner-container
        ${isLeaving ? 'banner-exit' : 'banner-enter'}
      `}
      style={{
        backgroundColor: style.bgColor,
        borderBottomColor: style.borderColor,
        color: style.textColor
      }}
      dir="rtl"
      role="banner"
      aria-live="polite"
    >
      <div className="max-w-7xl mx-auto px-4 py-3">
        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 flex-1 min-w-0">
            <IconComponent 
              className="w-5 h-5 flex-shrink-0"
              style={{ color: style.iconColor }}
              aria-hidden="true"
            />
            
            <div className="flex-1 min-w-0">
              <h4 className="font-medium" style={{ color: style.textColor }}>
                {title}
              </h4>
              {message && (
                <p className="text-sm mt-1 opacity-90" style={{ color: style.textColor }}>
                  {message}
                </p>
              )}
            </div>
          </div>

          <div className="flex items-center gap-2">
            {action && (
              <Button
                variant="outline"
                size="sm"
                onClick={action.onClick}
                className="h-8 px-4 text-sm border-current hover:bg-current hover:bg-opacity-10 focus:ring-2 focus:ring-current"
                style={{ borderColor: style.iconColor, color: style.iconColor }}
              >
                {action.label}
              </Button>
            )}
            
            {dismissible && (
              <Button
                variant="ghost"
                size="sm"
                onClick={handleDismiss}
                className="h-8 w-8 p-0 hover:bg-current hover:bg-opacity-10 focus:ring-2 focus:ring-current"
                style={{ color: style.iconColor }}
                aria-label="סגור התראה"
              >
                <X className="w-4 h-4" />
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// Banner container styles
const bannerContainerStyles = `
  .banner-container {
    position: sticky;
    top: 0;
    z-index: 40;
    width: 100%;
    border-bottom: 1px solid;
    backdrop-filter: blur(8px);
    transform: translateY(-100%);
    opacity: 0;
    transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
  }

  .banner-enter {
    transform: translateY(0);
    opacity: 1;
  }

  .banner-exit {
    transform: translateY(-100%);
    opacity: 0;
  }

  /* Respect reduced motion preference */
  @media (prefers-reduced-motion: reduce) {
    .banner-container {
      transition: opacity 0.2s ease;
      transform: none !important;
    }
    
    .banner-enter {
      opacity: 1;
    }
    
    .banner-exit {
      opacity: 0;
    }
  }
`;

// Inject styles into head if not already present
if (typeof document !== 'undefined' && !document.getElementById('banner-styles')) {
  const style = document.createElement('style');
  style.id = 'banner-styles';
  style.textContent = bannerContainerStyles;
  document.head.appendChild(style);
}