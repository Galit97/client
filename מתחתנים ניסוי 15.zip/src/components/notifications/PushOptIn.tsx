import React, { useState } from 'react';
import { Button } from '../ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Bell, Smartphone, CheckCircle, X, MessageSquare, Calendar, CreditCard } from 'lucide-react';

type PushOptInStep = 'explainer' | 'request' | 'success' | 'declined';

export function PushOptIn({ onComplete }: { onComplete: () => void }) {
  const [currentStep, setCurrentStep] = useState<PushOptInStep>('explainer');

  const handleEnableNotifications = () => {
    setCurrentStep('request');
    
    // Simulate permission request (in real app this would be actual browser API)
    setTimeout(() => {
      // Mock random success/failure for demo
      const granted = Math.random() > 0.3; // 70% success rate
      setCurrentStep(granted ? 'success' : 'declined');
    }, 2000);
  };

  const handleSkip = () => {
    setCurrentStep('declined');
  };

  const renderExplainerStep = () => (
    <div className="text-center space-y-6">
      <div 
        className="w-20 h-20 mx-auto rounded-full flex items-center justify-center"
        style={{backgroundColor: 'var(--surface-sky-50)'}}
      >
        <Bell className="w-10 h-10" style={{color: 'var(--accent-sky)'}} />
      </div>

      <div className="space-y-3">
        <h2 className="text-2xl font-semibold" style={{color: 'var(--text-primary)'}}>
          הישארו מעודכנים
        </h2>
        <p style={{color: 'var(--text-secondary)'}} className="text-lg leading-relaxed">
          קבלו התראות חשובות על החתונה שלכם ישירות למכשיר
        </p>
      </div>

      <div className="grid gap-4 text-right">
        <div className="flex items-center gap-3 p-3 rounded-lg" style={{backgroundColor: 'var(--base-bg)'}}>
          <div 
            className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0"
            style={{backgroundColor: 'var(--surface-rose-50)'}}
          >
            <MessageSquare className="w-4 h-4" style={{color: 'var(--accent-rose)'}} />
          </div>
          <div>
            <h4 className="font-medium" style={{color: 'var(--text-primary)'}}>אישורי הגעה</h4>
            <p className="text-sm" style={{color: 'var(--text-secondary)'}}>התראות כשמוזמנים מאשרים או מסרבים</p>
          </div>
        </div>

        <div className="flex items-center gap-3 p-3 rounded-lg" style={{backgroundColor: 'var(--base-bg)'}}>
          <div 
            className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0"
            style={{backgroundColor: 'var(--surface-gold-50)'}}
          >
            <Calendar className="w-4 h-4" style={{color: 'var(--accent-gold)'}} />
          </div>
          <div>
            <h4 className="font-medium" style={{color: 'var(--text-primary)'}}>תאריכים חשובים</h4>
            <p className="text-sm" style={{color: 'var(--text-secondary)'}}>תזכורות למשימות ותשלומים קרובים</p>
          </div>
        </div>

        <div className="flex items-center gap-3 p-3 rounded-lg" style={{backgroundColor: 'var(--base-bg)'}}>
          <div 
            className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0"
            style={{backgroundColor: 'var(--surface-sage-50)'}}
          >
            <CreditCard className="w-4 h-4" style={{color: 'var(--accent-sage)'}} />
          </div>
          <div>
            <h4 className="font-medium" style={{color: 'var(--text-primary)'}}>התראות תקציב</h4>
            <p className="text-sm" style={{color: 'var(--text-secondary)'}}>עדכונים על חריגות והזדמנויות לחיסכון</p>
          </div>
        </div>
      </div>

      <div className="space-y-3 pt-4">
        <Button
          onClick={handleEnableNotifications}
          className="btn-primary w-full focus:ring-2 focus:ring-primary"
        >
          הפעילו התראות
        </Button>
        <Button
          variant="ghost"
          onClick={handleSkip}
          className="w-full focus:ring-2 focus:ring-primary"
          style={{color: 'var(--text-secondary)'}}
        >
          דלגו כרגע
        </Button>
      </div>

      <div className="text-xs" style={{color: 'var(--text-muted)'}}>
        תוכלו לשנות את ההגדרות בכל עת דרך הגדרות האפליקציה
      </div>
    </div>
  );

  const renderRequestStep = () => (
    <div className="text-center space-y-6">
      <div 
        className="w-20 h-20 mx-auto rounded-full flex items-center justify-center animate-pulse"
        style={{backgroundColor: 'var(--surface-sky-50)'}}
      >
        <Smartphone className="w-10 h-10" style={{color: 'var(--accent-sky)'}} />
      </div>

      <div className="space-y-3">
        <h2 className="text-2xl font-semibold" style={{color: 'var(--text-primary)'}}>
          אישור הרשאה
        </h2>
        <p style={{color: 'var(--text-secondary)'}} className="text-lg leading-relaxed">
          הדפדפן יבקש אישור להצגת התראות
        </p>
      </div>

      <div 
        className="p-4 rounded-lg border"
        style={{
          backgroundColor: 'var(--semantic-info-bg)',
          borderColor: 'var(--semantic-info-border)'
        }}
      >
        <p className="text-sm" style={{color: 'var(--semantic-info-text)'}}>
          במידה ולא הופיע חלון קופץ, בדקו שלא חסמתם התראות בהגדרות הדפדפן
        </p>
      </div>

      <div className="space-y-3">
        <div className="flex items-center justify-center gap-2" style={{color: 'var(--text-muted)'}}>
          <div className="w-2 h-2 rounded-full bg-current animate-pulse"></div>
          <div className="w-2 h-2 rounded-full bg-current animate-pulse" style={{animationDelay: '0.2s'}}></div>
          <div className="w-2 h-2 rounded-full bg-current animate-pulse" style={{animationDelay: '0.4s'}}></div>
        </div>
        <p className="text-sm" style={{color: 'var(--text-muted)'}}>
          ממתינים לאישור...
        </p>
      </div>
    </div>
  );

  const renderSuccessStep = () => (
    <div className="text-center space-y-6">
      <div 
        className="w-20 h-20 mx-auto rounded-full flex items-center justify-center"
        style={{backgroundColor: 'var(--semantic-success-bg)'}}
      >
        <CheckCircle className="w-10 h-10" style={{color: 'var(--semantic-success-solid)'}} />
      </div>

      <div className="space-y-3">
        <h2 className="text-2xl font-semibold" style={{color: 'var(--text-primary)'}}>
          מעולה! התראות הופעלו
        </h2>
        <p style={{color: 'var(--text-secondary)'}} className="text-lg leading-relaxed">
          תקבלו התראות על עדכונים חשובים בחתונה שלכם
        </p>
      </div>

      <div 
        className="p-4 rounded-lg border text-right"
        style={{
          backgroundColor: 'var(--semantic-success-bg)',
          borderColor: 'var(--semantic-success-border)'
        }}
      >
        <h4 className="font-medium mb-2" style={{color: 'var(--semantic-success-text)'}}>
          עכשיו תוכלו לקבל:
        </h4>
        <ul className="text-sm space-y-1" style={{color: 'var(--semantic-success-text)'}}>
          <li>• התראות על אישורי הגעה חדשים</li>
          <li>• תזכורות למשימות חשובות</li>
          <li>• התראות על תשלומים קרובים</li>
          <li>• עדכוני תקציב וחריגות</li>
        </ul>
      </div>

      <Button
        onClick={onComplete}
        className="btn-primary w-full focus:ring-2 focus:ring-primary"
      >
        המשיכו לאפליקציה
      </Button>

      <div className="text-xs" style={{color: 'var(--text-muted)'}}>
        ניתן לכבות התראות בכל עת דרך הגדרות ההתראות
      </div>
    </div>
  );

  const renderDeclinedStep = () => (
    <div className="text-center space-y-6">
      <div 
        className="w-20 h-20 mx-auto rounded-full flex items-center justify-center"
        style={{backgroundColor: 'var(--surface-sky-50)'}}
      >
        <Bell className="w-10 h-10" style={{color: 'var(--text-muted)'}} />
      </div>

      <div className="space-y-3">
        <h2 className="text-2xl font-semibold" style={{color: 'var(--text-primary)'}}>
          בסדר גמור
        </h2>
        <p style={{color: 'var(--text-secondary)'}} className="text-lg leading-relaxed">
          תוכלו להפעיל התראות בכל עת דרך הגדרות האפליקציה
        </p>
      </div>

      <div 
        className="p-4 rounded-lg border text-right"
        style={{
          backgroundColor: 'var(--semantic-info-bg)',
          borderColor: 'var(--semantic-info-border)'
        }}
      >
        <h4 className="font-medium mb-2" style={{color: 'var(--semantic-info-text)'}}>
          בלי התראות תפספסו:
        </h4>
        <ul className="text-sm space-y-1" style={{color: 'var(--semantic-info-text)'}}>
          <li>• עדכונים מיידיים על אישורי הגעה</li>
          <li>• תזכורות למשימות קריטיות</li>
          <li>• התראות על תשלומים בדקה ה-90</li>
        </ul>
      </div>

      <div className="space-y-3">
        <Button
          onClick={handleEnableNotifications}
          variant="outline"
          className="w-full focus:ring-2 focus:ring-primary"
        >
          בכל זאת הפעילו התראות
        </Button>
        <Button
          onClick={onComplete}
          className="btn-primary w-full focus:ring-2 focus:ring-primary"
        >
          המשיכו ללא התראות
        </Button>
      </div>

      <div className="text-xs" style={{color: 'var(--text-muted)'}}>
        תמיד תוכלו להפעיל התראות דרך הגדרות › התראות
      </div>
    </div>
  );

  return (
    <div className="min-h-screen flex items-center justify-center p-4" style={{backgroundColor: '#FAFAFA'}} dir="rtl">
      <Card className="w-full max-w-md">
        <CardContent className="p-8">
          {currentStep === 'explainer' && renderExplainerStep()}
          {currentStep === 'request' && renderRequestStep()}
          {currentStep === 'success' && renderSuccessStep()}
          {currentStep === 'declined' && renderDeclinedStep()}
        </CardContent>
      </Card>
    </div>
  );
}