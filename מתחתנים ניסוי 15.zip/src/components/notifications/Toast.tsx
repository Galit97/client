import React, { useEffect, useState } from 'react';
import { X, CheckCircle, Info, AlertTriangle, AlertCircle } from 'lucide-react';
import { Button } from '../ui/button';

export type ToastType = 'info' | 'success' | 'warning' | 'negative';

export interface ToastProps {
  id: string;
  type: ToastType;
  title: string;
  message?: string;
  action?: {
    label: string;
    onClick: () => void;
  };
  onDismiss: (id: string) => void;
  autoClose?: boolean;
  duration?: number;
}

const toastStyles: Record<ToastType, { 
  bgColor: string; 
  borderColor: string; 
  iconColor: string; 
  textColor: string;
  icon: React.ComponentType<{ className?: string }>;
}> = {
  info: {
    bgColor: 'var(--semantic-info-bg)',
    borderColor: 'var(--semantic-info-border)',
    iconColor: 'var(--semantic-info-solid)',
    textColor: 'var(--semantic-info-text)',
    icon: Info
  },
  success: {
    bgColor: 'var(--semantic-success-bg)',
    borderColor: 'var(--semantic-success-border)', 
    iconColor: 'var(--semantic-success-solid)',
    textColor: 'var(--semantic-success-text)',
    icon: CheckCircle
  },
  warning: {
    bgColor: 'var(--semantic-warning-bg)',
    borderColor: 'var(--semantic-warning-border)',
    iconColor: 'var(--semantic-warning-solid)', 
    textColor: 'var(--semantic-warning-text)',
    icon: AlertTriangle
  },
  negative: {
    bgColor: 'var(--semantic-danger-bg)',
    borderColor: 'var(--semantic-danger-border)',
    iconColor: 'var(--semantic-danger-solid)',
    textColor: 'var(--semantic-danger-text)', 
    icon: AlertCircle
  }
};

export function Toast({ 
  id, 
  type, 
  title, 
  message, 
  action, 
  onDismiss, 
  autoClose = true, 
  duration = 2500 
}: ToastProps) {
  const [isVisible, setIsVisible] = useState(false);
  const [isLeaving, setIsLeaving] = useState(false);
  
  const style = toastStyles[type];
  const IconComponent = style.icon;

  useEffect(() => {
    // Entrance animation
    const timer = setTimeout(() => setIsVisible(true), 50);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    if (!autoClose) return;

    const timer = setTimeout(() => {
      handleDismiss();
    }, duration);

    return () => clearTimeout(timer);
  }, [autoClose, duration]);

  const handleDismiss = () => {
    setIsLeaving(true);
    // Wait for animation to complete before removing from DOM
    setTimeout(() => onDismiss(id), 200);
  };

  return (
    <div
      className={`
        toast-container
        ${isVisible ? 'toast-enter' : ''}
        ${isLeaving ? 'toast-exit' : ''}
      `}
      style={{
        backgroundColor: style.bgColor,
        borderColor: style.borderColor,
        color: style.textColor
      }}
      dir="rtl"
      role="alert"
      aria-live="polite"
    >
      <div className="flex items-start gap-3 flex-1">
        <IconComponent 
          className="w-5 h-5 mt-0.5 flex-shrink-0"
          style={{ color: style.iconColor }}
          aria-hidden="true"
        />
        
        <div className="flex-1 min-w-0">
          <h4 className="font-medium mb-1" style={{ color: style.textColor }}>
            {title}
          </h4>
          {message && (
            <p className="text-sm opacity-90" style={{ color: style.textColor }}>
              {message}
            </p>
          )}
        </div>
      </div>

      <div className="flex items-center gap-2 mt-2">
        {action && (
          <Button
            variant="outline"
            size="sm"
            onClick={action.onClick}
            className="h-8 px-3 text-xs border-current hover:bg-current hover:bg-opacity-10 focus:ring-2 focus:ring-current"
            style={{ borderColor: style.iconColor, color: style.iconColor }}
          >
            {action.label}
          </Button>
        )}
        
        <Button
          variant="ghost"
          size="sm"
          onClick={handleDismiss}
          className="h-8 w-8 p-0 hover:bg-current hover:bg-opacity-10 focus:ring-2 focus:ring-current"
          style={{ color: style.iconColor }}
          aria-label="סגור התראה"
        >
          <X className="w-4 h-4" />
        </Button>
      </div>
    </div>
  );
}

// Toast container styles
const toastContainerStyles = `
  .toast-container {
    position: relative;
    width: 100%;
    max-width: 400px;
    padding: 16px;
    border: 1px solid;
    border-radius: 12px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    transform: translateX(100%);
    opacity: 0;
    transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1);
  }

  .toast-enter {
    transform: translateX(0);
    opacity: 1;
  }

  .toast-exit {
    transform: translateX(100%);
    opacity: 0;
  }

  /* Respect reduced motion preference */
  @media (prefers-reduced-motion: reduce) {
    .toast-container {
      transition: opacity 0.2s ease;
      transform: none !important;
    }
    
    .toast-enter {
      opacity: 1;
    }
    
    .toast-exit {
      opacity: 0;
    }
  }
`;

// Inject styles into head if not already present
if (typeof document !== 'undefined' && !document.getElementById('toast-styles')) {
  const style = document.createElement('style');
  style.id = 'toast-styles';
  style.textContent = toastContainerStyles;
  document.head.appendChild(style);
}