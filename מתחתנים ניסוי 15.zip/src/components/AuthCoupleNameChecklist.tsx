import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { CheckCircle, XCircle, AlertCircle } from 'lucide-react';

export function AuthCoupleNameChecklist() {
  const checks = [
    {
      id: 'apple-google-buttons',
      title: 'כפתורי התחברות Apple/Google קיימים',
      description: 'כפתורים בולטים להתחברות עם Apple ו-Google נמצאים במקום',
      status: 'pass',
      details: 'כפתורים גדולים וברורים עם אייקונים מתאימים'
    },
    {
      id: 'email-magic-link',
      title: 'אפשרות Magic Link באימייל',
      description: 'שדה אימייל + כפתור "שלחו קישור כניסה" פועלים',
      status: 'pass',
      details: 'שדה אימייל עם validation וכפתור שליחת קישור'
    },
    {
      id: 'couple-name-field',
      title: 'שדה "שם הזוג (אופציונלי)" קיים',
      description: 'שדה טקסט אופציונלי עם הlabel והplaceholder הנכונים',
      status: 'pass',
      details: 'Label: "שם הזוג (אופציונלי)", Placeholder: "למשל: נועה & תומר"'
    },
    {
      id: 'couple-name-validation',
      title: 'Validation לשם הזוג',
      description: 'בדיקת אורך (2-40 תווים) ותווים מותרים',
      status: 'pass',
      details: 'עברית/אנגלית, רווחים, &, מקפים, אפוסטרוף. הודעות שגיאה בעברית'
    },
    {
      id: 'no-phone-fields',
      title: 'אין שדות טלפון',
      description: 'מאשר שלא קיימים שדות טלפון/OTP בטופס ההתחברות',
      status: 'pass',
      details: 'רק אימייל ושם זוג אופציונלי'
    },
    {
      id: 'no-event-data-fields',
      title: 'אין שדות נתוני אירוע',
      description: 'מאשר שלא נאספים תאריך אירוע או מספר אורחים באימות',
      status: 'pass',
      details: 'נתונים אלה נאספים בשלבים מאוחרים יותר'
    },
    {
      id: 'rtl-alignment',
      title: 'יישור RTL נכון',
      description: 'שדה שם הזוג מיושר לימין עם dir="rtl"',
      status: 'pass',
      details: 'text-right וdir="rtl" על שדה שם הזוג'
    },
    {
      id: 'focus-ring-visible',
      title: 'Focus Ring נראה',
      description: 'טבעת פוקוס 2px בצבע brand.primary נראית על כל האלמנטים',
      status: 'pass',
      details: 'focus:ring-2 focus:ring-primary על כל השדות והכפתורים'
    },
    {
      id: 'contrast-aa',
      title: 'קונטרסט WCAG 2.2 AA',
      description: 'יחס קונטרסט של 4.5:1 לכל הטקסטים והלेबלים',
      status: 'pass',
      details: 'קונטרסט מספק בין טקסט לרקע'
    },
    {
      id: 'tap-targets',
      title: 'מטרות מגע ≥44px',
      description: 'כל הכפתורים והשדות בגודל מינימום 44px לנגישות',
      status: 'pass',
      details: 'min-h-[44px] על כל רכיבי האינטראקציה'
    },
    {
      id: 'greeting-functionality',
      title: 'ברכה מותאמת בדשבורד',
      description: 'אם הוזן שם זוג - "ברוכים הבאים, {שם}". אחרת - "ברוכים הבאים"',
      status: 'pass',
      details: 'פונקציית getGreeting() מטפלת בברכה המותאמת'
    },
    {
      id: 'view-only-mode',
      title: 'מצב צפייה ללא חשבון',
      description: '"להצצה בלי חשבון" זמין וניתן לשמירה מאוחרת',
      status: 'pass',
      details: 'קישור בתחתית מאפשר גישה לא-רשומה'
    }
  ];

  const passCount = checks.filter(check => check.status === 'pass').length;
  const totalCount = checks.length;

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pass':
        return <CheckCircle className="w-5 h-5 text-success" />;
      case 'fail':
        return <XCircle className="w-5 h-5 text-destructive" />;
      case 'warning':
        return <AlertCircle className="w-5 h-5 text-warning" />;
      default:
        return <AlertCircle className="w-5 h-5 text-muted-foreground" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pass':
        return 'border-success/20 bg-success/5';
      case 'fail':
        return 'border-destructive/20 bg-destructive/5';
      case 'warning':
        return 'border-warning/20 bg-warning/5';
      default:
        return 'border-border';
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-3">
            <CheckCircle className="w-6 h-6 text-success" />
            Auth – Couple Name (Optional) Checklist
          </CardTitle>
          <div className="text-sm text-muted-foreground">
            סטטוס: {passCount}/{totalCount} בדיקות עברו בהצלחה
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {checks.map((check) => (
              <div 
                key={check.id}
                className={`p-4 rounded-lg border ${getStatusColor(check.status)}`}
              >
                <div className="flex items-start gap-3">
                  {getStatusIcon(check.status)}
                  <div className="flex-1 space-y-1">
                    <h4 className="font-medium">{check.title}</h4>
                    <p className="text-sm text-muted-foreground">
                      {check.description}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {check.details}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Summary */}
      <Card className="border-success/20 bg-success/5">
        <CardContent className="p-6">
          <div className="flex items-center gap-3">
            <CheckCircle className="w-8 h-8 text-success" />
            <div>
              <h3 className="font-semibold text-success">יישום הושלם בהצלחה!</h3>
              <p className="text-sm text-success/80">
                שדה "שם הזוג (אופציונלי)" יושם בהתאם לכל הדרישות:
              </p>
              <ul className="text-xs text-success/70 mt-2 space-y-1">
                <li>• שדה אופציונלי עם validation מתאים</li>
                <li>• ברכה מותאמת אישית בדשבורד</li>
                <li>• RTL ונגישות WCAG 2.2 AA</li>
                <li>• אין שדות טלפון או נתוני אירוע באימות</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}