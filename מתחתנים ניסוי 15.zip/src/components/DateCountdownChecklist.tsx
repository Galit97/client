import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { CheckCircle2, XCircle, Clock, Calendar, User, Edit3 } from 'lucide-react';

export function DateCountdownChecklist() {
  const checks = [
    {
      id: 'couple-name-auto-fill',
      title: 'הקלדת "שם הזוג" ממלאת את "שם האירוע" אוטומטית',
      description: 'כשמקלידים שם זוג, שדה האירוע צריך להתמלא ב"החתונה של ..." עד שמשתמש עורך ידנית',
      icon: User,
      status: 'pending' as const
    },
    {
      id: 'event-name-manual-edit',
      title: 'עריכה ידנית של שם האירוע מפסיקה מילוי אוטומטי',
      description: 'ברגע שמשתמש לוחץ בשדה "שם האירוע" או מקליד בו, המילוי האוטומטי צריך להפסק',
      icon: Edit3,
      status: 'pending' as const
    },
    {
      id: 'date-saves-correctly',
      title: 'שמירת תאריך מעבירה לדשבורד עם CountdownHero',
      description: 'כשבוחרים תאריך ולוחצים "שמרו תאריך", צריך לעבור לדשבורד עם CountdownHero במקום כרטיס בחירת תאריך',
      icon: Calendar,
      status: 'pending' as const
    },
    {
      id: 'days-calculation',
      title: 'חישוב ימים נותרים מדויק',
      description: 'המספר ימים ב-CountdownHero צריך להתאים להפרש בין היום הנוכחי לתאריך הנבחר',
      icon: Clock,
      status: 'pending' as const
    },
    {
      id: 'hero-gradient-animation',
      title: 'אנימציית רקע של CountdownHero',
      description: 'הרקע צריך לעבור בין שני variants (A/B) כל 10 שניות עם אנימציה חלקה',
      icon: CheckCircle2,
      status: 'pending' as const
    },
    {
      id: 'hero-text-contrast',
      title: 'ניגודיות טקסט בCountdownHero',
      description: 'כל הטקסט על הרקע המונפש צריך להיות קריא (AA compliance) עם שכבת scrim',
      icon: CheckCircle2,
      status: 'pending' as const
    }
  ];

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'passed':
        return <CheckCircle2 className="w-5 h-5 text-green-600" />;
      case 'failed':
        return <XCircle className="w-5 h-5 text-red-600" />;
      default:
        return <Clock className="w-5 h-5 text-gray-400" />;
    }
  };

  return (
    <Card className="max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Calendar className="w-6 h-6" />
          צ'קליסט - בחירת תאריך וספירה לאחור
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {checks.map((check) => (
            <div key={check.id} className="flex gap-3 p-4 rounded-lg border border-gray-200">
              <div className="flex-shrink-0 mt-1">
                {getStatusIcon(check.status)}
              </div>
              <div className="flex-1">
                <div className="flex items-start gap-2 mb-2">
                  <check.icon className="w-4 h-4 mt-0.5 text-gray-500" />
                  <h3 className="font-medium text-right flex-1">{check.title}</h3>
                </div>
                <p className="text-sm text-gray-600 text-right">{check.description}</p>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-8 p-4 bg-gray-50 rounded-lg">
          <h4 className="font-medium text-right mb-2">הוראות בדיקה:</h4>
          <ol className="text-sm text-gray-600 space-y-1 text-right list-none">
            <li>1. היכנסו לעמוד בחירת התאריך</li>
            <li>2. הקלידו שם זוג ובדקו שהשדה השני מתמלא אוטומטית</li>
            <li>3. לחצו על שדה שם האירוע ובדקו שהמילוי האוטומטי נפסק</li>
            <li>4. בחרו תאריך ושמרו</li>
            <li>5. בדקו שהדשבורד מציג CountdownHero במקום כרטיס בחירת תאריך</li>
            <li>6. בדקו שמספר הימים נכון וניתן לקרוא את הטקסט על הרקע</li>
          </ol>
        </div>
      </CardContent>
    </Card>
  );
}