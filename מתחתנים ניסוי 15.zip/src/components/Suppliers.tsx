import React, { useState } from 'react';
import { BackButton } from './ui/back-button';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Textarea } from './ui/textarea';
import { SupplierModal } from './suppliers/SupplierModal';
import { SupplierCommitmentModal } from './suppliers/SupplierCommitmentModal';
import { SupplierStatusBadge } from './suppliers/SupplierStatusBadge';
import { Plus, Search, Filter, Phone, Mail, MoreVertical, CheckCircle, Calendar, FileText } from 'lucide-react';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from './ui/dropdown-menu';

interface BudgetVars {
  forecastTotal: number;
}

interface SuppliersVars {
  committedCount: number;
  vendor1_visible: boolean;
  vendor1_name: string;
  vendor1_category: string;
  vendor1_status: string;
  vendor1_email: string;
  vendor1_phone: string;
  vendor1_finalAmount: number;
  vendor1_deposit: number;
  vendor1_remaining: number;
  vendor1_notes: string;
  vendor1_offerExpiry: string;
  vendor2_visible: boolean;
  vendor2_name: string;
  vendor2_category: string;
  vendor2_status: string;
  vendor2_email: string;
  vendor2_phone: string;
  vendor2_finalAmount: number;
  vendor2_deposit: number;
  vendor2_remaining: number;
  vendor2_notes: string;
  vendor2_offerExpiry: string;
  vendor3_visible: boolean;
  vendor3_name: string;
  vendor3_category: string;
  vendor3_status: string;
  vendor3_email: string;
  vendor3_phone: string;
  vendor3_finalAmount: number;
  vendor3_deposit: number;
  vendor3_remaining: number;
  vendor3_notes: string;
  vendor3_offerExpiry: string;
  vendor4_visible: boolean;
  vendor4_name: string;
  vendor4_category: string;
  vendor4_status: string;
  vendor4_email: string;
  vendor4_phone: string;
  vendor4_finalAmount: number;
  vendor4_deposit: number;
  vendor4_remaining: number;
  vendor4_notes: string;
  vendor4_offerExpiry: string;
  vendor5_visible: boolean;
  vendor5_name: string;
  vendor5_category: string;
  vendor5_status: string;
  vendor5_email: string;
  vendor5_phone: string;
  vendor5_finalAmount: number;
  vendor5_deposit: number;
  vendor5_remaining: number;
  vendor5_notes: string;
  vendor5_offerExpiry: string;
  vendor6_visible: boolean;
  vendor6_name: string;
  vendor6_category: string;
  vendor6_status: string;
  vendor6_email: string;
  vendor6_phone: string;
  vendor6_finalAmount: number;
  vendor6_deposit: number;
  vendor6_remaining: number;
  vendor6_notes: string;
  vendor6_offerExpiry: string;
  vendor7_visible: boolean;
  vendor7_name: string;
  vendor7_category: string;
  vendor7_status: string;
  vendor7_email: string;
  vendor7_phone: string;
  vendor7_finalAmount: number;
  vendor7_deposit: number;
  vendor7_remaining: number;
  vendor7_notes: string;
  vendor7_offerExpiry: string;
  vendor8_visible: boolean;
  vendor8_name: string;
  vendor8_category: string;
  vendor8_status: string;
  vendor8_email: string;
  vendor8_phone: string;
  vendor8_finalAmount: number;
  vendor8_deposit: number;
  vendor8_remaining: number;
  vendor8_notes: string;
  vendor8_offerExpiry: string;
}

interface SuppliersProps {
  budgetVars: BudgetVars;
  suppliersVars: SuppliersVars;
  setSuppliersVars: (vars: SuppliersVars) => void;
  onNavigate: (screen: string) => void;
  onSupplierCommitted: (supplierName: string, finalAmount: number) => void;
  onSupplierUpdatedCommitment: (supplierName: string) => void;
  currentView: 'list' | 'add' | 'commitment';
}

export function Suppliers({
  budgetVars,
  suppliersVars,
  setSuppliersVars,
  onNavigate,
  onSupplierCommitted,
  onSupplierUpdatedCommitment,
  currentView
}: SuppliersProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterCategory, setFilterCategory] = useState('all');
  const [showAddModal, setShowAddModal] = useState(currentView === 'add');
  const [showCommitmentModal, setShowCommitmentModal] = useState(false);
  const [selectedSupplier, setSelectedSupplier] = useState<any>(null);

  // Get all visible suppliers
  const allSuppliers = [];
  for (let i = 1; i <= 8; i++) {
    const visible = suppliersVars[`vendor${i}_visible` as keyof SuppliersVars] as boolean;
    if (visible) {
      allSuppliers.push({
        id: i,
        name: suppliersVars[`vendor${i}_name` as keyof SuppliersVars] as string,
        category: suppliersVars[`vendor${i}_category` as keyof SuppliersVars] as string,
        status: suppliersVars[`vendor${i}_status` as keyof SuppliersVars] as string,
        email: suppliersVars[`vendor${i}_email` as keyof SuppliersVars] as string,
        phone: suppliersVars[`vendor${i}_phone` as keyof SuppliersVars] as string,
        finalAmount: suppliersVars[`vendor${i}_finalAmount` as keyof SuppliersVars] as number,
        deposit: suppliersVars[`vendor${i}_deposit` as keyof SuppliersVars] as number,
        remaining: suppliersVars[`vendor${i}_remaining` as keyof SuppliersVars] as number,
        notes: suppliersVars[`vendor${i}_notes` as keyof SuppliersVars] as string,
        offerExpiry: suppliersVars[`vendor${i}_offerExpiry` as keyof SuppliersVars] as string
      });
    }
  }

  // Filter suppliers
  const filteredSuppliers = allSuppliers.filter(supplier => {
    const matchesSearch = supplier.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         supplier.category.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === 'all' || supplier.status === filterStatus;
    const matchesCategory = filterCategory === 'all' || supplier.category === filterCategory;
    
    return matchesSearch && matchesStatus && matchesCategory;
  });

  // Group suppliers by category for catalog view
  const suppliersByCategory = filteredSuppliers.reduce((acc, supplier) => {
    const category = supplier.category || 'ללא קטגוריה';
    if (!acc[category]) {
      acc[category] = [];
    }
    acc[category].push(supplier);
    return acc;
  }, {} as Record<string, any[]>);

  // Get unique categories for filter
  const categories = [...new Set(allSuppliers.map(s => s.category).filter(Boolean))];

  const handleAddSupplier = () => {
    setShowAddModal(true);
  };

  const handleMarkCommitted = (supplier: any) => {
    setSelectedSupplier(supplier);
    setShowCommitmentModal(true);
  };

  const handleCommitmentConfirm = (finalAmount: number, deposit: number) => {
    if (selectedSupplier) {
      // Update supplier with commitment data
      const vendorKey = `vendor${selectedSupplier.id}`;
      setSuppliersVars({
        ...suppliersVars,
        [`${vendorKey}_status`]: 'התחייב',
        [`${vendorKey}_finalAmount`]: finalAmount,
        [`${vendorKey}_deposit`]: deposit,
        [`${vendorKey}_remaining`]: finalAmount - deposit
      });
      
      onSupplierUpdatedCommitment(selectedSupplier.name);
      setSelectedSupplier(null);
    }
  };

  const SupplierCard = ({ supplier }: { supplier: any }) => (
    <div className="card p-4 hover:shadow-lg transition-all duration-200">
      <div className="flex items-start justify-between mb-3" dir="rtl">
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-2">
            <h3 className="font-medium" style={{ color: 'var(--text-primary)' }}>
              {supplier.name}
            </h3>
            <SupplierStatusBadge status={supplier.status} />
          </div>
          <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
            {supplier.category}
          </p>
        </div>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
              <MoreVertical className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" dir="rtl">
            {supplier.status !== 'התחייב' && (
              <DropdownMenuItem onClick={() => handleMarkCommitted(supplier)}>
                <CheckCircle className="ml-2 h-4 w-4" />
                סמן כהתחייב
              </DropdownMenuItem>
            )}
            <DropdownMenuItem>
              <FileText className="ml-2 h-4 w-4" />
              פרטים מלאים
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      {/* Contact Info */}
      <div className="space-y-2 mb-3">
        {supplier.email && (
          <div className="flex items-center gap-2 text-sm" style={{ color: 'var(--text-muted)' }}>
            <Mail className="w-4 h-4" />
            <span>{supplier.email}</span>
          </div>
        )}
        {supplier.phone && (
          <div className="flex items-center gap-2 text-sm" style={{ color: 'var(--text-muted)' }}>
            <Phone className="w-4 h-4" />
            <span>{supplier.phone}</span>
          </div>
        )}
      </div>

      {/* Financial Info for Committed Suppliers */}
      {supplier.status === 'התחייב' && supplier.finalAmount > 0 && (
        <div 
          className="p-3 rounded-lg border-r-4 mt-3"
          style={{
            backgroundColor: 'var(--semantic-success-bg)',
            borderRightColor: 'var(--semantic-success-border)'
          }}
        >
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span style={{ color: 'var(--text-secondary)' }}>סכום סופי:</span>
              <div style={{ color: 'var(--text-primary)' }}>
                ₪{supplier.finalAmount.toLocaleString('he-IL')}
              </div>
            </div>
            {supplier.remaining > 0 && (
              <div>
                <span style={{ color: 'var(--text-secondary)' }}>יתרה:</span>
                <div style={{ color: 'var(--semantic-warning-text)' }}>
                  ₪{supplier.remaining.toLocaleString('he-IL')}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Offer Expiry */}
      {supplier.status === 'הצעה' && supplier.offerExpiry && (
        <div className="flex items-center gap-1 mt-3 text-sm" style={{ color: 'var(--semantic-warning-text)' }}>
          <Calendar className="w-4 h-4" />
          <span>תוקף הצעה: {supplier.offerExpiry}</span>
        </div>
      )}
    </div>
  );

  return (
    <>
      {/* Header with Back Button */}
      <div style={{backgroundColor: '#EFF5FB', minHeight: '88px'}} className="relative">
        <div className="flex items-center justify-between px-6 py-4 relative z-10">
          <BackButton onBack={() => onNavigate("dashboard")} />
          <div className="text-center relative">
            <h1 className="section-title text-primary">
              ספקים
            </h1>
            {/* Decorative sparkles */}
            <div
              className="absolute -top-1 -left-4 w-1.5 h-1.5 rotate-45 opacity-45"
              style={{ backgroundColor: "#89B3E0" }}
            ></div>
            <div
              className="absolute top-0 -right-6 w-2 h-2 rotate-45 opacity-40"
              style={{ backgroundColor: "#F7D7A3" }}
            ></div>
            <div
              className="absolute -bottom-1 left-8 w-1 h-1 rotate-45 opacity-50"
              style={{ backgroundColor: "#89B3E0" }}
            ></div>
          </div>
          <Button
            onClick={handleAddSupplier}
            size="sm"
            className="focus:ring-2 focus:ring-ring"
            style={{
              backgroundColor: 'var(--brand-primary)',
              color: 'var(--text-inverse)'
            }}
          >
            <Plus className="w-4 h-4 ml-1" />
            הוסף
          </Button>
        </div>
      </div>

      <div className="p-6">
        {allSuppliers.length === 0 ? (
          /* Empty State */
          <div className="card p-8 text-center max-w-md mx-auto">
            <div
              className="w-16 h-16 mx-auto rounded-full flex items-center justify-center mb-4"
              style={{ backgroundColor: 'var(--surface-sky-50)' }}
            >
              <FileText className="w-8 h-8" style={{ color: 'var(--accent-sky)' }} />
            </div>
            <h2 style={{ color: 'var(--text-primary)' }} className="mb-3">
              עדיין אין ספקים בתכנון
            </h2>
            <p style={{ color: 'var(--text-secondary)' }} className="mb-6">
              התחילו להוסיף ספקים כדי לבנות את תכנון החתונה
            </p>
            <Button
              onClick={handleAddSupplier}
              className="focus:ring-2 focus:ring-ring"
              style={{
                backgroundColor: 'var(--brand-primary)',
                color: 'var(--text-inverse)'
              }}
            >
              הוסיפו ספק ראשון
            </Button>
          </div>
        ) : (
          <>
            {/* Search and Filters */}
            <div className="space-y-4 mb-6">
              {/* Search */}
              <div className="relative">
                <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4" style={{ color: 'var(--text-muted)' }} />
                <Input
                  type="text"
                  placeholder="חפשו ספק או קטגוריה..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pr-10 text-right focus:ring-2 focus:ring-ring"
                  dir="rtl"
                />
              </div>

              {/* Filters */}
              <div className="flex gap-3 overflow-x-auto pb-2">
                <Select value={filterStatus} onValueChange={setFilterStatus}>
                  <SelectTrigger className="w-40 focus:ring-2 focus:ring-ring">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent dir="rtl">
                    <SelectItem value="all">כל הסטטוסים</SelectItem>
                    <SelectItem value="התחייב">התחייב</SelectItem>
                    <SelectItem value="הצעה">הצעה</SelectItem>
                    <SelectItem value="פתוח">פתוח</SelectItem>
                  </SelectContent>
                </Select>

                {categories.length > 0 && (
                  <Select value={filterCategory} onValueChange={setFilterCategory}>
                    <SelectTrigger className="w-40 focus:ring-2 focus:ring-ring">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent dir="rtl">
                      <SelectItem value="all">כל הקטגוריות</SelectItem>
                      {categories.map(category => (
                        <SelectItem key={category} value={category}>
                          {category}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                )}
              </div>
            </div>

            {/* Suppliers Catalog by Category */}
            {Object.keys(suppliersByCategory).length > 0 ? (
              <div className="space-y-6">
                {Object.entries(suppliersByCategory).map(([category, suppliers]) => (
                  <div key={category}>
                    <div className="flex items-center gap-2 mb-4">
                      <h2 style={{ color: 'var(--text-primary)' }}>
                        {category}
                      </h2>
                      <span 
                        className="text-sm px-2 py-1 rounded-md"
                        style={{
                          backgroundColor: 'var(--surface-sky-50)',
                          color: 'var(--text-secondary)'
                        }}
                      >
                        {suppliers.length}
                      </span>
                    </div>
                    <div className="grid gap-4">
                      {suppliers.map(supplier => (
                        <SupplierCard key={supplier.id} supplier={supplier} />
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              /* No Results */
              <div className="card p-6 text-center">
                <Filter className="w-8 h-8 mx-auto mb-3" style={{ color: 'var(--text-muted)' }} />
                <h3 style={{ color: 'var(--text-primary)' }} className="mb-2">
                  לא נמצאו ספקים
                </h3>
                <p style={{ color: 'var(--text-secondary)' }}>
                  נסו לשנות את מונחי החיפוש או הסינון
                </p>
              </div>
            )}
          </>
        )}
      </div>

      {/* Modals */}
      <SupplierModal
        isOpen={showAddModal}
        onClose={() => setShowAddModal(false)}
        suppliersVars={suppliersVars}
        setSuppliersVars={setSuppliersVars}
        onSupplierCommitted={onSupplierCommitted}
      />

      <SupplierCommitmentModal
        isOpen={showCommitmentModal}
        onClose={() => setShowCommitmentModal(false)}
        onConfirm={handleCommitmentConfirm}
        supplierName={selectedSupplier?.name || ''}
      />
    </>
  );
}