import { useState, useEffect } from 'react';

interface CountdownHeroProps {
  daysLeft: number;
  eventName: string;
  eventDate: string;
  onEditDate: () => void;
  onEditEventName: () => void;
}

export function CountdownHero({ 
  daysLeft, 
  eventName, 
  eventDate, 
  onEditDate, 
  onEditEventName 
}: CountdownHeroProps) {
  const [variant, setVariant] = useState<'A' | 'B'>('A');

  // Auto-animate between variants A and B with 10 second loop
  useEffect(() => {
    const interval = setInterval(() => {
      setVariant(prev => prev === 'A' ? 'B' : 'A');
    }, 10000);

    return () => clearInterval(interval);
  }, []);

  // Format date for display
  const formatDate = (dateString: string) => {
    if (!dateString) return "—";
    
    try {
      const date = new Date(dateString);
      return new Intl.DateTimeFormat('he-IL', {
        day: 'numeric',
        month: 'long',
        year: 'numeric'
      }).format(date);
    } catch {
      return dateString || "—";
    }
  };

  // Variant A and B have different blob positions - using brand tokens
  const getBlobStyles = () => {
    if (variant === 'A') {
      return {
        blob1: { 
          top: '-20%', 
          right: '-15%', 
          width: '280px', 
          height: '240px',
          background: 'radial-gradient(ellipse, hsl(var(--brand-primary)) 0%, transparent 70%)'
        },
        blob2: { 
          bottom: '-25%', 
          left: '10%', 
          width: '320px', 
          height: '200px',
          background: 'radial-gradient(ellipse, hsl(var(--brand-secondary-soft)) 0%, transparent 70%)'
        },
        blob3: { 
          top: '40%', 
          left: '-10%', 
          width: '200px', 
          height: '280px',
          background: 'radial-gradient(ellipse, hsl(var(--semantic-info)) 0%, transparent 70%)'
        }
      };
    } else {
      return {
        blob1: { 
          top: '10%', 
          right: '5%', 
          width: '240px', 
          height: '320px',
          background: 'radial-gradient(ellipse, hsl(var(--brand-primary)) 0%, transparent 70%)'
        },
        blob2: { 
          bottom: '5%', 
          left: '-5%', 
          width: '300px', 
          height: '220px',
          background: 'radial-gradient(ellipse, hsl(var(--brand-secondary-soft)) 0%, transparent 70%)'
        },
        blob3: { 
          top: '-15%', 
          left: '20%', 
          width: '180px', 
          height: '300px',
          background: 'radial-gradient(ellipse, hsl(var(--semantic-info)) 0%, transparent 70%)'
        }
      };
    }
  };

  const blobStyles = getBlobStyles();
  const displayDays = daysLeft <= 0 ? 'היום!' : `נשארו ${daysLeft} ימים`;

  return (
    <div className="relative w-full h-52 rounded-xl overflow-hidden border border-border">
      {/* Animated gradient background with 3 blurred blobs */}
      <div className="absolute inset-0">
        {/* Blob 1 */}
        <div
          className="absolute rounded-full blur-2xl transition-all duration-[10000ms] ease-linear opacity-30"
          style={blobStyles.blob1}
        />
        {/* Blob 2 */}
        <div
          className="absolute rounded-full blur-2xl transition-all duration-[10000ms] ease-linear opacity-25"
          style={blobStyles.blob2}
        />
        {/* Blob 3 */}
        <div
          className="absolute rounded-full blur-2xl transition-all duration-[10000ms] ease-linear opacity-20"
          style={blobStyles.blob3}
        />
        
        {/* Semi-transparent scrim for text contrast (AA compliance) */}
        <div 
          className="absolute inset-0" 
          style={{ backgroundColor: 'rgba(0, 0, 0, 0.22)' }}
        />
      </div>

      {/* Content - RTL aligned */}
      <div className="relative z-10 h-full flex items-center justify-end p-5 text-right">
        <div className="space-y-2">
          {/* Emoji in decorative circle */}
          <div className="flex justify-end mb-3">
            <div className="w-12 h-12 rounded-full bg-white/15 backdrop-blur-sm flex items-center justify-center">
              <span className="text-2xl" role="img" aria-label="טבעת נישואין">💍</span>
            </div>
          </div>

          {/* Main countdown */}
          <h1 style={{ color: 'var(--text-on-hero)' }} className="text-2xl font-semibold leading-tight">
            {displayDays}
          </h1>

          {/* Event name and date */}
          <div style={{ color: 'var(--text-on-hero-secondary)' }} className="text-sm leading-tight">
            <div>{eventName || "—"} · {formatDate(eventDate)}</div>
          </div>

          {/* Action buttons */}
          <div className="flex gap-3 justify-end mt-3">
            <button
              onClick={onEditDate}
              style={{ color: 'var(--text-on-hero-subtle)' }}
              className="text-xs hover:text-white transition-colors focus:ring-2 focus:ring-white/50 focus:outline-none rounded px-2 py-1"
            >
              ערכו תאריך
            </button>
            <button
              onClick={onEditEventName}
              style={{ color: 'var(--text-on-hero-subtle)' }}
              className="text-xs hover:text-white transition-colors focus:ring-2 focus:ring-white/50 focus:outline-none rounded px-2 py-1"
            >
              ערכו שם האירוע
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}