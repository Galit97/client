import React from 'react';
import { BackButton } from './ui/back-button';
import { Button } from './ui/button';
import { CheckCircle, Clock, AlertCircle, Calendar, Phone, FileText, CreditCard } from 'lucide-react';

interface DashVars {
  tasksTodayCount: number;
  guestsCount: number;
}

interface SuppliersVars {
  committedCount: number;
  vendor1_visible: boolean;
  vendor1_name: string;
  vendor1_category: string;
  vendor1_status: string;
  vendor1_email: string;
  vendor1_phone: string;
  vendor1_deposit: number;
  vendor1_remaining: number;
  vendor1_nextDue: string;
  vendor2_visible: boolean;
  vendor2_name: string;
  vendor2_category: string;
  vendor2_status: string;
  vendor2_email: string;
  vendor2_phone: string;
  vendor2_deposit: number;
  vendor2_remaining: number;
  vendor2_nextDue: string;
  vendor3_visible: boolean;
  vendor3_name: string;
  vendor3_category: string;
  vendor3_status: string;
  vendor3_email: string;
  vendor3_phone: string;
  vendor3_deposit: number;
  vendor3_remaining: number;
  vendor3_nextDue: string;
  vendor4_visible: boolean;
  vendor4_name: string;
  vendor4_category: string;
  vendor4_status: string;
  vendor4_email: string;
  vendor4_phone: string;
  vendor4_deposit: number;
  vendor4_remaining: number;
  vendor4_nextDue: string;
  vendor5_visible: boolean;
  vendor5_name: string;
  vendor5_category: string;
  vendor5_status: string;
  vendor5_email: string;
  vendor5_phone: string;
  vendor5_deposit: number;
  vendor5_remaining: number;
  vendor5_nextDue: string;
  vendor6_visible: boolean;
  vendor6_name: string;
  vendor6_category: string;
  vendor6_status: string;
  vendor6_email: string;
  vendor6_phone: string;
  vendor6_deposit: number;
  vendor6_remaining: number;
  vendor6_nextDue: string;
  vendor7_visible: boolean;
  vendor7_name: string;
  vendor7_category: string;
  vendor7_status: string;
  vendor7_email: string;
  vendor7_phone: string;
  vendor7_deposit: number;
  vendor7_remaining: number;
  vendor7_nextDue: string;
  vendor8_visible: boolean;
  vendor8_name: string;
  vendor8_category: string;
  vendor8_status: string;
  vendor8_email: string;
  vendor8_phone: string;
  vendor8_deposit: number;
  vendor8_remaining: number;
  vendor8_nextDue: string;
}

interface TasksProps {
  dashVars: DashVars;
  setDashVars: (vars: DashVars) => void;
  suppliersVars: SuppliersVars;
  onNavigate: (screen: string) => void;
}

export function Tasks({ dashVars, setDashVars, suppliersVars, onNavigate }: TasksProps) {
  // Get all visible suppliers
  const allSuppliers = [];
  for (let i = 1; i <= 8; i++) {
    const visible = suppliersVars[`vendor${i}_visible` as keyof SuppliersVars] as boolean;
    if (visible) {
      allSuppliers.push({
        id: i,
        name: suppliersVars[`vendor${i}_name` as keyof SuppliersVars] as string,
        category: suppliersVars[`vendor${i}_category` as keyof SuppliersVars] as string,
        status: suppliersVars[`vendor${i}_status` as keyof SuppliersVars] as string,
        email: suppliersVars[`vendor${i}_email` as keyof SuppliersVars] as string,
        phone: suppliersVars[`vendor${i}_phone` as keyof SuppliersVars] as string,
        deposit: suppliersVars[`vendor${i}_deposit` as keyof SuppliersVars] as number,
        remaining: suppliersVars[`vendor${i}_remaining` as keyof SuppliersVars] as number,
        nextDue: suppliersVars[`vendor${i}_nextDue` as keyof SuppliersVars] as string
      });
    }
  }

  // Generate tasks based on suppliers
  const generateSupplierTasks = () => {
    const tasks = [];

    // Tasks for committed suppliers (follow up tasks)
    const committedSuppliers = allSuppliers.filter(s => s.status === 'התחייב');
    committedSuppliers.forEach(supplier => {
      // Payment reminders
      if (supplier.remaining > 0 && supplier.nextDue) {
        tasks.push({
          id: `payment-${supplier.id}`,
          type: 'payment',
          title: `תשלום ל${supplier.name}`,
          description: `יתרה לתשלום: ₪${supplier.remaining.toLocaleString('he-IL')}`,
          dueDate: supplier.nextDue,
          priority: 'high',
          supplier: supplier.name,
          category: supplier.category,
          icon: CreditCard
        });
      }

      // Contract finalization
      tasks.push({
        id: `contract-${supplier.id}`,
        type: 'contract',
        title: `חוזה עם ${supplier.name}`,
        description: 'סיום ההסכם וחתימה על החוזה',
        priority: 'medium',
        supplier: supplier.name,
        category: supplier.category,
        icon: FileText
      });

      // Final meeting
      tasks.push({
        id: `meeting-${supplier.id}`,
        type: 'meeting',
        title: `פגישה אחרונה עם ${supplier.name}`,
        description: 'תיאום פרטים אחרונים לקראת האירוע',
        priority: 'medium',
        supplier: supplier.name,
        category: supplier.category,
        icon: Calendar
      });
    });

    // Tasks for open suppliers (decision tasks)
    const openSuppliers = allSuppliers.filter(s => s.status === 'פתוח' || s.status === 'הצעה');
    openSuppliers.forEach(supplier => {
      if (supplier.status === 'הצעה') {
        tasks.push({
          id: `decision-${supplier.id}`,
          type: 'decision',
          title: `החלטה על ${supplier.name}`,
          description: `${supplier.category} - הצעה מחכה לאישור`,
          priority: 'high',
          supplier: supplier.name,
          category: supplier.category,
          icon: AlertCircle
        });
      }

      // Follow up contact
      if (supplier.phone) {
        tasks.push({
          id: `followup-${supplier.id}`,
          type: 'contact',
          title: `מעקב עם ${supplier.name}`,
          description: 'בדיקת סטטוס והתקדמות',
          priority: 'medium',
          supplier: supplier.name,
          category: supplier.category,
          icon: Phone
        });
      }
    });

    return tasks;
  };

  const supplierTasks = generateSupplierTasks();

  // Group tasks by priority
  const highPriorityTasks = supplierTasks.filter(t => t.priority === 'high');
  const mediumPriorityTasks = supplierTasks.filter(t => t.priority === 'medium');

  const handleTaskComplete = (taskId: string) => {
    // In a real app, this would update task completion status
    console.log('Task completed:', taskId);
  };

  const getTaskIcon = (task: any) => {
    const IconComponent = task.icon;
    const colorClass = task.priority === 'high' ? 'text-red-600' : 'text-amber-600';
    return <IconComponent className={`w-5 h-5 ${colorClass}`} />;
  };

  const TaskCard = ({ task }: { task: any }) => (
    <div className="card p-4 hover:shadow-lg transition-all duration-200">
      <div className="flex items-start gap-3" dir="rtl">
        <div className="flex-shrink-0 mt-1">
          {getTaskIcon(task)}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between mb-2">
            <h3 className="font-medium text-right" style={{ color: 'var(--text-primary)' }}>
              {task.title}
            </h3>
            {task.priority === 'high' && (
              <span 
                className="px-2 py-1 text-xs rounded-md"
                style={{
                  backgroundColor: 'var(--semantic-danger-bg)',
                  color: 'var(--semantic-danger-text)'
                }}
              >
                דחוף
              </span>
            )}
          </div>
          <p className="text-sm text-right mb-2" style={{ color: 'var(--text-secondary)' }}>
            {task.description}
          </p>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span 
                className="text-xs px-2 py-1 rounded-md"
                style={{
                  backgroundColor: 'var(--surface-sky-50)',
                  color: 'var(--accent-sky)'
                }}
              >
                {task.category}
              </span>
              {task.dueDate && (
                <span className="text-xs" style={{ color: 'var(--text-muted)' }}>
                  תאריך יעד: {task.dueDate}
                </span>
              )}
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => handleTaskComplete(task.id)}
              className="flex items-center gap-1 focus:ring-2 focus:ring-ring"
            >
              <CheckCircle className="w-4 h-4" />
              <span className="text-xs">בוצע</span>
            </Button>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <>
      {/* Header with Back Button */}
      <div style={{backgroundColor: '#FBF7EF', minHeight: '88px'}} className="relative">
        <div className="flex items-center justify-between px-6 py-4 relative z-10">
          <BackButton onBack={() => onNavigate("dashboard")} />
          <div className="text-center relative">
            <h1 className="section-title text-primary">
              משימות
            </h1>
            {/* Decorative sparkles */}
            <div
              className="absolute -top-1 -left-4 w-1.5 h-1.5 rotate-45 opacity-45"
              style={{ backgroundColor: "#C7A774" }}
            ></div>
            <div
              className="absolute top-0 -right-6 w-2 h-2 rotate-45 opacity-40"
              style={{ backgroundColor: "#89B3E0" }}
            ></div>
            <div
              className="absolute -bottom-1 left-8 w-1 h-1 rotate-45 opacity-50"
              style={{ backgroundColor: "#C7A774" }}
            ></div>
          </div>
          <div className="w-20"></div>
        </div>
      </div>

      <div className="p-6 space-y-6">
        {/* Summary Stats */}
        <div className="grid grid-cols-2 gap-4">
          <div className="card p-4 text-center">
            <div className="text-2xl font-semibold mb-1" style={{ color: 'var(--text-primary)' }}>
              {highPriorityTasks.length}
            </div>
            <div className="text-sm" style={{ color: 'var(--semantic-danger-text)' }}>
              משימות דחופות
            </div>
          </div>
          <div className="card p-4 text-center">
            <div className="text-2xl font-semibold mb-1" style={{ color: 'var(--text-primary)' }}>
              {supplierTasks.length}
            </div>
            <div className="text-sm" style={{ color: 'var(--text-secondary)' }}>
              סה"כ משימות
            </div>
          </div>
        </div>

        {allSuppliers.length === 0 ? (
          /* Empty State */
          <div className="card p-8 text-center">
            <div
              className="w-16 h-16 mx-auto rounded-full flex items-center justify-center mb-4"
              style={{ backgroundColor: 'var(--surface-gold-50)' }}
            >
              <Clock className="w-8 h-8" style={{ color: 'var(--accent-gold)' }} />
            </div>
            <h2 style={{ color: 'var(--text-primary)' }} className="mb-3">
              עדיין אין משימות
            </h2>
            <p style={{ color: 'var(--text-secondary)' }} className="mb-6">
              משימות יווצרו אוטומטית כשתוסיפו ספקים לתכנון
            </p>
            <Button
              variant="outline"
              onClick={() => onNavigate("suppliers")}
              className="focus:ring-2 focus:ring-ring"
            >
              פתחו עמוד ספקים
            </Button>
          </div>
        ) : (
          <>
            {/* High Priority Tasks */}
            {highPriorityTasks.length > 0 && (
              <div>
                <div className="flex items-center gap-2 mb-4">
                  <AlertCircle className="w-5 h-5 text-red-600" />
                  <h2 style={{ color: 'var(--text-primary)' }}>
                    משימות דחופות
                  </h2>
                </div>
                <div className="space-y-3">
                  {highPriorityTasks.map(task => (
                    <TaskCard key={task.id} task={task} />
                  ))}
                </div>
              </div>
            )}

            {/* Medium Priority Tasks */}
            {mediumPriorityTasks.length > 0 && (
              <div>
                <div className="flex items-center gap-2 mb-4">
                  <Clock className="w-5 h-5 text-amber-600" />
                  <h2 style={{ color: 'var(--text-primary)' }}>
                    משימות נוספות
                  </h2>
                </div>
                <div className="space-y-3">
                  {mediumPriorityTasks.map(task => (
                    <TaskCard key={task.id} task={task} />
                  ))}
                </div>
              </div>
            )}

            {/* Quick Actions */}
            <div className="card p-4">
              <h3 className="mb-4" style={{ color: 'var(--text-primary)' }}>
                פעולות מהירות
              </h3>
              <div className="space-y-2">
                <Button
                  variant="outline"
                  onClick={() => onNavigate("suppliers")}
                  className="w-full justify-start focus:ring-2 focus:ring-ring"
                  dir="rtl"
                >
                  <FileText className="w-4 h-4 ml-2" />
                  נהלו ספקים
                </Button>
                <Button
                  variant="outline"
                  onClick={() => onNavigate("budget-overview")}
                  className="w-full justify-start focus:ring-2 focus:ring-ring"
                  dir="rtl"
                >
                  <CreditCard className="w-4 h-4 ml-2" />
                  בדקו תקציב
                </Button>
              </div>
            </div>
          </>
        )}
      </div>
    </>
  );
}