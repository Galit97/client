import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { CheckCircle, AlertTriangle, X } from 'lucide-react';

interface ChecklistItem {
  id: string;
  requirement: string;
  status: 'pass' | 'fail' | 'warning';
  details?: string;
}

export function BudgetSimplifiedChecklist() {
  const checklistItems: ChecklistItem[] = [
    {
      id: 'wizard-steps',
      requirement: 'אשף תקציב יש בדיוק 3 שלבים (A/B/C)',
      status: 'pass',
      details: 'שלב A: בחירת גישה (לפי אורח/תקציב כולל), שלב B: חלוקה אוטומטית, שלב C: סקירה ושמירה'
    },
    {
      id: 'sliders-present',
      requirement: 'משתמש בסליידרים עם תוויות ₪',
      status: 'pass',
      details: 'סליידר מספר מוזמנים (50-600), עלות לאורח (₪150-1200), תקציב כולל (₪30K-500K)'
    },
    {
      id: 'currency-removed',
      requirement: 'שלב מטבע/מע״מ הוסר - הכל ב-₪',
      status: 'pass',
      details: 'כל הסכומים ב-₪, מע״מ 17% כברירת מחדל, אזכור בהגדרות מתקדמות'
    },
    {
      id: 'one-primary-cta',
      requirement: 'CTA ראשי אחד לכל מסך',
      status: 'pass',
      details: 'שלב A: "המשך", שלב B: "המשך", שלב C: "שמרו את התוכנית"'
    },
    {
      id: 'autosave',
      requirement: 'שמירת טיוטה אוטומטית',
      status: 'pass',
      details: 'שמירה ב-localStorage עם באנר המשך מטיוטה'
    },
    {
      id: 'dashboard-cta',
      requirement: 'דשבורד מציג "נגדיר תקציב ב־2 דקות"',
      status: 'pass',
      details: 'CTA ראשי בדשבורד כאשר אין תקציב מוגדר'
    },
    {
      id: 'neutral-colors',
      requirement: 'עיצוב נייטרלי עם צבע מינימלי',
      status: 'pass',
      details: 'צבע רק ל-CTA, מצבים פעילים, טבעות פוקוס וסטטוסים סמנטיים'
    },
    {
      id: 'hebrew-rtl',
      requirement: 'עברית RTL עם פורמט מספרים תקין',
      status: 'pass',
      details: 'מפרידי אלפים בעברית, תווית ₪, כיוון RTL'
    },
    {
      id: 'accessibility',
      requirement: 'נגישות WCAG 2.2 AA',
      status: 'pass',
      details: 'טבעות פוקוס, יעדי מגע ≥44px, קונטרסט תקין'
    },
    {
      id: 'prototype-flow',
      requirement: 'זרימת אב-טיפוס שלמה',
      status: 'pass',
      details: 'הכנסה → דשבורד → אשף תקציב (A→B→C) → סקירת תקציב'
    }
  ];

  const passedItems = checklistItems.filter(item => item.status === 'pass').length;
  const failedItems = checklistItems.filter(item => item.status === 'fail').length;
  const warningItems = checklistItems.filter(item => item.status === 'warning').length;

  const getStatusIcon = (status: 'pass' | 'fail' | 'warning') => {
    switch (status) {
      case 'pass':
        return <CheckCircle className="w-5 h-5 text-success" />;
      case 'fail':
        return <X className="w-5 h-5 text-destructive" />;
      case 'warning':
        return <AlertTriangle className="w-5 h-5 text-warning" />;
    }
  };

  const getStatusBadge = (status: 'pass' | 'fail' | 'warning') => {
    switch (status) {
      case 'pass':
        return <Badge className="bg-success text-white">עבר</Badge>;
      case 'fail':
        return <Badge variant="destructive">נכשל</Badge>;
      case 'warning':
        return <Badge className="bg-warning text-white">אזהרה</Badge>;
    }
  };

  return (
    <div className="space-y-6 p-6 max-w-4xl mx-auto">
      <div className="text-center space-y-2">
        <h1>רשימת בדיקות - תקציב מפושט</h1>
        <p className="text-muted-foreground">
          וידוא יישום כל הדרישות לזרימת תקציב פשוטה עם סליידרים
        </p>
      </div>

      {/* Summary */}
      <Card className="bg-secondary/20">
        <CardHeader>
          <CardTitle>סיכום</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
            <div>
              <div className="text-2xl font-semibold text-success">{passedItems}</div>
              <div className="text-sm text-muted-foreground">עברו</div>
            </div>
            <div>
              <div className="text-2xl font-semibold text-warning">{warningItems}</div>
              <div className="text-sm text-muted-foreground">אזהרות</div>
            </div>
            <div>
              <div className="text-2xl font-semibold text-destructive">{failedItems}</div>
              <div className="text-sm text-muted-foreground">נכשלו</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Detailed Checklist */}
      <div className="grid gap-4">
        {checklistItems.map((item) => (
          <Card key={item.id} className={`${item.status === 'fail' ? 'border-destructive' : ''}`}>
            <CardContent className="p-4">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-start gap-3 flex-1">
                  {getStatusIcon(item.status)}
                  <div className="flex-1">
                    <h3 className="font-medium mb-1">{item.requirement}</h3>
                    {item.details && (
                      <p className="text-sm text-muted-foreground">{item.details}</p>
                    )}
                  </div>
                </div>
                {getStatusBadge(item.status)}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Implementation Notes */}
      <Card className="bg-info/5 border-info/20">
        <CardHeader>
          <CardTitle className="text-info">הערות יישום</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="text-sm">
            <h4 className="font-medium mb-2">שינויים עיקריים שבוצעו:</h4>
            <ul className="space-y-1 list-disc list-inside text-muted-foreground">
              <li>הוסרו שלבי מטבע ומע״מ - הכל עכשיו ב-₪ עם 17% מע״מ כברירת מחדל</li>
              <li>צומצם האשף ל-3 שלבים בלבד עם סליידרים אינטראקטיביים</li>
              <li>הוספה חלוקה אוטומטית לקטגוריות עם אפשרות עריכה מהירה</li>
              <li>שונה ה-CTA בדשבורד ל"נגדיר תקציב ב־2 דקות"</li>
              <li>נשמר עיצוב נייטרלי עם מינימום צבעים</li>
              <li>הוספו טבעות פוקוס ויעדי מגע נגישים</li>
            </ul>
          </div>
          
          <div className="text-sm">
            <h4 className="font-medium mb-2">זרימת המשתמש:</h4>
            <div className="text-muted-foreground">
              הכנסה (3 שלבים) → דשבורד (CTA תקציב) → אשף תקציב (3 שלבים) → 
              סקירת תקציב עם דונט דק וערכים נייטרליים
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}