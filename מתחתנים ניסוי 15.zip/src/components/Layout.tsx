import React from 'react';
import { BottomNavigation, getActiveTabFromScreen } from './ui/bottom-navigation';

interface LayoutProps {
  currentScreen: string;
  onNavigate: (screen: string) => void;
  children: React.ReactNode;
}

export function Layout({ currentScreen, onNavigate, children }: LayoutProps) {
  const activeTab = getActiveTabFromScreen(currentScreen);

  return (
    <div className="min-h-screen flex flex-col" style={{ backgroundColor: 'var(--base-bg)' }}>
      {/* Main content with bottom padding for fixed nav */}
      <main 
        className="flex-1"
        style={{
          paddingBottom: 'calc(80px + var(--safe-area-inset-bottom))' // Height of bottom nav + safe area
        }}
      >
        {children}
      </main>
      
      {/* Fixed bottom navigation */}
      <BottomNavigation 
        activeTab={activeTab}
        onNavigate={onNavigate}
      />
    </div>
  );
}