import React from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { ArrowRight, Calendar, Users, CheckCircle, FileText, CreditCard, TrendingUp, Share2 } from 'lucide-react';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from './ui/tooltip';

// Mock participants data - in real app this would come from props/state
const MOCK_PARTICIPANTS = [
  { id: 1, name: 'שרה כהן', role: 'owner', initials: 'שכ' },
  { id: 2, name: 'דני לוי', role: 'partner', initials: 'דל' },
  { id: 3, name: 'מיכל אברמוביץ', role: 'planner', initials: 'מא' },
  { id: 4, name: 'רותי ישראלי', role: 'family', initials: 'רי' },
  { id: 5, name: 'אלי דוד', role: 'friend', initials: 'אד' }
];

interface ParticipantsClusterProps {
  participants?: typeof MOCK_PARTICIPANTS;
  onParticipantClick?: () => void;
}

const ParticipantsCluster: React.FC<ParticipantsClusterProps> = ({ 
  participants = MOCK_PARTICIPANTS, 
  onParticipantClick 
}) => {
  const visibleParticipants = participants.slice(0, 3);
  const overflowCount = Math.max(0, participants.length - 3);

  const getAvatarColor = (role: string) => {
    switch (role) {
      case 'owner': return 'var(--brand-primary)';
      case 'partner': return 'var(--accent-sky)';
      case 'planner': return 'var(--accent-sage)';
      default: return 'var(--accent-gold)';
    }
  };

  const getRoleLabel = (role: string) => {
    switch (role) {
      case 'owner': return 'בעל החתונה';
      case 'partner': return 'בן/בת זוג';
      case 'planner': return 'מתכנן אירועים';
      default: return 'משתתף';
    }
  };

  return (
    <div className="flex items-center" dir="rtl">
      {/* Visible Avatars - RTL order with negative margin overlap */}
      <div className="flex items-center" style={{ direction: 'rtl' }}>
        {visibleParticipants.map((participant, index) => (
          <TooltipProvider key={participant.id}>
            <Tooltip>
              <TooltipTrigger asChild>
                <button
                  onClick={onParticipantClick}
                  className="relative rounded-full transition-all duration-200 hover:scale-110 focus:scale-110 focus:outline-none focus:ring-2 focus:ring-offset-2"
                  style={{
                    marginLeft: index > 0 ? '-6px' : '0',
                    zIndex: visibleParticipants.length - index,
                    minWidth: '44px',
                    minHeight: '44px',
                    padding: '10px',
                    focusRingColor: 'var(--focus-ring)'
                  }}
                  aria-label={`${participant.name} - ${getRoleLabel(participant.role)}`}
                >
                  <div
                    className="w-6 h-6 rounded-full flex items-center justify-center text-xs font-medium shadow-sm"
                    style={{
                      backgroundColor: getAvatarColor(participant.role),
                      color: 'var(--text-inverse)',
                      border: '2px solid white',
                      boxShadow: '0 1px 3px rgba(0, 0, 0, 0.1)'
                    }}
                  >
                    {participant.initials}
                  </div>
                </button>
              </TooltipTrigger>
              <TooltipContent side="bottom" className="text-sm">
                <p className="font-medium">{participant.name}</p>
                <p className="text-xs opacity-75">{getRoleLabel(participant.role)}</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        ))}
      </div>

      {/* Overflow Chip */}
      {overflowCount > 0 && (
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <button
                onClick={onParticipantClick}
                className="relative rounded-full transition-all duration-200 hover:scale-110 focus:scale-110 focus:outline-none focus:ring-2 focus:ring-offset-2"
                style={{
                  marginLeft: '-6px',
                  zIndex: 0,
                  minWidth: '44px',
                  minHeight: '44px',
                  padding: '10px',
                  focusRingColor: 'var(--focus-ring)'
                }}
                aria-label={`עוד ${overflowCount} משתתפים`}
              >
                <div
                  className="w-6 h-6 rounded-full flex items-center justify-center text-xs font-medium shadow-sm"
                  style={{
                    backgroundColor: 'var(--base-white)',
                    color: 'var(--text-secondary)',
                    border: '2px solid white',
                    boxShadow: '0 1px 3px rgba(0, 0, 0, 0.1)'
                  }}
                >
                  +{overflowCount}
                </div>
              </button>
            </TooltipTrigger>
            <TooltipContent side="bottom" className="text-sm">
              <p>{overflowCount} משתתפים נוספים</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      )}
    </div>
  );
};

interface AppState {
  isAuthenticated: boolean;
  isViewOnly: boolean;
  hasEventDate: boolean;
  coupleName: string;
}

interface Event {
  eventName: string;
  eventNameEdited: boolean;
  eventDate: string;
}

interface Countdown {
  daysLeft: number;
}

interface BudgetVars {
  guestsMin: number;
  guestsMax: number;
  guestsExact: number;
  giftAvg: number;
  targetMode: string;
  ownContribution: number;
  savePercent: number;
  giftsMin: number;
  giftsMax: number;
  targetExact: number;
  targetMin: number;
  targetMax: number;
  forecastTotal: number;
}

interface DashVars {
  tasksTodayCount: number;
  guestsCount: number;
  filesCount?: number;
  upcomingPaymentsCount?: number;
}

interface SuppliersVars {
  committedCount: number;
}

interface DashboardProps {
  appState: AppState;
  event: Event;
  countdown: Countdown;
  budgetVars: BudgetVars;
  dashVars: DashVars;
  suppliersVars: SuppliersVars;
  onNavigate: (screen: string) => void;
  setDashVars: (vars: DashVars) => void;
}

export function Dashboard({ 
  appState, 
  event, 
  countdown, 
  budgetVars, 
  dashVars, 
  suppliersVars, 
  onNavigate, 
  setDashVars 
}: DashboardProps) {
  
  const formatCurrency = (amount: number): string => {
    if (amount === 0) return "—";
    return new Intl.NumberFormat('he-IL', {
      style: 'currency',
      currency: 'ILS',
      minimumFractionDigits: 0
    }).format(amount);
  };

  const hasBudgetData = budgetVars.targetExact > 0 || budgetVars.targetMin > 0;
  const hasCommittedSuppliers = suppliersVars.committedCount > 0;

  return (
    <div className="min-h-screen" style={{backgroundColor: '#FAFAFA'}} dir="rtl">
      {/* Header - Event Date or Countdown */}
      {appState.hasEventDate && event.eventDate ? (
        <div className="countdown-hero relative overflow-hidden">
          {/* Header Controls - Participants and Share */}
          <div className="absolute top-4 left-6 z-20 flex items-center gap-3">
            <ParticipantsCluster 
              onParticipantClick={() => onNavigate('members-permissions')}
            />
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => onNavigate('members-permissions')}
                    className="text-white hover:bg-white/20 focus:ring-2 focus:ring-white/50"
                    style={{ minWidth: '44px', minHeight: '44px' }}
                    aria-label="שיתוף ותיכון של משתתפים"
                  >
                    <Share2 className="w-5 h-5" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent side="bottom" className="text-sm">
                  <p>שיתוף</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>

          <div className="relative z-10 text-center py-8 px-6 responsive-md:py-12 responsive-lg:py-16">
            <div className="max-w-4xl mx-auto">
              <h1 className="hero-text mb-2 responsive-xs:text-2xl responsive-md:text-3xl responsive-lg:text-4xl">
                {event.eventName || 'החתונה שלנו'}
              </h1>
              <div className="hero-text-secondary mb-6 responsive-xs:text-base responsive-md:text-lg">
                {new Date(event.eventDate).toLocaleDateString('he-IL', {
                  weekday: 'long',
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric'
                })}
              </div>
              
              <div className="hero-text text-center">
                <div className="text-6xl responsive-xs:text-5xl responsive-md:text-7xl responsive-lg:text-8xl font-medium mb-2">
                  {countdown.daysLeft}
                </div>
                <div className="hero-text-secondary text-xl responsive-xs:text-lg responsive-md:text-2xl">
                  {countdown.daysLeft === 1 ? 'יום נשאר' : 'ימים נשארו'}
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="section-header-dashboard">
          {/* Header Controls - Participants and Share */}
          <div className="absolute top-4 left-6 z-20 flex items-center gap-3">
            <ParticipantsCluster 
              onParticipantClick={() => onNavigate('members-permissions')}
            />
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => onNavigate('members-permissions')}
                    className="text-white hover:bg-white/20 focus:ring-2 focus:ring-white/50"
                    style={{ minWidth: '44px', minHeight: '44px' }}
                    aria-label="שיתוף ותיכון של משתתפים"
                  >
                    <Share2 className="w-5 h-5" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent side="bottom" className="text-sm">
                  <p>שיתוף</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>

          <div className="relative z-10 text-center py-8 px-6 responsive-md:py-12">
            <div className="max-w-2xl mx-auto">
              <h1 className="hero-text mb-4 responsive-xs:text-2xl responsive-md:text-3xl">
                {appState.coupleName ? `שלום ${appState.coupleName}!` : 'ברוכים הבאים!'}
              </h1>
              <p className="hero-text-secondary mb-6 responsive-xs:text-base responsive-md:text-lg">
                בואו נתחיל לתכנן את החתונה שלכם
              </p>
              <Button 
                onClick={() => onNavigate('event-date')}
                className="btn-primary responsive-xs:w-full responsive-md:w-auto responsive-xs:text-base responsive-md:text-lg px-8 py-4"
              >
                בחרו תאריך לחתונה
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Main Content */}
      <div className="px-4 py-6 responsive-md:px-6 responsive-lg:px-8 responsive-2xl:px-12">
        <div className="max-w-7xl mx-auto space-y-8">
          
          {/* Primary Actions - Responsive Grid */}
          <div className="grid grid-cols-1 responsive-md:grid-cols-2 responsive-xl:grid-cols-3 gap-6">
            
            {/* Budget Card - Always show, but content varies */}
            <Card className="card">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3">
                  <div 
                    className="w-12 h-12 rounded-full flex items-center justify-center"
                    style={{backgroundColor: 'var(--surface-sage-50)'}}
                  >
                    <TrendingUp className="w-6 h-6" style={{color: 'var(--accent-sage)'}} />
                  </div>
                  <CardTitle className="responsive-xs:text-lg responsive-md:text-xl">תקציב</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {hasBudgetData ? (
                  <div className="space-y-3">
                    <div>
                      <div className="text-sm mb-1" style={{color: 'var(--text-secondary)'}}>יעד התקציב</div>
                      <div className="text-2xl responsive-xs:text-xl font-semibold" style={{color: 'var(--text-primary)'}}>
                        {formatCurrency(budgetVars.targetExact || budgetVars.targetMin)}
                      </div>
                      {budgetVars.targetMin > 0 && budgetVars.targetMax > budgetVars.targetMin && (
                        <div className="text-xs mt-1" style={{color: 'var(--text-muted)'}}>
                          טווח: {formatCurrency(budgetVars.targetMin)}–{formatCurrency(budgetVars.targetMax)}
                        </div>
                      )}
                    </div>
                    
                    {hasCommittedSuppliers && (
                      <div>
                        <div className="text-sm mb-1" style={{color: 'var(--text-secondary)'}}>צפוי כרגע</div>
                        <div className="text-xl font-medium" style={{color: 'var(--text-primary)'}}>
                          {formatCurrency(budgetVars.forecastTotal)}
                        </div>
                      </div>
                    )}
                    
                    <Button 
                      variant="outline" 
                      onClick={() => onNavigate('budget-overview')}
                      className="w-full responsive-xs:min-h-[48px] responsive-md:min-h-[44px]"
                    >
                      <span className="ml-2">סקירת תקציב</span>
                      <ArrowRight size={16} />
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-4 text-center py-4">
                    <div style={{color: 'var(--text-secondary)'}} className="responsive-xs:text-sm responsive-md:text-base">
                      עדיין לא הוגדר תקציב
                    </div>
                    <Button 
                      onClick={() => onNavigate('new-budget-wizard')}
                      className="btn-primary w-full responsive-xs:min-h-[48px] responsive-md:min-h-[44px]"
                    >
                      הגדירו תקציב
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Tasks Card */}
            <Card className="card">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3">
                  <div 
                    className="w-12 h-12 rounded-full flex items-center justify-center"
                    style={{backgroundColor: 'var(--surface-gold-50)'}}
                  >
                    <CheckCircle className="w-6 h-6" style={{color: 'var(--accent-gold)'}} />
                  </div>
                  <CardTitle className="responsive-xs:text-lg responsive-md:text-xl">מה היום?</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="text-sm mb-1" style={{color: 'var(--text-secondary)'}}>משימות להיום</div>
                  <div className="text-2xl responsive-xs:text-xl font-semibold" style={{color: 'var(--text-primary)'}}>
                    {dashVars.tasksTodayCount || "—"}
                  </div>
                </div>
                
                <Button 
                  variant="outline" 
                  onClick={() => onNavigate('tasks')}
                  className="w-full responsive-xs:min-h-[48px] responsive-md:min-h-[44px]"
                >
                  <span className="ml-2">כל המשימות</span>
                  <ArrowRight size={16} />
                </Button>
              </CardContent>
            </Card>

            {/* Guests Card */}
            <Card className="card responsive-md:col-span-2 responsive-xl:col-span-1">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3">
                  <div 
                    className="w-12 h-12 rounded-full flex items-center justify-center"
                    style={{backgroundColor: 'var(--surface-rose-50)'}}
                  >
                    <Users className="w-6 h-6" style={{color: 'var(--accent-rose)'}} />
                  </div>
                  <CardTitle className="responsive-xs:text-lg responsive-md:text-xl">מוזמנים</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="text-sm mb-1" style={{color: 'var(--text-secondary)'}}>סה״כ מוזמנים</div>
                  <div className="text-2xl responsive-xs:text-xl font-semibold" style={{color: 'var(--text-primary)'}}>
                    {dashVars.guestsCount || "—"}
                  </div>
                </div>
                
                <Button 
                  variant="outline" 
                  onClick={() => onNavigate('guests')}
                  className="w-full responsive-xs:min-h-[48px] responsive-md:min-h-[44px]"
                >
                  <span className="ml-2">ניהול מוזמנים</span>
                  <ArrowRight size={16} />
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Secondary Actions - Responsive Grid */}
          <div className="grid grid-cols-1 responsive-md:grid-cols-2 responsive-lg:grid-cols-3 gap-6">
            
            {/* Suppliers Card */}
            <Card className="card">
              <CardContent className="p-6 text-center">
                <div 
                  className="w-12 h-12 mx-auto rounded-full flex items-center justify-center mb-4"
                  style={{backgroundColor: 'var(--surface-sky-50)'}}
                >
                  <FileText className="w-6 h-6" style={{color: 'var(--accent-sky)'}} />
                </div>
                <h3 className="mb-2 responsive-xs:text-base responsive-md:text-lg" style={{color: 'var(--text-primary)'}}>
                  ספקים
                </h3>
                <p className="text-sm mb-4" style={{color: 'var(--text-secondary)'}}>
                  {hasCommittedSuppliers 
                    ? `${suppliersVars.committedCount} ספקים נבחרו` 
                    : "עדיין לא נבחרו ספקים"
                  }
                </p>
                <Button 
                  variant="outline" 
                  onClick={() => onNavigate('suppliers')}
                  className="w-full responsive-xs:min-h-[48px] responsive-md:min-h-[44px]"
                >
                  <span className="ml-2">ניהול ספקים</span>
                  <ArrowRight size={16} />
                </Button>
              </CardContent>
            </Card>

            {/* Payments Card */}
            <Card className="card">
              <CardContent className="p-6 text-center">
                <div 
                  className="w-12 h-12 mx-auto rounded-full flex items-center justify-center mb-4"
                  style={{backgroundColor: 'var(--surface-sage-50)'}}
                >
                  <CreditCard className="w-6 h-6" style={{color: 'var(--accent-sage)'}} />
                </div>
                <h3 className="mb-2 responsive-xs:text-base responsive-md:text-lg" style={{color: 'var(--text-primary)'}}>
                  תשלומים קרובים
                </h3>
                <p className="text-sm mb-4" style={{color: 'var(--text-secondary)'}}>
                  {dashVars.upcomingPaymentsCount || "—"} תשלומים השבוע
                </p>
                <Button 
                  variant="outline" 
                  onClick={() => onNavigate('suppliers')}
                  className="w-full responsive-xs:min-h-[48px] responsive-md:min-h-[44px]"
                >
                  <span className="ml-2">לוח תשלומים</span>
                  <ArrowRight size={16} />
                </Button>
              </CardContent>
            </Card>

            {/* Files Card */}
            <Card className="card responsive-md:col-span-2 responsive-lg:col-span-1">
              <CardContent className="p-6 text-center">
                <div 
                  className="w-12 h-12 mx-auto rounded-full flex items-center justify-center mb-4"
                  style={{backgroundColor: 'var(--surface-gold-50)'}}
                >
                  <FileText className="w-6 h-6" style={{color: 'var(--accent-gold)'}} />
                </div>
                <h3 className="mb-2 responsive-xs:text-base responsive-md:text-lg" style={{color: 'var(--text-primary)'}}>
                  קבצים וחוזים
                </h3>
                <p className="text-sm mb-4" style={{color: 'var(--text-secondary)'}}>
                  {dashVars.filesCount || "—"} קבצים הועלו
                </p>
                <Button 
                  variant="outline" 
                  onClick={() => onNavigate('suppliers')}
                  className="w-full responsive-xs:min-h-[48px] responsive-md:min-h-[44px]"
                >
                  <span className="ml-2">ניהול קבצים</span>
                  <ArrowRight size={16} />
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Quick Stats - Only show if we have data */}
          {(hasBudgetData || dashVars.guestsCount > 0 || hasCommittedSuppliers) && (
            <Card className="card">
              <CardHeader>
                <CardTitle className="responsive-xs:text-lg responsive-md:text-xl">סיכום מהיר</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 responsive-md:grid-cols-4 gap-4 text-center">
                  <div>
                    <div className="text-2xl responsive-xs:text-xl font-semibold mb-1" style={{color: 'var(--text-primary)'}}>
                      {dashVars.guestsCount || "—"}
                    </div>
                    <div className="text-xs responsive-xs:text-xs responsive-md:text-sm" style={{color: 'var(--text-secondary)'}}>
                      מוזמנים
                    </div>
                  </div>
                  <div>
                    <div className="text-2xl responsive-xs:text-xl font-semibold mb-1" style={{color: 'var(--text-primary)'}}>
                      {suppliersVars.committedCount || "—"}
                    </div>
                    <div className="text-xs responsive-xs:text-xs responsive-md:text-sm" style={{color: 'var(--text-secondary)'}}>
                      ספקים נבחרו
                    </div>
                  </div>
                  <div>
                    <div className="text-2xl responsive-xs:text-xl font-semibold mb-1" style={{color: 'var(--text-primary)'}}>
                      {dashVars.tasksTodayCount || "—"}
                    </div>
                    <div className="text-xs responsive-xs:text-xs responsive-md:text-sm" style={{color: 'var(--text-secondary)'}}>
                      משימות היום
                    </div>
                  </div>
                  <div>
                    <div className="text-2xl responsive-xs:text-xl font-semibold mb-1" style={{color: 'var(--text-primary)'}}>
                      {formatCurrency(budgetVars.forecastTotal)}
                    </div>
                    <div className="text-xs responsive-xs:text-xs responsive-md:text-sm" style={{color: 'var(--text-secondary)'}}>
                      תחזית תקציב
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}