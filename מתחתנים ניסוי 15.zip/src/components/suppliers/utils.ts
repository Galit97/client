import { BudgetVars, SuppliersVars, Vendor } from './types';

// Helper function to format currency
export const formatCurrency = (amount: number): string => {
  if (amount === 0) return "—";
  return new Intl.NumberFormat('he-IL', {
    style: 'currency',
    currency: 'ILS',
    minimumFractionDigits: 0
  }).format(amount);
};

// Calculate normalized total for a vendor
export const calculateNormalizedTotal = (vendor: Vendor, budgetVars: BudgetVars): number => {
  if (vendor.type === 'perGuest') {
    const guestCount = budgetVars.guestsExact > 0 
      ? budgetVars.guestsExact 
      : Math.round((budgetVars.guestsMin + budgetVars.guestsMax) / 2);
    return vendor.perGuest * guestCount;
  }
  return vendor.total;
};

// Convert suppliersVars to vendor array for easier processing
export const convertSuppliersVarsToVendors = (suppliersVars: SuppliersVars): Vendor[] => {
  const vendorList: Vendor[] = [];
  for (let i = 1; i <= 20; i++) {
    const visible = suppliersVars[`vendor${i}_visible`];
    if (visible) {
      vendorList.push({
        id: i,
        visible,
        name: suppliersVars[`vendor${i}_name`] || '',
        category: suppliersVars[`vendor${i}_category`] || '',
        status: suppliersVars[`vendor${i}_status`] || '',
        type: suppliersVars[`vendor${i}_type`] || '',
        total: suppliersVars[`vendor${i}_total`] || 0,
        perGuest: suppliersVars[`vendor${i}_perGuest`] || 0,
        email: suppliersVars[`vendor${i}_email`] || '',
        phone: suppliersVars[`vendor${i}_phone`] || '',
        offerExpiry: suppliersVars[`vendor${i}_offerExpiry`] || '',
        deposit: suppliersVars[`vendor${i}_deposit`] || 0,
        remaining: suppliersVars[`vendor${i}_remaining`] || 0,
        nextDue: suppliersVars[`vendor${i}_nextDue`] || '',
        notes: suppliersVars[`vendor${i}_notes`] || '',
        totalNormalized: suppliersVars[`vendor${i}_totalNormalized`] || 0
      });
    }
  }
  return vendorList;
};

// Get overall stats from vendors
export const getOverallStats = (vendors: Vendor[]) => {
  const total = vendors.length;
  const committed = vendors.filter(v => v.status === 'התחייב').length;
  const offer = vendors.filter(v => v.status === 'הצעה').length;
  const open = vendors.filter(v => v.status === 'פתוח').length;
  return { total, committed, offer, open };
};

// Filter and sort vendors
export const filterAndSortVendors = (
  vendors: Vendor[], 
  searchQuery: string, 
  selectedCategory: string, 
  statusFilter: string, 
  sortBy: string
): Vendor[] => {
  let filtered = vendors.filter(vendor => {
    // Search filter
    if (searchQuery && !vendor.name.toLowerCase().includes(searchQuery.toLowerCase())) {
      return false;
    }
    
    // Category filter
    if (selectedCategory && selectedCategory !== 'all' && vendor.category !== selectedCategory) {
      return false;
    }
    
    // Status filter
    if (statusFilter && statusFilter !== 'הכל' && vendor.status !== statusFilter) {
      return false;
    }
    
    return true;
  });

  // Sort
  filtered.sort((a, b) => {
    switch (sortBy) {
      case 'price':
        return b.totalNormalized - a.totalNormalized;
      case 'deadline':
        if (!a.nextDue && !b.nextDue) return 0;
        if (!a.nextDue) return 1;
        if (!b.nextDue) return -1;
        return new Date(a.nextDue).getTime() - new Date(b.nextDue).getTime();
      case 'name':
      default:
        return a.name.localeCompare(b.name, 'he');
    }
  });

  return filtered;
};