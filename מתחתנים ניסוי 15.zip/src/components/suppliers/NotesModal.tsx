import React from 'react';
import { Button } from '../ui/button';
import { Label } from '../ui/label';
import { Textarea } from '../ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '../ui/dialog';
import { Upload, Paperclip } from 'lucide-react';

interface NotesModalProps {
  showModal: boolean;
  setShowModal: (show: boolean) => void;
}

export function NotesModal({ showModal, setShowModal }: NotesModalProps) {
  return (
    <Dialog open={showModal} onOpenChange={setShowModal}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>הערות וחוזה</DialogTitle>
          <DialogDescription>
            הערות פרטיות וקבצים לספק
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div>
            <Label>הערות פרטיות</Label>
            <Textarea
              className="focus:ring-2 focus:ring-primary"
              dir="rtl"
              rows={6}
              placeholder="הערות פרטיות, תנאים מיוחדים, פרטי התקשרות נוספים..."
            />
          </div>

          <div>
            <Label>קבצים וחוזים</Label>
            <div className="border-2 border-dashed border-border rounded-lg p-6 text-center">
              <Upload className="w-8 h-8 mx-auto mb-2 text-muted-foreground" />
              <p className="text-sm text-muted-foreground">
                גררו קבצים לכאן או לחצו לבחירה
              </p>
              <Button variant="outline" className="mt-2 focus:ring-2 focus:ring-primary responsive-xs:min-h-[48px] responsive-md:min-h-[44px]">
                <Paperclip className="w-4 h-4 ml-2" />
                בחרו קבצים
              </Button>
            </div>
          </div>

          <div className="flex gap-2 justify-end">
            <Button
              variant="outline"
              onClick={() => setShowModal(false)}
              className="focus:ring-2 focus:ring-primary responsive-xs:min-h-[48px] responsive-md:min-h-[44px]"
            >
              סגור
            </Button>
            <Button
              className="btn-primary focus:ring-2 focus:ring-primary responsive-xs:min-h-[48px] responsive-md:min-h-[44px]"
            >
              שמור
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}