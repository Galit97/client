import React from 'react';

interface SupplierStatusBadgeProps {
  status: string; // "" | "פתוח" | "הצעה" | "התחייב"
  className?: string;
}

export function SupplierStatusBadge({ status, className = '' }: SupplierStatusBadgeProps) {
  if (!status) return null;

  const getStatusConfig = (status: string) => {
    switch (status) {
      case 'התחייב':
        return {
          label: 'התחייב',
          backgroundColor: 'var(--semantic-success-bg)',
          borderColor: 'var(--semantic-success-border)',
          textColor: 'var(--semantic-success-text)'
        };
      case 'הצעה':
        return {
          label: 'הצעה',
          backgroundColor: 'var(--semantic-info-bg)',
          borderColor: 'var(--semantic-info-border)',
          textColor: 'var(--semantic-info-text)'
        };
      case 'פתוח':
        return {
          label: 'פתוח',
          backgroundColor: 'var(--semantic-warning-bg)',
          borderColor: 'var(--semantic-warning-border)',
          textColor: 'var(--semantic-warning-text)'
        };
      default:
        return {
          label: status,
          backgroundColor: 'var(--base-bg)',
          borderColor: 'var(--border-subtle)',
          textColor: 'var(--text-secondary)'
        };
    }
  };

  const config = getStatusConfig(status);

  return (
    <span
      className={`inline-flex items-center px-2 py-1 text-xs font-medium rounded-md border ${className}`}
      style={{
        backgroundColor: config.backgroundColor,
        borderColor: config.borderColor,
        color: config.textColor
      }}
    >
      {config.label}
    </span>
  );
}