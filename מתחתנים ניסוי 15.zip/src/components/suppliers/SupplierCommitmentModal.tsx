import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '../ui/dialog';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { X } from 'lucide-react';

interface SupplierCommitmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (finalAmount: number, deposit: number) => void;
  supplierName: string;
  isNewSupplier?: boolean;
}

export function SupplierCommitmentModal({
  isOpen,
  onClose,
  onConfirm,
  supplierName,
  isNewSupplier = false
}: SupplierCommitmentModalProps) {
  const [finalAmount, setFinalAmount] = useState<string>('');
  const [deposit, setDeposit] = useState<string>('');

  const handleConfirm = () => {
    const finalAmountNum = parseFloat(finalAmount) || 0;
    const depositNum = parseFloat(deposit) || 0;
    
    if (finalAmountNum > 0) {
      onConfirm(finalAmountNum, depositNum);
      // Reset form
      setFinalAmount('');
      setDeposit('');
      onClose();
    }
  };

  const handleClose = () => {
    setFinalAmount('');
    setDeposit('');
    onClose();
  };

  // Calculate remaining amount
  const finalAmountNum = parseFloat(finalAmount) || 0;
  const depositNum = parseFloat(deposit) || 0;
  const remaining = Math.max(0, finalAmountNum - depositNum);

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-md mx-auto" dir="rtl">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="text-right">
              התחייבות ספק
            </DialogTitle>
            <Button
              variant="ghost"
              size="icon"
              onClick={handleClose}
              className="h-8 w-8 p-0"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* Supplier Name */}
          <div className="p-4 rounded-lg" style={{ backgroundColor: 'var(--surface-sky-50)' }}>
            <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
              ספק
            </p>
            <p className="font-medium" style={{ color: 'var(--text-primary)' }}>
              {supplierName || 'ספק חדש'}
            </p>
          </div>

          {/* Final Amount */}
          <div className="space-y-2">
            <Label htmlFor="finalAmount" className="text-right block">
              סכום סופי (₪) <span className="text-red-500">*</span>
            </Label>
            <Input
              id="finalAmount"
              type="number"
              inputMode="numeric"
              value={finalAmount}
              onChange={(e) => setFinalAmount(e.target.value)}
              placeholder="הזינו סכום סופי"
              className="text-right focus:ring-2 focus:ring-ring"
              dir="rtl"
              min="0"
              step="100"
            />
          </div>

          {/* Deposit */}
          <div className="space-y-2">
            <Label htmlFor="deposit" className="text-right block">
              מקדמה ששולמה (₪)
            </Label>
            <Input
              id="deposit"
              type="number"
              inputMode="numeric"
              value={deposit}
              onChange={(e) => setDeposit(e.target.value)}
              placeholder="הזינו מקדמה ששולמה (אופציונלי)"
              className="text-right focus:ring-2 focus:ring-ring"
              dir="rtl"
              min="0"
              step="100"
            />
          </div>

          {/* Remaining Amount (Read-only display) */}
          {finalAmountNum > 0 && (
            <div className="space-y-2">
              <Label className="text-right block" style={{ color: 'var(--text-secondary)' }}>
                יתרה לתשלום (₪)
              </Label>
              <div 
                className="p-3 rounded-lg border text-right"
                style={{ 
                  backgroundColor: 'var(--base-bg)', 
                  borderColor: 'var(--border-subtle)',
                  color: 'var(--text-primary)'
                }}
              >
                ₪{remaining.toLocaleString('he-IL')}
              </div>
            </div>
          )}

          {/* Helper Text */}
          <div 
            className="p-3 rounded-lg text-sm text-right"
            style={{
              backgroundColor: 'var(--semantic-info-bg)',
              color: 'var(--semantic-info-text)'
            }}
          >
            ספק 'התחייב' נכנס מיד לתקציב.
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3 pt-4">
            <Button
              variant="outline"
              onClick={handleClose}
              className="flex-1 focus:ring-2 focus:ring-ring"
            >
              ביטול
            </Button>
            <Button
              onClick={handleConfirm}
              disabled={!finalAmount || parseFloat(finalAmount) <= 0}
              className="flex-1 focus:ring-2 focus:ring-ring"
              style={{
                backgroundColor: 'var(--brand-primary)',
                color: 'var(--text-inverse)'
              }}
            >
              אישור
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}