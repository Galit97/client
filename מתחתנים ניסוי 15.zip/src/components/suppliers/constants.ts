// Categories for suppliers - Hebrew
export const SUPPLIER_CATEGORIES = [
  'אולם/קייטרינג',
  'מוזיקה/DJ', 
  'צילום/וידאו',
  'פרחים/דקור',
  'שמלה/חליפה',
  'טבעות',
  'רב/חופה',
  'הדפסות/הזמנות',
  'תחבורה',
  'בר',
  'אחרות'
];