import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '../ui/dialog';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Textarea } from '../ui/textarea';
import { Checkbox } from '../ui/checkbox';
import { X } from 'lucide-react';

interface SuppliersVars {
  vendor1_visible: boolean;
  vendor1_name: string;
  vendor1_category: string;
  vendor1_status: string;
  vendor1_email: string;
  vendor1_phone: string;
  vendor1_notes: string;
  vendor1_finalAmount: number;
  vendor1_deposit: number;
  vendor1_remaining: number;
  vendor2_visible: boolean;
  vendor2_name: string;
  vendor2_category: string;
  vendor2_status: string;
  vendor2_email: string;
  vendor2_phone: string;
  vendor2_notes: string;
  vendor2_finalAmount: number;
  vendor2_deposit: number;
  vendor2_remaining: number;
  vendor3_visible: boolean;
  vendor3_name: string;
  vendor3_category: string;
  vendor3_status: string;
  vendor3_email: string;
  vendor3_phone: string;
  vendor3_notes: string;
  vendor3_finalAmount: number;
  vendor3_deposit: number;
  vendor3_remaining: number;
  vendor4_visible: boolean;
  vendor4_name: string;
  vendor4_category: string;
  vendor4_status: string;
  vendor4_email: string;
  vendor4_phone: string;
  vendor4_notes: string;
  vendor4_finalAmount: number;
  vendor4_deposit: number;
  vendor4_remaining: number;
  vendor5_visible: boolean;
  vendor5_name: string;
  vendor5_category: string;
  vendor5_status: string;
  vendor5_email: string;
  vendor5_phone: string;
  vendor5_notes: string;
  vendor5_finalAmount: number;
  vendor5_deposit: number;
  vendor5_remaining: number;
  vendor6_visible: boolean;
  vendor6_name: string;
  vendor6_category: string;
  vendor6_status: string;
  vendor6_email: string;
  vendor6_phone: string;
  vendor6_notes: string;
  vendor6_finalAmount: number;
  vendor6_deposit: number;
  vendor6_remaining: number;
  vendor7_visible: boolean;
  vendor7_name: string;
  vendor7_category: string;
  vendor7_status: string;
  vendor7_email: string;
  vendor7_phone: string;
  vendor7_notes: string;
  vendor7_finalAmount: number;
  vendor7_deposit: number;
  vendor7_remaining: number;
  vendor8_visible: boolean;
  vendor8_name: string;
  vendor8_category: string;
  vendor8_status: string;
  vendor8_email: string;
  vendor8_phone: string;
  vendor8_notes: string;
  vendor8_finalAmount: number;
  vendor8_deposit: number;
  vendor8_remaining: number;
}

interface SupplierModalProps {
  isOpen: boolean;
  onClose: () => void;
  suppliersVars: SuppliersVars;
  setSuppliersVars: (vars: SuppliersVars) => void;
  onSupplierCommitted: (supplierName: string, finalAmount: number) => void;
}

// Supplier categories - predefined list
const SUPPLIER_CATEGORIES = [
  'אולם אירועים',
  'קייטרינג',
  'צלם',
  'די.ג\'יי',
  'כלי נגינה',
  'פרחים ועיצוב',
  'הובלות',
  'שמלה וחליפה',
  'איפור ושיער',
  'עוגה',
  'הזמנות',
  'כשרות',
  'אחר'
];

export function SupplierModal({
  isOpen,
  onClose,
  suppliersVars,
  setSuppliersVars,
  onSupplierCommitted
}: SupplierModalProps) {
  const [formData, setFormData] = useState({
    name: '',
    category: '',
    email: '',
    phone: '',
    notes: '',
    isCommitted: false,
    finalAmount: '',
    deposit: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Find the first available vendor slot
    let availableSlot = -1;
    for (let i = 1; i <= 8; i++) {
      const visible = suppliersVars[`vendor${i}_visible` as keyof SuppliersVars] as boolean;
      if (!visible) {
        availableSlot = i;
        break;
      }
    }

    if (availableSlot === -1) {
      alert('אין מקום לספקים נוספים (מקסימום 8)');
      return;
    }

    const vendorKey = `vendor${availableSlot}`;
    const finalAmountNum = parseFloat(formData.finalAmount) || 0;
    const depositNum = parseFloat(formData.deposit) || 0;
    
    // Update supplier data
    const updatedVars = {
      ...suppliersVars,
      [`${vendorKey}_visible`]: true,
      [`${vendorKey}_name`]: formData.name,
      [`${vendorKey}_category`]: formData.category,
      [`${vendorKey}_status`]: formData.isCommitted ? 'התחייב' : 'פתוח',
      [`${vendorKey}_email`]: formData.email,
      [`${vendorKey}_phone`]: formData.phone,
      [`${vendorKey}_notes`]: formData.notes,
      [`${vendorKey}_finalAmount`]: finalAmountNum,
      [`${vendorKey}_deposit`]: depositNum,
      [`${vendorKey}_remaining`]: finalAmountNum - depositNum
    };

    setSuppliersVars(updatedVars);

    // If committed, trigger the callback
    if (formData.isCommitted && finalAmountNum > 0) {
      onSupplierCommitted(formData.name, finalAmountNum);
    }

    // Reset form and close
    setFormData({
      name: '',
      category: '',
      email: '',
      phone: '',
      notes: '',
      isCommitted: false,
      finalAmount: '',
      deposit: ''
    });
    onClose();
  };

  const handleClose = () => {
    setFormData({
      name: '',
      category: '',
      email: '',
      phone: '',
      notes: '',
      isCommitted: false,
      finalAmount: '',
      deposit: ''
    });
    onClose();
  };

  const finalAmountNum = parseFloat(formData.finalAmount) || 0;
  const depositNum = parseFloat(formData.deposit) || 0;
  const remaining = Math.max(0, finalAmountNum - depositNum);

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-md mx-auto max-h-[90vh] overflow-y-auto" dir="rtl">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="text-right">
              הוספת ספק חדש
            </DialogTitle>
            <Button
              variant="ghost"
              size="icon"
              onClick={handleClose}
              className="h-8 w-8 p-0"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
          <DialogDescription className="text-right text-sm" style={{ color: 'var(--text-secondary)' }}>
            הזינו את פרטי הספק. תוכלו לסמן אותו כמחויב מיד או בדיעבד.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6 py-4">
          {/* Supplier Name */}
          <div className="space-y-2">
            <Label htmlFor="name" className="text-right block">
              שם הספק <span className="text-red-500">*</span>
            </Label>
            <Input
              id="name"
              type="text"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              placeholder="הזינו שם ספק"
              className="text-right focus:ring-2 focus:ring-ring"
              dir="rtl"
              required
            />
          </div>

          {/* Category */}
          <div className="space-y-2">
            <Label htmlFor="category" className="text-right block">
              קטגוריה <span className="text-red-500">*</span>
            </Label>
            <Select value={formData.category} onValueChange={(value) => setFormData({ ...formData, category: value })}>
              <SelectTrigger className="text-right focus:ring-2 focus:ring-ring" dir="rtl">
                <SelectValue placeholder="בחרו קטגוריה" />
              </SelectTrigger>
              <SelectContent dir="rtl">
                {SUPPLIER_CATEGORIES.map(category => (
                  <SelectItem key={category} value={category}>
                    {category}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Contact Details */}
          <div className="grid grid-cols-1 gap-4">
            <div className="space-y-2">
              <Label htmlFor="email" className="text-right block">
                אימייל
              </Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                placeholder="example@email.com"
                className="text-right focus:ring-2 focus:ring-ring"
                dir="rtl"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="phone" className="text-right block">
                טלפון
              </Label>
              <Input
                id="phone"
                type="tel"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                placeholder="050-123-4567"
                className="text-right focus:ring-2 focus:ring-ring"
                dir="rtl"
              />
            </div>
          </div>

          {/* Commitment Section */}
          <div className="space-y-4 p-4 rounded-lg" style={{ backgroundColor: 'var(--surface-sky-50)' }}>
            <div className="flex items-center space-x-2 space-x-reverse">
              <Checkbox
                id="committed"
                checked={formData.isCommitted}
                onCheckedChange={(checked) => setFormData({ ...formData, isCommitted: !!checked })}
              />
              <Label htmlFor="committed" className="text-right">
                הספק התחייב
              </Label>
            </div>

            {formData.isCommitted && (
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="finalAmount" className="text-right block">
                    סכום סופי (₪) <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="finalAmount"
                    type="number"
                    inputMode="numeric"
                    value={formData.finalAmount}
                    onChange={(e) => setFormData({ ...formData, finalAmount: e.target.value })}
                    placeholder="הזינו סכום סופי"
                    className="text-right focus:ring-2 focus:ring-ring"
                    dir="rtl"
                    min="0"
                    step="100"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="deposit" className="text-right block">
                    מקדמה ששולמה (₪)
                  </Label>
                  <Input
                    id="deposit"
                    type="number"
                    inputMode="numeric"
                    value={formData.deposit}
                    onChange={(e) => setFormData({ ...formData, deposit: e.target.value })}
                    placeholder="הזינו מקדמה ששולמה (אופציונלי)"
                    className="text-right focus:ring-2 focus:ring-ring"
                    dir="rtl"
                    min="0"
                    step="100"
                  />
                </div>

                {finalAmountNum > 0 && (
                  <div className="space-y-2">
                    <Label className="text-right block" style={{ color: 'var(--text-secondary)' }}>
                      יתרה לתשלום (₪)
                    </Label>
                    <div 
                      className="p-3 rounded-lg border text-right"
                      style={{ 
                        backgroundColor: 'var(--base-bg)', 
                        borderColor: 'var(--border-subtle)',
                        color: 'var(--text-primary)'
                      }}
                    >
                      ₪{remaining.toLocaleString('he-IL')}
                    </div>
                  </div>
                )}

                <p 
                  className="text-sm text-right"
                  style={{ color: 'var(--semantic-info-text)' }}
                >
                  ספק 'התחייב' נכנס מיד לתקציב.
                </p>
              </div>
            )}
          </div>

          {/* Notes */}
          <div className="space-y-2">
            <Label htmlFor="notes" className="text-right block">
              הערות
            </Label>
            <Textarea
              id="notes"
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              placeholder="הערות נוספות על הספק..."
              className="text-right focus:ring-2 focus:ring-ring min-h-[80px]"
              dir="rtl"
            />
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={handleClose}
              className="flex-1 focus:ring-2 focus:ring-ring"
            >
              ביטול
            </Button>
            <Button
              type="submit"
              disabled={!formData.name || !formData.category || (formData.isCommitted && !formData.finalAmount)}
              className="flex-1 focus:ring-2 focus:ring-ring"
              style={{
                backgroundColor: 'var(--brand-primary)',
                color: 'var(--text-inverse)'
              }}
            >
              שמירה
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}