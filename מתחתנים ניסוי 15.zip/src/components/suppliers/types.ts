export interface BudgetVars {
  guestsMin: number;
  guestsMax: number;
  guestsExact: number;
  giftAvg: number;
  targetMode: string;
  ownContribution: number;
  savePercent: number;
  giftsMin: number;
  giftsMax: number;
  targetExact: number;
  targetMin: number;
  targetMax: number;
  forecastTotal: number;
}

export interface SuppliersVars {
  committedCount: number;
  [key: string]: any; // For vendor1_name, vendor2_name, etc.
}

export interface SuppliersProps {
  budgetVars: BudgetVars;
  suppliersVars: SuppliersVars;
  setSuppliersVars: (vars: SuppliersVars) => void;
  onNavigate: (screen: string) => void;
}

export interface Vendor {
  id: number;
  visible: boolean;
  name: string;
  category: string;
  status: string;
  type: string;
  total: number;
  perGuest: number;
  email: string;
  phone: string;
  offerExpiry: string;
  deposit: number;
  remaining: number;
  nextDue: string;
  notes: string;
  totalNormalized: number;
}

export interface SupplierFormData {
  name: string;
  category: string;
  status: string;
  type: string;
  total: number;
  perGuest: number;
  email: string;
  phone: string;
  offerExpiry: string;
  deposit: number;
  remaining: number;
  nextDue: string;
  notes: string;
}