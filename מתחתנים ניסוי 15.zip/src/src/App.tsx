import { useState, useEffect } from 'react';
import { Layout } from './components/Layout';
import { Auth } from './components/Auth';
import { Dashboard } from './components/Dashboard';
import { Budget } from './components/Budget';
import { NewBudgetWizard } from './components/NewBudgetWizard';
import { BudgetOverview } from './components/BudgetOverview';
import { EventDateSelector } from './components/EventDateSelector';
import { Suppliers } from './components/Suppliers';
import { Guests } from './components/Guests';
import { Tasks } from './components/Tasks';
import { Toaster } from './components/ui/sonner';

type Screen = 'auth' | 'dashboard' | 'budget' | 'new-budget-wizard' | 'budget-overview' | 'event-date' | 'guests' | 'tasks' | 'suppliers' | 'settings';

// Figma Variables Collections - ALL EMPTY BY DEFAULT
interface AppState {
  isAuthenticated: boolean;
  isViewOnly: boolean;
  hasEventDate: boolean;
  coupleName: string;
}

interface Event {
  eventName: string;
  eventNameEdited: boolean;
  eventDate: string;
}

interface Countdown {
  daysLeft: number;
}

interface RSVPVars {
  invitedCount: number;
  acceptedCount: number;
  maybeCount: number;
  noReplyCount: number;
  declinedCount: number;
}

interface BudgetVars {
  guestsMin: number;
  guestsMax: number;
  guestsExact: number;
  giftAvg: number;
  targetMode: string; // "reset" | "add" | "save"
  ownContribution: number;
  savePercent: number;
  giftsMin: number;
  giftsMax: number;
  targetExact: number;
  targetMin: number;
  targetMax: number;
  forecastTotal: number;
}

interface PricingTier {
  min: number;
  max: number;
  pricePerGuest: number;
}

interface AddonItem {
  label: string;
  amount: number;
  enabled: boolean;
}

interface ChildrenRules {
  freeUnder: number;
  percentUnder: number;
  staffRate: number;
}

interface SuppliersVars {
  committedCount: number;
  // Vendor 1
  vendor1_visible: boolean;
  vendor1_name: string;
  vendor1_category: string;
  vendor1_status: string; // "" | "פתוח" | "הצעה" | "התחייב"
  vendor1_type: string; // "" | "venue" | "catering" | "total" | "perGuest"
  vendor1_email: string;
  vendor1_phone: string;
  vendor1_offerExpiry: string;
  vendor1_deposit: number;
  vendor1_remaining: number;
  vendor1_nextDue: string;
  vendor1_notes: string;
  // BASE PRICING
  vendor1_chargeMode: string; // "" | "perGuest" | "packagePerGuest" | "packageOnly"
  vendor1_pricePerGuest: number;
  vendor1_minChargeGuests: number;
  vendor1_minChargeAmount: number;
  vendor1_daySeason: string; // " mainstream" | "weekend" | "peak season"
  vendor1_daySeasonMultiplier: number;
  // ADVANCED TIERS & ADD-ONS
  vendor1_tiers: PricingTier[];
  vendor1_addonsPerGuest: AddonItem[];
  vendor1_addonsPerEvent: AddonItem[];
  vendor1_childrenRules: ChildrenRules;
  // LIVE SCENARIO
  vendor1_scenarioMode: string; // "min" | "likely" | "max"
  vendor1_maybePct: number;
  vendor1_noReplyPct: number;
  vendor1_arrivalFactor: number;
  // COMPUTED (read-only in UI)
  vendor1_guestsMin: number;
  vendor1_guestsLikely: number;
  vendor1_guestsMax: number;
  vendor1_guestsChosen: number;
  vendor1_totalFloor: number;
  vendor1_totalForecast: number;
  vendor1_totalCeiling: number;
  vendor1_breakdownText: string;
  vendor1_totalNormalized: number;
  // Vendor 2
  vendor2_visible: boolean;
  vendor2_name: string;
  vendor2_category: string;
  vendor2_status: string;
  vendor2_type: string;
  vendor2_email: string;
  vendor2_phone: string;
  vendor2_offerExpiry: string;
  vendor2_deposit: number;
  vendor2_remaining: number;
  vendor2_nextDue: string;
  vendor2_notes: string;
  vendor2_chargeMode: string;
  vendor2_pricePerGuest: number;
  vendor2_minChargeGuests: number;
  vendor2_minChargeAmount: number;
  vendor2_daySeason: string;
  vendor2_daySeasonMultiplier: number;
  vendor2_tiers: PricingTier[];
  vendor2_addonsPerGuest: AddonItem[];
  vendor2_addonsPerEvent: AddonItem[];
  vendor2_childrenRules: ChildrenRules;
  vendor2_scenarioMode: string;
  vendor2_maybePct: number;
  vendor2_noReplyPct: number;
  vendor2_arrivalFactor: number;
  vendor2_guestsMin: number;
  vendor2_guestsLikely: number;
  vendor2_guestsMax: number;
  vendor2_guestsChosen: number;
  vendor2_totalFloor: number;
  vendor2_totalForecast: number;
  vendor2_totalCeiling: number;
  vendor2_breakdownText: string;
  vendor2_totalNormalized: number;
  // Vendor 3
  vendor3_visible: boolean;
  vendor3_name: string;
  vendor3_category: string;
  vendor3_status: string;
  vendor3_type: string;
  vendor3_email: string;
  vendor3_phone: string;
  vendor3_offerExpiry: string;
  vendor3_deposit: number;
  vendor3_remaining: number;
  vendor3_nextDue: string;
  vendor3_notes: string;
  vendor3_chargeMode: string;
  vendor3_pricePerGuest: number;
  vendor3_minChargeGuests: number;
  vendor3_minChargeAmount: number;
  vendor3_daySeason: string;
  vendor3_daySeasonMultiplier: number;
  vendor3_tiers: PricingTier[];
  vendor3_addonsPerGuest: AddonItem[];
  vendor3_addonsPerEvent: AddonItem[];
  vendor3_childrenRules: ChildrenRules;
  vendor3_scenarioMode: string;
  vendor3_maybePct: number;
  vendor3_noReplyPct: number;
  vendor3_arrivalFactor: number;
  vendor3_guestsMin: number;
  vendor3_guestsLikely: number;
  vendor3_guestsMax: number;
  vendor3_guestsChosen: number;
  vendor3_totalFloor: number;
  vendor3_totalForecast: number;
  vendor3_totalCeiling: number;
  vendor3_breakdownText: string;
  vendor3_totalNormalized: number;
  // Vendor 4
  vendor4_visible: boolean;
  vendor4_name: string;
  vendor4_category: string;
  vendor4_status: string;
  vendor4_type: string;
  vendor4_email: string;
  vendor4_phone: string;
  vendor4_offerExpiry: string;
  vendor4_deposit: number;
  vendor4_remaining: number;
  vendor4_nextDue: string;
  vendor4_notes: string;
  vendor4_chargeMode: string;
  vendor4_pricePerGuest: number;
  vendor4_minChargeGuests: number;
  vendor4_minChargeAmount: number;
  vendor4_daySeason: string;
  vendor4_daySeasonMultiplier: number;
  vendor4_tiers: PricingTier[];
  vendor4_addonsPerGuest: AddonItem[];
  vendor4_addonsPerEvent: AddonItem[];
  vendor4_childrenRules: ChildrenRules;
  vendor4_scenarioMode: string;
  vendor4_maybePct: number;
  vendor4_noReplyPct: number;
  vendor4_arrivalFactor: number;
  vendor4_guestsMin: number;
  vendor4_guestsLikely: number;
  vendor4_guestsMax: number;
  vendor4_guestsChosen: number;
  vendor4_totalFloor: number;
  vendor4_totalForecast: number;
  vendor4_totalCeiling: number;
  vendor4_breakdownText: string;
  vendor4_totalNormalized: number;
  // Vendor 5
  vendor5_visible: boolean;
  vendor5_name: string;
  vendor5_category: string;
  vendor5_status: string;
  vendor5_type: string;
  vendor5_email: string;
  vendor5_phone: string;
  vendor5_offerExpiry: string;
  vendor5_deposit: number;
  vendor5_remaining: number;
  vendor5_nextDue: string;
  vendor5_notes: string;
  vendor5_chargeMode: string;
  vendor5_pricePerGuest: number;
  vendor5_minChargeGuests: number;
  vendor5_minChargeAmount: number;
  vendor5_daySeason: string;
  vendor5_daySeasonMultiplier: number;
  vendor5_tiers: PricingTier[];
  vendor5_addonsPerGuest: AddonItem[];
  vendor5_addonsPerEvent: AddonItem[];
  vendor5_childrenRules: ChildrenRules;
  vendor5_scenarioMode: string;
  vendor5_maybePct: number;
  vendor5_noReplyPct: number;
  vendor5_arrivalFactor: number;
  vendor5_guestsMin: number;
  vendor5_guestsLikely: number;
  vendor5_guestsMax: number;
  vendor5_guestsChosen: number;
  vendor5_totalFloor: number;
  vendor5_totalForecast: number;
  vendor5_totalCeiling: number;
  vendor5_breakdownText: string;
  vendor5_totalNormalized: number;
  // Vendor 6
  vendor6_visible: boolean;
  vendor6_name: string;
  vendor6_category: string;
  vendor6_status: string;
  vendor6_type: string;
  vendor6_email: string;
  vendor6_phone: string;
  vendor6_offerExpiry: string;
  vendor6_deposit: number;
  vendor6_remaining: number;
  vendor6_nextDue: string;
  vendor6_notes: string;
  vendor6_chargeMode: string;
  vendor6_pricePerGuest: number;
  vendor6_minChargeGuests: number;
  vendor6_minChargeAmount: number;
  vendor6_daySeason: string;
  vendor6_daySeasonMultiplier: number;
  vendor6_tiers: PricingTier[];
  vendor6_addonsPerGuest: AddonItem[];
  vendor6_addonsPerEvent: AddonItem[];
  vendor6_childrenRules: ChildrenRules;
  vendor6_scenarioMode: string;
  vendor6_maybePct: number;
  vendor6_noReplyPct: number;
  vendor6_arrivalFactor: number;
  vendor6_guestsMin: number;
  vendor6_guestsLikely: number;
  vendor6_guestsMax: number;
  vendor6_guestsChosen: number;
  vendor6_totalFloor: number;
  vendor6_totalForecast: number;
  vendor6_totalCeiling: number;
  vendor6_breakdownText: string;
  vendor6_totalNormalized: number;
  // Vendor 7
  vendor7_visible: boolean;
  vendor7_name: string;
  vendor7_category: string;
  vendor7_status: string;
  vendor7_type: string;
  vendor7_email: string;
  vendor7_phone: string;
  vendor7_offerExpiry: string;
  vendor7_deposit: number;
  vendor7_remaining: number;
  vendor7_nextDue: string;
  vendor7_notes: string;
  vendor7_chargeMode: string;
  vendor7_pricePerGuest: number;
  vendor7_minChargeGuests: number;
  vendor7_minChargeAmount: number;
  vendor7_daySeason: string;
  vendor7_daySeasonMultiplier: number;
  vendor7_tiers: PricingTier[];
  vendor7_addonsPerGuest: AddonItem[];
  vendor7_addonsPerEvent: AddonItem[];
  vendor7_childrenRules: ChildrenRules;
  vendor7_scenarioMode: string;
  vendor7_maybePct: number;
  vendor7_noReplyPct: number;
  vendor7_arrivalFactor: number;
  vendor7_guestsMin: number;
  vendor7_guestsLikely: number;
  vendor7_guestsMax: number;
  vendor7_guestsChosen: number;
  vendor7_totalFloor: number;
  vendor7_totalForecast: number;
  vendor7_totalCeiling: number;
  vendor7_breakdownText: string;
  vendor7_totalNormalized: number;
  // Vendor 8
  vendor8_visible: boolean;
  vendor8_name: string;
  vendor8_category: string;
  vendor8_status: string;
  vendor8_type: string;
  vendor8_email: string;
  vendor8_phone: string;
  vendor8_offerExpiry: string;
  vendor8_deposit: number;
  vendor8_remaining: number;
  vendor8_nextDue: string;
  vendor8_notes: string;
  vendor8_chargeMode: string;
  vendor8_pricePerGuest: number;
  vendor8_minChargeGuests: number;
  vendor8_minChargeAmount: number;
  vendor8_daySeason: string;
  vendor8_daySeasonMultiplier: number;
  vendor8_tiers: PricingTier[];
  vendor8_addonsPerGuest: AddonItem[];
  vendor8_addonsPerEvent: AddonItem[];
  vendor8_childrenRules: ChildrenRules;
  vendor8_scenarioMode: string;
  vendor8_maybePct: number;
  vendor8_noReplyPct: number;
  vendor8_arrivalFactor: number;
  vendor8_guestsMin: number;
  vendor8_guestsLikely: number;
  vendor8_guestsMax: number;
  vendor8_guestsChosen: number;
  vendor8_totalFloor: number;
  vendor8_totalForecast: number;
  vendor8_totalCeiling: number;
  vendor8_breakdownText: string;
  vendor8_totalNormalized: number;
}

interface DashVars {
  tasksTodayCount: number;
  guestsCount: number;
}

// Helper function to calculate days between dates
const dateDiffInDays = (startDate: Date, endDate: Date): number => {
  const diffTime = endDate.getTime() - startDate.getTime();
  return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
};

// Helper function to compute vendor pricing
const computeVendorPricing = (
  vendorIndex: number,
  suppliersVars: SuppliersVars,
  rsvpVars: RSVPVars,
  budgetVars: BudgetVars
) => {
  const prefix = `vendor${vendorIndex}_`;
  
  // Get vendor data
  const visible = suppliersVars[`${prefix}visible` as keyof SuppliersVars] as boolean;
  if (!visible) return {};

  const scenarioMode = suppliersVars[`${prefix}scenarioMode` as keyof SuppliersVars] as string || "likely";
  const maybePct = suppliersVars[`${prefix}maybePct` as keyof SuppliersVars] as number || 0.6;
  const noReplyPct = suppliersVars[`${prefix}noReplyPct` as keyof SuppliersVars] as number || 0.3;
  const arrivalFactor = suppliersVars[`${prefix}arrivalFactor` as keyof SuppliersVars] as number || 1.0;
  const pricePerGuest = suppliersVars[`${prefix}pricePerGuest` as keyof SuppliersVars] as number || 0;
  const minChargeGuests = suppliersVars[`${prefix}minChargeGuests` as keyof SuppliersVars] as number || 0;
  const minChargeAmount = suppliersVars[`${prefix}minChargeAmount` as keyof SuppliersVars] as number || 0;
  const daySeasonMultiplier = suppliersVars[`${prefix}daySeasonMultiplier` as keyof SuppliersVars] as number || 1.0;
  const tiers = suppliersVars[`${prefix}tiers` as keyof SuppliersVars] as PricingTier[] || [];
  const addonsPerGuest = suppliersVars[`${prefix}addonsPerGuest` as keyof SuppliersVars] as AddonItem[] || [];
  const addonsPerEvent = suppliersVars[`${prefix}addonsPerEvent` as keyof SuppliersVars] as AddonItem[] || [];

  // Compute guest counts
  const guestsMin = budgetVars.guestsMin > 0 ? budgetVars.guestsMin : rsvpVars.acceptedCount;
  const guestsLikely = Math.round(
    rsvpVars.acceptedCount + (maybePct * rsvpVars.maybeCount) + (noReplyPct * rsvpVars.noReplyCount)
  );
  const guestsMax = budgetVars.guestsMax > 0 ? budgetVars.guestsMax : (rsvpVars.invitedCount - rsvpVars.declinedCount);

  // Choose guest count based on scenario
  let guestsChosen = guestsLikely;
  if (scenarioMode === "min") guestsChosen = guestsMin;
  else if (scenarioMode === "max") guestsChosen = guestsMax;
  
  // Apply arrival factor
  guestsChosen = Math.round(guestsChosen * arrivalFactor);

  // Find applicable tier price
  let priceChosen = pricePerGuest;
  for (const tier of tiers) {
    if (guestsChosen >= tier.min && guestsChosen <= tier.max) {
      priceChosen = tier.pricePerGuest;
      break;
    }
  }

  // Calculate add-ons
  const addonsPerGuestTotal = addonsPerGuest
    .filter(addon => addon.enabled)
    .reduce((sum, addon) => sum + addon.amount, 0);
  
  const addonsPerEventTotal = addonsPerEvent
    .filter(addon => addon.enabled)
    .reduce((sum, addon) => sum + addon.amount, 0);

  // Calculate base per guest
  const basePerGuest = (priceChosen + addonsPerGuestTotal) * daySeasonMultiplier;

  // Calculate totals
  const subtotalGuests = guestsChosen * basePerGuest;
  const totalForecast = Math.round(subtotalGuests + addonsPerEventTotal);
  
  const totalFloor = Math.max(
    minChargeAmount,
    minChargeGuests > 0 ? minChargeGuests * basePerGuest : 0
  );
  
  // Calculate ceiling (max scenario)
  const guestsMaxScenario = Math.round(guestsMax * arrivalFactor);
  const subtotalMaxGuests = guestsMaxScenario * basePerGuest;
  const totalCeiling = Math.round(subtotalMaxGuests + addonsPerEventTotal);

  // Generate breakdown text
  const breakdownText = `${guestsChosen}×₪${Math.round(basePerGuest)} + אירוע ₪${addonsPerEventTotal} → ₪${totalForecast}`;

  // Compute normalized total for budget integration
  const status = suppliersVars[`${prefix}status` as keyof SuppliersVars] as string;
  const totalNormalized = status === 'התחייב' ? totalForecast : 0;

  return {
    [`${prefix}guestsMin`]: guestsMin,
    [`${prefix}guestsLikely`]: guestsLikely,
    [`${prefix}guestsMax`]: guestsMax,
    [`${prefix}guestsChosen`]: guestsChosen,
    [`${prefix}totalFloor`]: totalFloor,
    [`${prefix}totalForecast`]: totalForecast,
    [`${prefix}totalCeiling`]: totalCeiling,
    [`${prefix}breakdownText`]: breakdownText,
    [`${prefix}totalNormalized`]: totalNormalized,
  };
};

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('auth');
  
  // Figma Variables - ALL EMPTY/ZERO BY DEFAULT
  const [appState, setAppState] = useState<AppState>({
    isAuthenticated: false,
    isViewOnly: false,
    hasEventDate: false,
    coupleName: ""
  });

  const [event, setEvent] = useState<Event>({
    eventName: "",
    eventNameEdited: false,
    eventDate: ""
  });

  const [countdown, setCountdown] = useState<Countdown>({
    daysLeft: 0
  });

  const [rsvpVars, setRsvpVars] = useState<RSVPVars>({
    invitedCount: 0,
    acceptedCount: 0,
    maybeCount: 0,
    noReplyCount: 0,
    declinedCount: 0
  });

  const [budgetVars, setBudgetVars] = useState<BudgetVars>({
    guestsMin: 0,
    guestsMax: 0,
    guestsExact: 0,
    giftAvg: 0,
    targetMode: "reset",
    ownContribution: 0,
    savePercent: 0,
    giftsMin: 0,
    giftsMax: 0,
    targetExact: 0,
    targetMin: 0,
    targetMax: 0,
    forecastTotal: 0
  });

  const [suppliersVars, setSuppliersVars] = useState<SuppliersVars>({
    committedCount: 0,
    // Vendor 1
    vendor1_visible: false,
    vendor1_name: "",
    vendor1_category: "",
    vendor1_status: "",
    vendor1_type: "",
    vendor1_email: "",
    vendor1_phone: "",
    vendor1_offerExpiry: "",
    vendor1_deposit: 0,
    vendor1_remaining: 0,
    vendor1_nextDue: "",
    vendor1_notes: "",
    vendor1_chargeMode: "",
    vendor1_pricePerGuest: 0,
    vendor1_minChargeGuests: 0,
    vendor1_minChargeAmount: 0,
    vendor1_daySeason: "ordinary",
    vendor1_daySeasonMultiplier: 1.0,
    vendor1_tiers: [],
    vendor1_addonsPerGuest: [],
    vendor1_addonsPerEvent: [],
    vendor1_childrenRules: { freeUnder: 0, percentUnder: 0, staffRate: 0 },
    vendor1_scenarioMode: "likely",
    vendor1_maybePct: 0.6,
    vendor1_noReplyPct: 0.3,
    vendor1_arrivalFactor: 1.0,
    vendor1_guestsMin: 0,
    vendor1_guestsLikely: 0,
    vendor1_guestsMax: 0,
    vendor1_guestsChosen: 0,
    vendor1_totalFloor: 0,
    vendor1_totalForecast: 0,
    vendor1_totalCeiling: 0,
    vendor1_breakdownText: "",
    vendor1_totalNormalized: 0,
    // Vendor 2
    vendor2_visible: false,
    vendor2_name: "",
    vendor2_category: "",
    vendor2_status: "",
    vendor2_type: "",
    vendor2_email: "",
    vendor2_phone: "",
    vendor2_offerExpiry: "",
    vendor2_deposit: 0,
    vendor2_remaining: 0,
    vendor2_nextDue: "",
    vendor2_notes: "",
    vendor2_chargeMode: "",
    vendor2_pricePerGuest: 0,
    vendor2_minChargeGuests: 0,
    vendor2_minChargeAmount: 0,
    vendor2_daySeason: "ordinary",
    vendor2_daySeasonMultiplier: 1.0,
    vendor2_tiers: [],
    vendor2_addonsPerGuest: [],
    vendor2_addonsPerEvent: [],
    vendor2_childrenRules: { freeUnder: 0, percentUnder: 0, staffRate: 0 },
    vendor2_scenarioMode: "likely",
    vendor2_maybePct: 0.6,
    vendor2_noReplyPct: 0.3,
    vendor2_arrivalFactor: 1.0,
    vendor2_guestsMin: 0,
    vendor2_guestsLikely: 0,
    vendor2_guestsMax: 0,
    vendor2_guestsChosen: 0,
    vendor2_totalFloor: 0,
    vendor2_totalForecast: 0,
    vendor2_totalCeiling: 0,
    vendor2_breakdownText: "",
    vendor2_totalNormalized: 0,
    // Vendor 3
    vendor3_visible: false,
    vendor3_name: "",
    vendor3_category: "",
    vendor3_status: "",
    vendor3_type: "",
    vendor3_email: "",
    vendor3_phone: "",
    vendor3_offerExpiry: "",
    vendor3_deposit: 0,
    vendor3_remaining: 0,
    vendor3_nextDue: "",
    vendor3_notes: "",
    vendor3_chargeMode: "",
    vendor3_pricePerGuest: 0,
    vendor3_minChargeGuests: 0,
    vendor3_minChargeAmount: 0,
    vendor3_daySeason: "ordinary",
    vendor3_daySeasonMultiplier: 1.0,
    vendor3_tiers: [],
    vendor3_addonsPerGuest: [],
    vendor3_addonsPerEvent: [],
    vendor3_childrenRules: { freeUnder: 0, percentUnder: 0, staffRate: 0 },
    vendor3_scenarioMode: "likely",
    vendor3_maybePct: 0.6,
    vendor3_noReplyPct: 0.3,
    vendor3_arrivalFactor: 1.0,
    vendor3_guestsMin: 0,
    vendor3_guestsLikely: 0,
    vendor3_guestsMax: 0,
    vendor3_guestsChosen: 0,
    vendor3_totalFloor: 0,
    vendor3_totalForecast: 0,
    vendor3_totalCeiling: 0,
    vendor3_breakdownText: "",
    vendor3_totalNormalized: 0,
    // Vendor 4
    vendor4_visible: false,
    vendor4_name: "",
    vendor4_category: "",
    vendor4_status: "",
    vendor4_type: "",
    vendor4_email: "",
    vendor4_phone: "",
    vendor4_offerExpiry: "",
    vendor4_deposit: 0,
    vendor4_remaining: 0,
    vendor4_nextDue: "",
    vendor4_notes: "",
    vendor4_chargeMode: "",
    vendor4_pricePerGuest: 0,
    vendor4_minChargeGuests: 0,
    vendor4_minChargeAmount: 0,
    vendor4_daySeason: "ordinary",
    vendor4_daySeasonMultiplier: 1.0,
    vendor4_tiers: [],
    vendor4_addonsPerGuest: [],
    vendor4_addonsPerEvent: [],
    vendor4_childrenRules: { freeUnder: 0, percentUnder: 0, staffRate: 0 },
    vendor4_scenarioMode: "likely",
    vendor4_maybePct: 0.6,
    vendor4_noReplyPct: 0.3,
    vendor4_arrivalFactor: 1.0,
    vendor4_guestsMin: 0,
    vendor4_guestsLikely: 0,
    vendor4_guestsMax: 0,
    vendor4_guestsChosen: 0,
    vendor4_totalFloor: 0,
    vendor4_totalForecast: 0,
    vendor4_totalCeiling: 0,
    vendor4_breakdownText: "",
    vendor4_totalNormalized: 0,
    // Vendor 5
    vendor5_visible: false,
    vendor5_name: "",
    vendor5_category: "",
    vendor5_status: "",
    vendor5_type: "",
    vendor5_email: "",
    vendor5_phone: "",
    vendor5_offerExpiry: "",
    vendor5_deposit: 0,
    vendor5_remaining: 0,
    vendor5_nextDue: "",
    vendor5_notes: "",
    vendor5_chargeMode: "",
    vendor5_pricePerGuest: 0,
    vendor5_minChargeGuests: 0,
    vendor5_minChargeAmount: 0,
    vendor5_daySeason: "ordinary",
    vendor5_daySeasonMultiplier: 1.0,
    vendor5_tiers: [],
    vendor5_addonsPerGuest: [],
    vendor5_addonsPerEvent: [],
    vendor5_childrenRules: { freeUnder: 0, percentUnder: 0, staffRate: 0 },
    vendor5_scenarioMode: "likely",
    vendor5_maybePct: 0.6,
    vendor5_noReplyPct: 0.3,
    vendor5_arrivalFactor: 1.0,
    vendor5_guestsMin: 0,
    vendor5_guestsLikely: 0,
    vendor5_guestsMax: 0,
    vendor5_guestsChosen: 0,
    vendor5_totalFloor: 0,
    vendor5_totalForecast: 0,
    vendor5_totalCeiling: 0,
    vendor5_breakdownText: "",
    vendor5_totalNormalized: 0,
    // Vendor 6
    vendor6_visible: false,
    vendor6_name: "",
    vendor6_category: "",
    vendor6_status: "",
    vendor6_type: "",
    vendor6_email: "",
    vendor6_phone: "",
    vendor6_offerExpiry: "",
    vendor6_deposit: 0,
    vendor6_remaining: 0,
    vendor6_nextDue: "",
    vendor6_notes: "",
    vendor6_chargeMode: "",
    vendor6_pricePerGuest: 0,
    vendor6_minChargeGuests: 0,
    vendor6_minChargeAmount: 0,
    vendor6_daySeason: "ordinary",
    vendor6_daySeasonMultiplier: 1.0,
    vendor6_tiers: [],
    vendor6_addonsPerGuest: [],
    vendor6_addonsPerEvent: [],
    vendor6_childrenRules: { freeUnder: 0, percentUnder: 0, staffRate: 0 },
    vendor6_scenarioMode: "likely",
    vendor6_maybePct: 0.6,
    vendor6_noReplyPct: 0.3,
    vendor6_arrivalFactor: 1.0,
    vendor6_guestsMin: 0,
    vendor6_guestsLikely: 0,
    vendor6_guestsMax: 0,
    vendor6_guestsChosen: 0,
    vendor6_totalFloor: 0,
    vendor6_totalForecast: 0,
    vendor6_totalCeiling: 0,
    vendor6_breakdownText: "",
    vendor6_totalNormalized: 0,
    // Vendor 7
    vendor7_visible: false,
    vendor7_name: "",
    vendor7_category: "",
    vendor7_status: "",
    vendor7_type: "",
    vendor7_email: "",
    vendor7_phone: "",
    vendor7_offerExpiry: "",
    vendor7_deposit: 0,
    vendor7_remaining: 0,
    vendor7_nextDue: "",
    vendor7_notes: "",
    vendor7_chargeMode: "",
    vendor7_pricePerGuest: 0,
    vendor7_minChargeGuests: 0,
    vendor7_minChargeAmount: 0,
    vendor7_daySeason: "ordinary",
    vendor7_daySeasonMultiplier: 1.0,
    vendor7_tiers: [],
    vendor7_addonsPerGuest: [],
    vendor7_addonsPerEvent: [],
    vendor7_childrenRules: { freeUnder: 0, percentUnder: 0, staffRate: 0 },
    vendor7_scenarioMode: "likely",
    vendor7_maybePct: 0.6,
    vendor7_noReplyPct: 0.3,
    vendor7_arrivalFactor: 1.0,
    vendor7_guestsMin: 0,
    vendor7_guestsLikely: 0,
    vendor7_guestsMax: 0,
    vendor7_guestsChosen: 0,
    vendor7_totalFloor: 0,
    vendor7_totalForecast: 0,
    vendor7_totalCeiling: 0,
    vendor7_breakdownText: "",
    vendor7_totalNormalized: 0,
    // Vendor 8
    vendor8_visible: false,
    vendor8_name: "",
    vendor8_category: "",
    vendor8_status: "",
    vendor8_type: "",
    vendor8_email: "",
    vendor8_phone: "",
    vendor8_offerExpiry: "",
    vendor8_deposit: 0,
    vendor8_remaining: 0,
    vendor8_nextDue: "",
    vendor8_notes: "",
    vendor8_chargeMode: "",
    vendor8_pricePerGuest: 0,
    vendor8_minChargeGuests: 0,
    vendor8_minChargeAmount: 0,
    vendor8_daySeason: "ordinary",
    vendor8_daySeasonMultiplier: 1.0,
    vendor8_tiers: [],
    vendor8_addonsPerGuest: [],
    vendor8_addonsPerEvent: [],
    vendor8_childrenRules: { freeUnder: 0, percentUnder: 0, staffRate: 0 },
    vendor8_scenarioMode: "likely",
    vendor8_maybePct: 0.6,
    vendor8_noReplyPct: 0.3,
    vendor8_arrivalFactor: 1.0,
    vendor8_guestsMin: 0,
    vendor8_guestsLikely: 0,
    vendor8_guestsMax: 0,
    vendor8_guestsChosen: 0,
    vendor8_totalFloor: 0,
    vendor8_totalForecast: 0,
    vendor8_totalCeiling: 0,
    vendor8_breakdownText: "",
    vendor8_totalNormalized: 0
  });

  const [dashVars, setDashVars] = useState<DashVars>(() => {
    try {
      const saved = localStorage.getItem('dashVars');
      return saved
        ? JSON.parse(saved)
        : { tasksTodayCount: 0, guestsCount: 0 };
    } catch {
      return { tasksTodayCount: 0, guestsCount: 0 };
    }
  });

  // Recompute countdown when dashboard loads and we have a date
  useEffect(() => {
    if (currentScreen === 'dashboard' && appState.hasEventDate && event.eventDate) {
      const eventDateObj = new Date(event.eventDate);
      const today = new Date();
      const daysLeft = dateDiffInDays(today, eventDateObj);
      
      setCountdown(prev => ({
        ...prev,
        daysLeft: daysLeft
      }));
    }
  }, [currentScreen, appState.hasEventDate, event.eventDate]);

  // Calculate forecast total from committed vendors only
  useEffect(() => {
    let forecastTotal = 0;
    
    for (let i = 1; i <= 8; i++) {
      const visible = suppliersVars[`vendor${i}_visible` as keyof SuppliersVars];
      const status = suppliersVars[`vendor${i}_status` as keyof SuppliersVars];
      const totalNormalized = suppliersVars[`vendor${i}_totalNormalized` as keyof SuppliersVars];
      
      if (visible && status === 'התחייב') {
        forecastTotal += (totalNormalized as number) || 0;
      }
    }
    
    setBudgetVars(prev => ({
      ...prev,
      forecastTotal: forecastTotal
    }));
  }, [suppliersVars]);

  // Calculate vendor pricing computations
  useEffect(() => {
    const updates: Partial<SuppliersVars> = {};
    
    for (let i = 1; i <= 8; i++) {
      const computed = computeVendorPricing(i, suppliersVars, rsvpVars, budgetVars);
      Object.assign(updates, computed);
    }
    
    if (Object.keys(updates).length > 0) {
      setSuppliersVars(prev => ({ ...prev, ...updates }));
    }
  }, [suppliersVars.vendor1_visible, suppliersVars.vendor2_visible, suppliersVars.vendor3_visible, suppliersVars.vendor4_visible, suppliersVars.vendor5_visible, suppliersVars.vendor6_visible, suppliersVars.vendor7_visible, suppliersVars.vendor8_visible, rsvpVars, budgetVars.guestsMin, budgetVars.guestsMax]);

  // Save dashVars to localStorage
  useEffect(() => {
    try { 
      localStorage.setItem('dashVars', JSON.stringify(dashVars)); 
    } catch {}
  }, [dashVars]);

  // NEVER reset variables on navigation - they persist
  const handleAuthSuccess = (name?: string) => {
    setAppState(prev => ({
      ...prev,
      isAuthenticated: true,
      isViewOnly: false,
      coupleName: name || ""
    }));
    setCurrentScreen('dashboard');
  };

  const handleDemoMode = () => {
    setAppState(prev => ({
      ...prev,
      isAuthenticated: false,
      isViewOnly: true,
      coupleName: ""
    }));
    setCurrentScreen('dashboard');
  };

  const handleNavigate = (screen: string) => {
    setCurrentScreen(screen as Screen);
  };

  const handleBudgetWizardComplete = (data: any) => {
    // Update budget variables from wizard
    setBudgetVars(prev => ({
      ...prev,
      ...data
    }));
    setCurrentScreen('budget-overview');
  };

  const handleBudgetWizardCancel = () => {
    setCurrentScreen('dashboard');
  };

  const handleEventDateSet = (eventData: {date: Date, eventName: string, daysLeft: number}) => {
    setAppState(prev => ({
      ...prev,
      hasEventDate: true
    }));
    setEvent(prev => ({
      ...prev,
      eventName: eventData.eventName,
      eventNameEdited: true,
      eventDate: eventData.date.toISOString().split('T')[0]
    }));
    setCountdown(prev => ({
      ...prev,
      daysLeft: eventData.daysLeft
    }));
    setCurrentScreen('dashboard');
  };

  const handleEventDateSkip = () => {
    setCurrentScreen('dashboard');
  };

  // Auth screen - no layout
  if (currentScreen === 'auth') {
    return (
      <>
        <Auth 
          onAuthSuccess={handleAuthSuccess}
          onDemoMode={handleDemoMode}
        />
        <Toaster />
      </>
    );
  }

  // Event Date Selector - no layout
  if (currentScreen === 'event-date') {
    return (
      <>
        <EventDateSelector
          appState={appState}
          setAppState={setAppState}
          event={event}
          setEvent={setEvent}
          countdown={countdown}
          setCountdown={setCountdown}
          onDateSet={handleEventDateSet}
          onSkip={handleEventDateSkip}
        />
        <Toaster />
      </>
    );
  }

  // New Budget Wizard - no layout
  if (currentScreen === 'new-budget-wizard') {
    return (
      <>
        <NewBudgetWizard
          onComplete={handleBudgetWizardComplete}
          onCancel={handleBudgetWizardCancel}
          budgetVars={budgetVars}
          setBudgetVars={setBudgetVars}
          suppliersVars={suppliersVars}
          onNavigate={handleNavigate}
        />
        <Toaster />
      </>
    );
  }

  // Budget Overview - no layout  
  if (currentScreen === 'budget-overview') {
    return (
      <>
        <BudgetOverview
          budgetVars={budgetVars}
          suppliersVars={suppliersVars}
          onEdit={() => setCurrentScreen('new-budget-wizard')}
          onBack={() => setCurrentScreen('dashboard')}
        />
        <Toaster />
      </>
    );
  }

  // Main app screens
  const renderScreen = () => {
    switch (currentScreen) {
      case 'dashboard':
        return (
          <Dashboard 
            appState={appState}
            event={event}
            countdown={countdown}
            budgetVars={budgetVars}
            dashVars={dashVars}
            suppliersVars={suppliersVars}
            onNavigate={handleNavigate}
            setDashVars={setDashVars}
          />
        );
      case 'budget':
        // Check if budget has any data
        const hasBudgetData = budgetVars.targetExact > 0 || budgetVars.targetMin > 0;
        return hasBudgetData ? <Budget budgetVars={budgetVars} /> : (
          <div className="p-8 text-center space-y-4" dir="rtl">
            <h2>תקציב לא הוגדר</h2>
            <p className="text-muted-foreground">עליכם להגדיר תקציב תחילה</p>
            <button 
              onClick={() => setCurrentScreen('new-budget-wizard')}
              className="text-primary hover:underline focus:ring-2 focus:ring-primary rounded"
            >
              הגדירו תקציב עכשיו
            </button>
          </div>
        );
      case 'guests':
        return <Guests 
          dashVars={dashVars} 
          setDashVars={setDashVars}
          rsvpVars={rsvpVars}
          setRsvpVars={setRsvpVars}
        />;
      case 'tasks':
        return <Tasks dashVars={dashVars} setDashVars={setDashVars} />;
      case 'suppliers':
        return (
          <Suppliers 
            budgetVars={budgetVars}
            rsvpVars={rsvpVars}
            setRsvpVars={setRsvpVars}
            suppliersVars={suppliersVars}
            setSuppliersVars={setSuppliersVars}
            onNavigate={handleNavigate}
          />
        );
      case 'settings':
        return (
          <div className="p-8 text-center space-y-4" dir="rtl">
            <h2>הגדרות</h2>
            <p className="text-muted-foreground">מודול בקרוב...</p>
            <div className="text-sm text-muted-foreground">
              יכלול: העדפות אישיות, התראות, גיבויים
            </div>
          </div>
        );
      default:
        return <div>Screen not found</div>;
    }
  };

  return (
    <>
      <Layout 
        currentScreen={currentScreen} 
        onNavigate={handleNavigate}
      >
        {renderScreen()}
      </Layout>
      <Toaster />
    </>
  );
}