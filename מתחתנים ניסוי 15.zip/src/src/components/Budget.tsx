import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { formatCurrency } from '@/lib/utils';

interface BudgetProps {
  budgetVars: any;
}

export function Budget({ budgetVars }: BudgetProps) {
  return (
    <div className="space-y-6" dir="rtl">
      <div className="text-center">
        <h1 className="text-2xl font-semibold">תקציב החתונה</h1>
        <p className="text-muted-foreground">סקירה מפורטת של התקציב שלכם</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>יעד התקציב</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-semibold">
              {budgetVars.targetExact > 0 
                ? formatCurrency(budgetVars.targetExact)
                : budgetVars.targetMin > 0 
                  ? `${formatCurrency(budgetVars.targetMin)} - ${formatCurrency(budgetVars.targetMax)}`
                  : "—"
              }
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>תחזית נוכחית</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-semibold">
              {formatCurrency(budgetVars.forecastTotal)}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>יעד אורחים</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-semibold">
              {budgetVars.guestsExact > 0 
                ? budgetVars.guestsExact
                : budgetVars.guestsMin > 0 
                  ? `${budgetVars.guestsMin} - ${budgetVars.guestsMax}`
                  : "—"
              }
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>פירוט התקציב</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center text-muted-foreground py-8">
            פירוט מפורט יופיע כאן לאחר הוספת ספקים
          </div>
        </CardContent>
      </Card>
    </div>
  );
}