import React from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Heart } from 'lucide-react';

interface AuthProps {
  onAuthSuccess: (name?: string) => void;
  onDemoMode: () => void;
}

export function Auth({ onAuthSuccess, onDemoMode }: AuthProps) {
  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4" dir="rtl">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center space-y-4">
          <div className="flex justify-center">
            <Heart className="h-12 w-12 text-primary" />
          </div>
          <CardTitle className="text-xl font-semibold">
            ברוכים הבאים לתכנון החתונה
          </CardTitle>
          <p className="text-sm text-muted-foreground">
            אפליקציה חכמה לתכנון החתונה המושלמת
          </p>
        </CardHeader>
        <CardContent className="space-y-4">
          <Button 
            onClick={() => onAuthSuccess()} 
            className="w-full h-12 text-base font-medium"
            size="lg"
          >
            התחילו לתכנן את החתונה
          </Button>
          <Button 
            variant="outline" 
            onClick={onDemoMode} 
            className="w-full h-10 text-sm"
          >
            צפו בדמו
          </Button>
          <p className="text-xs text-muted-foreground text-center mt-4">
            תכנון חתונות עם עיצוב מינימלי וחכם
          </p>
        </CardContent>
      </Card>
    </div>
  );
}