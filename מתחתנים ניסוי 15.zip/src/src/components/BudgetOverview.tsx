import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';

interface BudgetOverviewProps {
  budgetVars: any;
  suppliersVars: any;
  onEdit: () => void;
  onBack: () => void;
}

export function BudgetOverview({ budgetVars, suppliersVars, onEdit, onBack }: BudgetOverviewProps) {
  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4" dir="rtl">
      <Card className="w-full max-w-2xl">
        <CardHeader>
          <CardTitle>סקירת התקציב</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="text-center py-8">
            <p className="text-muted-foreground">
              סקירת תקציב מפורטת בפיתוח
            </p>
            <p className="text-sm text-muted-foreground mt-2">
              יכלול: סיכום KPIs, פירוט קטגוריות, מעקב אחר יעדים
            </p>
          </div>
          
          <div className="flex gap-4">
            <Button onClick={onBack} variant="outline" className="flex-1">
              חזרה לדשבורד
            </Button>
            <Button onClick={onEdit} className="flex-1">
              עריכת תקציב
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}