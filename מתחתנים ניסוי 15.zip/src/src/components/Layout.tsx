import React from 'react';
import { Home, Calculator, Users, UserCheck, CheckSquare, Settings } from 'lucide-react';

interface LayoutProps {
  currentScreen: string;
  onNavigate: (screen: string) => void;
  children: React.ReactNode;
}

const navigationItems = [
  { id: 'dashboard', label: 'דשבורד', icon: Home },
  { id: 'budget', label: 'תקציב', icon: Calculator },
  { id: 'suppliers', label: 'ספקים', icon: Users },
  { id: 'guests', label: 'מוזמנים', icon: UserCheck },
  { id: 'tasks', label: 'משימות', icon: CheckSquare },
  { id: 'settings', label: 'הגדרות', icon: Settings },
];

export function Layout({ currentScreen, onNavigate, children }: LayoutProps) {
  return (
    <div className="min-h-screen bg-background" dir="rtl">
      {/* Top Navigation */}
      <nav className="border-b border-border bg-card">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex space-x-8 space-x-reverse">
              {navigationItems.map((item) => {
                const Icon = item.icon;
                const isActive = currentScreen === item.id;
                
                return (
                  <button
                    key={item.id}
                    onClick={() => onNavigate(item.id)}
                    className={`flex items-center gap-2 px-3 py-2 text-sm font-medium transition-colors focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 rounded-md ${
                      isActive
                        ? 'text-primary border-b-2 border-primary bg-secondary/50'
                        : 'text-muted-foreground hover:text-foreground hover:bg-secondary/30'
                    }`}
                  >
                    <Icon className="h-4 w-4" />
                    {item.label}
                  </button>
                );
              })}
            </div>
            
            <div className="text-sm font-medium text-foreground">
              תכנון חתונות
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
        {children}
      </main>
    </div>
  );
}