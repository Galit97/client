import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';

interface SuppliersProps {
  budgetVars: any;
  rsvpVars: any;
  setRsvpVars: (vars: any) => void;
  suppliersVars: any;
  setSuppliersVars: (vars: any) => void;
  onNavigate: (screen: string) => void;
}

export function Suppliers({ 
  budgetVars, 
  rsvpVars, 
  setRsvpVars, 
  suppliersVars, 
  setSuppliersVars, 
  onNavigate 
}: SuppliersProps) {
  return (
    <div className="space-y-6" dir="rtl">
      <div className="text-center">
        <h1 className="text-2xl font-semibold">ניהול ספקים</h1>
        <p className="text-muted-foreground">נהלו את כל ספקי החתונה במקום אחד</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>סטטיסטיקות ספקים</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center">
            <div className="text-3xl font-semibold">{suppliersVars.committedCount || "—"}</div>
            <div className="text-muted-foreground">ספקים התחייבו</div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="pt-6">
          <div className="text-center text-muted-foreground py-8">
            מודול ניהול ספקים מתקדם בפיתוח
            <br />
            יכלול: הצעות מחיר, השוואות, תמחור דינמי, RSVP integration
          </div>
        </CardContent>
      </Card>
    </div>
  );
}