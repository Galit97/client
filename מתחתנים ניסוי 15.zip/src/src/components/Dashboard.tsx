import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Calendar, Calculator, CheckSquare, Users, Heart } from 'lucide-react';
import { formatCurrency } from '@/lib/utils';

interface DashboardProps {
  appState: any;
  event: any;
  countdown: any;
  budgetVars: any;
  dashVars: any;
  suppliersVars: any;
  onNavigate: (screen: string) => void;
  setDashVars: (vars: any) => void;
}

export function Dashboard({ 
  appState, 
  event, 
  countdown, 
  budgetVars, 
  dashVars, 
  suppliersVars, 
  onNavigate, 
  setDashVars 
}: DashboardProps) {

  // Determine primary CTA based on state
  const getPrimaryCTA = () => {
    if (!appState.hasEventDate) {
      return {
        text: 'בחרו תאריך לחתונה',
        action: () => onNavigate('event-date'),
        description: 'התחילו עם קביעת תאריך החתונה'
      };
    }
    
    if (budgetVars.targetExact === 0 && budgetVars.targetMin === 0) {
      return {
        text: 'תכננו את התקציב',
        action: () => onNavigate('new-budget-wizard'),
        description: 'הגדירו תקציב חכם עבור החתונה'
      };
    }
    
    if (dashVars.tasksTodayCount > 0) {
      return {
        text: `בצעו ${dashVars.tasksTodayCount} משימות היום`,
        action: () => onNavigate('tasks'),
        description: 'יש לכם משימות ממתינות'
      };
    }
    
    return {
      text: 'נהלו ספקים',
      action: () => onNavigate('suppliers'),
      description: 'הוסיפו וארגנו את ספקי החתונה'
    };
  };

  const primaryCTA = getPrimaryCTA();

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-semibold text-foreground flex items-center justify-center gap-2">
          <Heart className="h-8 w-8 text-primary" />
          דשבורד תכנון החתונה
        </h1>
        <p className="text-muted-foreground">
          {appState.coupleName ? `שלום ${appState.coupleName}` : 'כל המידע שלכם במקום אחד'}
        </p>
      </div>

      {/* Event Date or Date Selection */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            תאריך החתונה
          </CardTitle>
        </CardHeader>
        <CardContent>
          {!appState.hasEventDate ? (
            <div className="text-center space-y-4">
              <p className="text-muted-foreground">עדיין לא הוגדר תאריך לחתונה</p>
              <Button onClick={() => onNavigate('event-date')} className="w-full">
                {primaryCTA.text}
              </Button>
              <button 
                onClick={() => {/* Skip for now */}} 
                className="text-sm text-muted-foreground hover:text-foreground"
              >
                דלגו כרגע
              </button>
            </div>
          ) : (
            <div className="text-center space-y-2">
              <div className="text-2xl font-semibold">
                {countdown.daysLeft > 0 ? `${countdown.daysLeft} ימים` : 'היום!'}
              </div>
              <div className="text-sm text-muted-foreground">
                {event.eventDate ? new Date(event.eventDate).toLocaleDateString('he-IL') : 'תאריך לא זמין'}
              </div>
              {event.eventName && (
                <div className="text-sm text-muted-foreground">
                  {event.eventName}
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Grid of Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Budget Card */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calculator className="h-5 w-5" />
              תקציב
            </CardTitle>
          </CardHeader>
          <CardContent>
            {budgetVars.targetExact === 0 && budgetVars.targetMin === 0 ? (
              <div className="space-y-3">
                <p className="text-muted-foreground">עדיין אין נתוני תקציב</p>
                <Button 
                  variant="outline" 
                  onClick={() => onNavigate('new-budget-wizard')}
                  className="w-full"
                >
                  הגדירו תקציב
                </Button>
              </div>
            ) : (
              <div className="space-y-2">
                <div className="text-lg font-semibold">
                  {budgetVars.targetExact > 0 
                    ? formatCurrency(budgetVars.targetExact)
                    : `${formatCurrency(budgetVars.targetMin)} - ${formatCurrency(budgetVars.targetMax)}`
                  }
                </div>
                <div className="text-sm text-muted-foreground">
                  יעד התקציב
                </div>
                {budgetVars.forecastTotal > 0 && (
                  <div className="text-sm">
                    תחזית: {formatCurrency(budgetVars.forecastTotal)}
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Tasks Card */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CheckSquare className="h-5 w-5" />
              משימות היום
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="text-lg font-semibold">
                {dashVars.tasksTodayCount || "—"}
              </div>
              <div className="text-sm text-muted-foreground">
                {dashVars.tasksTodayCount === 0 ? 'אין משימות להיום' : 'משימות ממתינות'}
              </div>
              <Button 
                variant="outline" 
                onClick={() => onNavigate('tasks')}
                className="w-full"
              >
                נהלו משימות
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Guests Card */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              מוזמנים
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="text-lg font-semibold">
                {dashVars.guestsCount || "—"}
              </div>
              <div className="text-sm text-muted-foreground">
                סה"כ מוזמנים
              </div>
              <Button 
                variant="outline" 
                onClick={() => onNavigate('guests')}
                className="w-full"
              >
                נהלו אורחים
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Suppliers Summary */}
      {suppliersVars.committedCount === 0 ? (
        <Card>
          <CardContent className="pt-6">
            <div className="text-center space-y-4">
              <h3 className="text-lg font-semibold">עדיין אין ספקים בתכנון</h3>
              <p className="text-muted-foreground">
                הוסיפו ספקים כדי להתחיל לעקוב אחר התקציב והתשלומים
              </p>
              <Button 
                variant="outline" 
                onClick={() => onNavigate('suppliers')}
              >
                פתחו עמוד ספקים
              </Button>
            </div>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardHeader>
            <CardTitle>ספקים</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center">
              <div className="text-lg font-semibold">{suppliersVars.committedCount}</div>
              <div className="text-sm text-muted-foreground">ספקים התחייבו</div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}