import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Calendar } from 'lucide-react';

interface EventDateSelectorProps {
  appState: any;
  setAppState: (state: any) => void;
  event: any;
  setEvent: (event: any) => void;
  countdown: any;
  setCountdown: (countdown: any) => void;
  onDateSet: (eventData: {date: Date, eventName: string, daysLeft: number}) => void;
  onSkip: () => void;
}

export function EventDateSelector({ 
  appState, 
  setAppState, 
  event, 
  setEvent, 
  countdown, 
  setCountdown, 
  onDateSet, 
  onSkip 
}: EventDateSelectorProps) {
  const [selectedDate, setSelectedDate] = useState('');
  const [eventName, setEventName] = useState('');

  const handleSubmit = () => {
    if (selectedDate) {
      const date = new Date(selectedDate);
      const today = new Date();
      const daysLeft = Math.ceil((date.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
      
      onDateSet({
        date,
        eventName: eventName || 'החתונה שלנו',
        daysLeft
      });
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4" dir="rtl">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <Calendar className="h-12 w-12 text-primary mx-auto mb-4" />
          <CardTitle>בואו נקבע תאריך</CardTitle>
          <p className="text-muted-foreground">
            מתי החתונה שלכם?
          </p>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">תאריך החתונה</label>
            <Input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="text-right"
              dir="rtl"
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">שם האירוע (אופציונלי)</label>
            <Input
              type="text"
              value={eventName}
              onChange={(e) => setEventName(e.target.value)}
              placeholder="החתונה שלנו"
              className="text-right"
              dir="rtl"
            />
          </div>

          <div className="space-y-2 pt-4">
            <Button 
              onClick={handleSubmit} 
              disabled={!selectedDate}
              className="w-full"
            >
              שמירת התאריך
            </Button>
            <Button 
              variant="outline" 
              onClick={onSkip}
              className="w-full"
            >
              דלגו כרגע
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}