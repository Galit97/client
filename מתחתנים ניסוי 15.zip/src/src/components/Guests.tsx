import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';

interface GuestsProps {
  dashVars: any;
  setDashVars: (vars: any) => void;
  rsvpVars: any;
  setRsvpVars: (vars: any) => void;
}

export function Guests({ dashVars, setDashVars, rsvpVars, setRsvpVars }: GuestsProps) {
  return (
    <div className="space-y-6" dir="rtl">
      <div className="text-center">
        <h1 className="text-2xl font-semibold">ניהול אורחים</h1>
        <p className="text-muted-foreground">נהלו את רשימת המוזמנים לחתונה</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>סטטיסטיקות RSVP</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4 text-center">
            <div>
              <div className="text-2xl font-semibold">{rsvpVars.invitedCount || "—"}</div>
              <div className="text-sm text-muted-foreground">הוזמנו</div>
            </div>
            <div>
              <div className="text-2xl font-semibold">{rsvpVars.acceptedCount || "—"}</div>
              <div className="text-sm text-muted-foreground">מאשרים</div>
            </div>
            <div>
              <div className="text-2xl font-semibold">{rsvpVars.maybeCount || "—"}</div>
              <div className="text-sm text-muted-foreground">אולי</div>
            </div>
            <div>
              <div className="text-2xl font-semibold">{rsvpVars.noReplyCount || "—"}</div>
              <div className="text-sm text-muted-foreground">לא ענו</div>
            </div>
            <div>
              <div className="text-2xl font-semibold">{rsvpVars.declinedCount || "—"}</div>
              <div className="text-sm text-muted-foreground">מסרבים</div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="pt-6">
          <div className="text-center text-muted-foreground py-8">
            מודול ניהול אורחים בפיתוח
            <br />
            יכלול: רשימת אורחים, RSVP, הזמנות דיגיטליות
          </div>
        </CardContent>
      </Card>
    </div>
  );
}