import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';

interface TasksProps {
  dashVars: any;
  setDashVars: (vars: any) => void;
}

export function Tasks({ dashVars, setDashVars }: TasksProps) {
  return (
    <div className="space-y-6" dir="rtl">
      <div className="text-center">
        <h1 className="text-2xl font-semibold">ניהול משימות</h1>
        <p className="text-muted-foreground">עקבו אחר כל המשימות לחתונה</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>משימות היום</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center">
            <div className="text-3xl font-semibold">{dashVars.tasksTodayCount || "—"}</div>
            <div className="text-muted-foreground">
              {dashVars.tasksTodayCount === 0 ? 'אין משימות להיום' : 'משימות ממתינות'}
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="pt-6">
          <div className="text-center text-muted-foreground py-8">
            מודול ניהול משימות בפיתוח
            <br />
            יכלול: רשימת משימות, תאריכי יעד, התראות, קטגוריות
          </div>
        </CardContent>
      </Card>
    </div>
  );
}