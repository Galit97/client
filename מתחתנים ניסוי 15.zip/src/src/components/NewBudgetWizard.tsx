import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';

interface NewBudgetWizardProps {
  onComplete: (data: any) => void;
  onCancel: () => void;
  budgetVars: any;
  setBudgetVars: (vars: any) => void;
  suppliersVars: any;
  onNavigate: (screen: string) => void;
}

export function NewBudgetWizard({ 
  onComplete, 
  onCancel, 
  budgetVars, 
  setBudgetVars, 
  suppliersVars, 
  onNavigate 
}: NewBudgetWizardProps) {
  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4" dir="rtl">
      <Card className="w-full max-w-2xl">
        <CardHeader>
          <CardTitle>אשף תכנון התקציב</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="text-center py-8">
            <p className="text-muted-foreground">
              אשף תכנון התקציב המתקדם בפיתוח
            </p>
            <p className="text-sm text-muted-foreground mt-2">
              יכלול: הגדרת טווח אורחים, יעדי תקציב, אינטגרציה עם ספקים
            </p>
          </div>
          
          <div className="flex gap-4">
            <Button onClick={onCancel} variant="outline" className="flex-1">
              ביטול
            </Button>
            <Button onClick={() => onComplete({})} className="flex-1">
              שמירה זמנית
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}