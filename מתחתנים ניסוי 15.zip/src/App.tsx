import { useState, useEffect, useMemo } from "react";
import { Layout } from "./components/Layout";
import { Auth } from "./components/Auth";
import { Dashboard } from "./components/Dashboard";
import { Budget } from "./components/Budget";
import { NewBudgetWizard } from "./components/NewBudgetWizard";
import { BudgetOverview } from "./components/BudgetOverview";
import { EventDateSelector } from "./components/EventDateSelector";
import { Suppliers } from "./components/Suppliers";
import { Guests } from "./components/Guests";
import { Tasks } from "./components/Tasks";
import { MembersPermissionsSettings } from "./components/sharing/MembersPermissionsSettings";
import { JoinLanding } from "./components/sharing/JoinLanding";
import { TopBanner } from "./components/notifications/TopBanner";
import { ToastContainer } from "./components/notifications/ToastContainer";
import { Toaster } from "./components/ui/sonner";
import { Button } from "./components/ui/button";
import { BackButton } from "./components/ui/back-button";

type Screen =
  | "auth"
  | "dashboard"
  | "budget"
  | "new-budget-wizard"
  | "budget-overview"
  | "event-date"
  | "guests"
  | "tasks"
  | "suppliers"
  | "add-supplier"
  | "supplier-commitment"
  | "settings"
  | "members-permissions"
  | "join-landing";

// Figma Variables Collections - ALL EMPTY BY DEFAULT
interface AppState {
  isAuthenticated: boolean;
  isViewOnly: boolean;
  hasEventDate: boolean;
  coupleName: string;
}

interface Event {
  eventName: string;
  eventNameEdited: boolean;
  eventDate: string;
}

interface Countdown {
  daysLeft: number;
}

interface RSVPVars {
  invitedCount: number;
  acceptedCount: number;
  maybeCount: number;
  noReplyCount: number;
  declinedCount: number;
}

interface BudgetVars {
  guestsMin: number;
  guestsMax: number;
  guestsExact: number;
  giftAvg: number;
  targetMode: string; // "reset" | "add" | "save"
  ownContribution: number;
  savePercent: number;
  giftsMin: number;
  giftsMax: number;
  targetExact: number;
  targetMin: number;
  targetMax: number;
  forecastTotal: number;
}

interface PricingTier {
  min: number;
  max: number;
  pricePerGuest: number;
}

interface AddonItem {
  label: string;
  amount: number;
  enabled: boolean;
}

interface ChildrenRules {
  freeUnder: number;
  percentUnder: number;
  staffRate: number;
}

interface SuppliersVars {
  committedCount: number;
  // Vendor 1
  vendor1_visible: boolean;
  vendor1_name: string;
  vendor1_category: string;
  vendor1_status: string; // "" | "פתוח" | "הצעה" | "התחייב"
  vendor1_type: string; // "" | "venue" | "catering" | "total" | "perGuest"
  vendor1_email: string;
  vendor1_phone: string;
  vendor1_offerExpiry: string;
  vendor1_deposit: number;
  vendor1_remaining: number;
  vendor1_nextDue: string;
  vendor1_notes: string;
  vendor1_finalAmount: number; // New field for commitment
  // BASE PRICING
  vendor1_chargeMode: string; // "" | "perGuest" | "packagePerGuest" | "packageOnly"
  vendor1_pricePerGuest: number;
  vendor1_minChargeGuests: number;
  vendor1_minChargeAmount: number;
  vendor1_daySeason: string; // " mainstream" | "weekend" | "peak season"
  vendor1_daySeasonMultiplier: number;
  // ADVANCED TIERS & ADD-ONS
  vendor1_tiers: PricingTier[];
  vendor1_addonsPerGuest: AddonItem[];
  vendor1_addonsPerEvent: AddonItem[];
  vendor1_childrenRules: ChildrenRules;
  // LIVE SCENARIO
  vendor1_scenarioMode: string; // "min" | "likely" | "max"
  vendor1_maybePct: number;
  vendor1_noReplyPct: number;
  vendor1_arrivalFactor: number;
  // COMPUTED (read-only in UI)
  vendor1_guestsMin: number;
  vendor1_guestsLikely: number;
  vendor1_guestsMax: number;
  vendor1_guestsChosen: number;
  vendor1_totalFloor: number;
  vendor1_totalForecast: number;
  vendor1_totalCeiling: number;
  vendor1_breakdownText: string;
  vendor1_totalNormalized: number;
  // Vendor 2
  vendor2_visible: boolean;
  vendor2_name: string;
  vendor2_category: string;
  vendor2_status: string;
  vendor2_type: string;
  vendor2_email: string;
  vendor2_phone: string;
  vendor2_offerExpiry: string;
  vendor2_deposit: number;
  vendor2_remaining: number;
  vendor2_nextDue: string;
  vendor2_notes: string;
  vendor2_finalAmount: number;
  vendor2_chargeMode: string;
  vendor2_pricePerGuest: number;
  vendor2_minChargeGuests: number;
  vendor2_minChargeAmount: number;
  vendor2_daySeason: string;
  vendor2_daySeasonMultiplier: number;
  vendor2_tiers: PricingTier[];
  vendor2_addonsPerGuest: AddonItem[];
  vendor2_addonsPerEvent: AddonItem[];
  vendor2_childrenRules: ChildrenRules;
  vendor2_scenarioMode: string;
  vendor2_maybePct: number;
  vendor2_noReplyPct: number;
  vendor2_arrivalFactor: number;
  vendor2_guestsMin: number;
  vendor2_guestsLikely: number;
  vendor2_guestsMax: number;
  vendor2_guestsChosen: number;
  vendor2_totalFloor: number;
  vendor2_totalForecast: number;
  vendor2_totalCeiling: number;
  vendor2_breakdownText: string;
  vendor2_totalNormalized: number;
  // Vendor 3
  vendor3_visible: boolean;
  vendor3_name: string;
  vendor3_category: string;
  vendor3_status: string;
  vendor3_type: string;
  vendor3_email: string;
  vendor3_phone: string;
  vendor3_offerExpiry: string;
  vendor3_deposit: number;
  vendor3_remaining: number;
  vendor3_nextDue: string;
  vendor3_notes: string;
  vendor3_finalAmount: number;
  vendor3_chargeMode: string;
  vendor3_pricePerGuest: number;
  vendor3_minChargeGuests: number;
  vendor3_minChargeAmount: number;
  vendor3_daySeason: string;
  vendor3_daySeasonMultiplier: number;
  vendor3_tiers: PricingTier[];
  vendor3_addonsPerGuest: AddonItem[];
  vendor3_addonsPerEvent: AddonItem[];
  vendor3_childrenRules: ChildrenRules;
  vendor3_scenarioMode: string;
  vendor3_maybePct: number;
  vendor3_noReplyPct: number;
  vendor3_arrivalFactor: number;
  vendor3_guestsMin: number;
  vendor3_guestsLikely: number;
  vendor3_guestsMax: number;
  vendor3_guestsChosen: number;
  vendor3_totalFloor: number;
  vendor3_totalForecast: number;
  vendor3_totalCeiling: number;
  vendor3_breakdownText: string;
  vendor3_totalNormalized: number;
  // Vendor 4
  vendor4_visible: boolean;
  vendor4_name: string;
  vendor4_category: string;
  vendor4_status: string;
  vendor4_type: string;
  vendor4_email: string;
  vendor4_phone: string;
  vendor4_offerExpiry: string;
  vendor4_deposit: number;
  vendor4_remaining: number;
  vendor4_nextDue: string;
  vendor4_notes: string;
  vendor4_finalAmount: number;
  vendor4_chargeMode: string;
  vendor4_pricePerGuest: number;
  vendor4_minChargeGuests: number;
  vendor4_minChargeAmount: number;
  vendor4_daySeason: string;
  vendor4_daySeasonMultiplier: number;
  vendor4_tiers: PricingTier[];
  vendor4_addonsPerGuest: AddonItem[];
  vendor4_addonsPerEvent: AddonItem[];
  vendor4_childrenRules: ChildrenRules;
  vendor4_scenarioMode: string;
  vendor4_maybePct: number;
  vendor4_noReplyPct: number;
  vendor4_arrivalFactor: number;
  vendor4_guestsMin: number;
  vendor4_guestsLikely: number;
  vendor4_guestsMax: number;
  vendor4_guestsChosen: number;
  vendor4_totalFloor: number;
  vendor4_totalForecast: number;
  vendor4_totalCeiling: number;
  vendor4_breakdownText: string;
  vendor4_totalNormalized: number;
  // Vendor 5
  vendor5_visible: boolean;
  vendor5_name: string;
  vendor5_category: string;
  vendor5_status: string;
  vendor5_type: string;
  vendor5_email: string;
  vendor5_phone: string;
  vendor5_offerExpiry: string;
  vendor5_deposit: number;
  vendor5_remaining: number;
  vendor5_nextDue: string;
  vendor5_notes: string;
  vendor5_finalAmount: number;
  vendor5_chargeMode: string;
  vendor5_pricePerGuest: number;
  vendor5_minChargeGuests: number;
  vendor5_minChargeAmount: number;
  vendor5_daySeason: string;
  vendor5_daySeasonMultiplier: number;
  vendor5_tiers: PricingTier[];
  vendor5_addonsPerGuest: AddonItem[];
  vendor5_addonsPerEvent: AddonItem[];
  vendor5_childrenRules: ChildrenRules;
  vendor5_scenarioMode: string;
  vendor5_maybePct: number;
  vendor5_noReplyPct: number;
  vendor5_arrivalFactor: number;
  vendor5_guestsMin: number;
  vendor5_guestsLikely: number;
  vendor5_guestsMax: number;
  vendor5_guestsChosen: number;
  vendor5_totalFloor: number;
  vendor5_totalForecast: number;
  vendor5_totalCeiling: number;
  vendor5_breakdownText: string;
  vendor5_totalNormalized: number;
  // Vendor 6
  vendor6_visible: boolean;
  vendor6_name: string;
  vendor6_category: string;
  vendor6_status: string;
  vendor6_type: string;
  vendor6_email: string;
  vendor6_phone: string;
  vendor6_offerExpiry: string;
  vendor6_deposit: number;
  vendor6_remaining: number;
  vendor6_nextDue: string;
  vendor6_notes: string;
  vendor6_finalAmount: number;
  vendor6_chargeMode: string;
  vendor6_pricePerGuest: number;
  vendor6_minChargeGuests: number;
  vendor6_minChargeAmount: number;
  vendor6_daySeason: string;
  vendor6_daySeasonMultiplier: number;
  vendor6_tiers: PricingTier[];
  vendor6_addonsPerGuest: AddonItem[];
  vendor6_addonsPerEvent: AddonItem[];
  vendor6_childrenRules: ChildrenRules;
  vendor6_scenarioMode: string;
  vendor6_maybePct: number;
  vendor6_noReplyPct: number;
  vendor6_arrivalFactor: number;
  vendor6_guestsMin: number;
  vendor6_guestsLikely: number;
  vendor6_guestsMax: number;
  vendor6_guestsChosen: number;
  vendor6_totalFloor: number;
  vendor6_totalForecast: number;
  vendor6_totalCeiling: number;
  vendor6_breakdownText: string;
  vendor6_totalNormalized: number;
  // Vendor 7
  vendor7_visible: boolean;
  vendor7_name: string;
  vendor7_category: string;
  vendor7_status: string;
  vendor7_type: string;
  vendor7_email: string;
  vendor7_phone: string;
  vendor7_offerExpiry: string;
  vendor7_deposit: number;
  vendor7_remaining: number;
  vendor7_nextDue: string;
  vendor7_notes: string;
  vendor7_finalAmount: number;
  vendor7_chargeMode: string;
  vendor7_pricePerGuest: number;
  vendor7_minChargeGuests: number;
  vendor7_minChargeAmount: number;
  vendor7_daySeason: string;
  vendor7_daySeasonMultiplier: number;
  vendor7_tiers: PricingTier[];
  vendor7_addonsPerGuest: AddonItem[];
  vendor7_addonsPerEvent: AddonItem[];
  vendor7_childrenRules: ChildrenRules;
  vendor7_scenarioMode: string;
  vendor7_maybePct: number;
  vendor7_noReplyPct: number;
  vendor7_arrivalFactor: number;
  vendor7_guestsMin: number;
  vendor7_guestsLikely: number;
  vendor7_guestsMax: number;
  vendor7_guestsChosen: number;
  vendor7_totalFloor: number;
  vendor7_totalForecast: number;
  vendor7_totalCeiling: number;
  vendor7_breakdownText: string;
  vendor7_totalNormalized: number;
  // Vendor 8
  vendor8_visible: boolean;
  vendor8_name: string;
  vendor8_category: string;
  vendor8_status: string;
  vendor8_type: string;
  vendor8_email: string;
  vendor8_phone: string;
  vendor8_offerExpiry: string;
  vendor8_deposit: number;
  vendor8_remaining: number;
  vendor8_nextDue: string;
  vendor8_notes: string;
  vendor8_finalAmount: number;
  vendor8_chargeMode: string;
  vendor8_pricePerGuest: number;
  vendor8_minChargeGuests: number;
  vendor8_minChargeAmount: number;
  vendor8_daySeason: string;
  vendor8_daySeasonMultiplier: number;
  vendor8_tiers: PricingTier[];
  vendor8_addonsPerGuest: AddonItem[];
  vendor8_addonsPerEvent: AddonItem[];
  vendor8_childrenRules: ChildrenRules;
  vendor8_scenarioMode: string;
  vendor8_maybePct: number;
  vendor8_noReplyPct: number;
  vendor8_arrivalFactor: number;
  vendor8_guestsMin: number;
  vendor8_guestsLikely: number;
  vendor8_guestsMax: number;
  vendor8_guestsChosen: number;
  vendor8_totalFloor: number;
  vendor8_totalForecast: number;
  vendor8_totalCeiling: number;
  vendor8_breakdownText: string;
  vendor8_totalNormalized: number;
}

interface DashVars {
  tasksTodayCount: number;
  guestsCount: number;
}

// Helper function to calculate days between dates
const dateDiffInDays = (
  startDate: Date,
  endDate: Date,
): number => {
  const diffTime = endDate.getTime() - startDate.getTime();
  return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
};

// Helper function to compute vendor pricing
const computeVendorPricing = (
  vendorIndex: number,
  suppliersVars: SuppliersVars,
  rsvpVars: RSVPVars,
  budgetVars: BudgetVars,
) => {
  const prefix = `vendor${vendorIndex}_`;

  // Get vendor data
  const visible = suppliersVars[
    `${prefix}visible` as keyof SuppliersVars
  ] as boolean;
  if (!visible) return {};

  const status = suppliersVars[
    `${prefix}status` as keyof SuppliersVars
  ] as string;

  // For committed suppliers, use finalAmount directly
  if (status === "התחייב") {
    const finalAmount = suppliersVars[
      `${prefix}finalAmount` as keyof SuppliersVars
    ] as number;
    
    return {
      [`${prefix}totalNormalized`]: finalAmount || 0,
      [`${prefix}totalForecast`]: finalAmount || 0,
      [`${prefix}breakdownText`]: finalAmount ? `סכום מוסכם: ₪${finalAmount.toLocaleString('he-IL')}` : "—"
    };
  }

  const scenarioMode =
    (suppliersVars[
      `${prefix}scenarioMode` as keyof SuppliersVars
    ] as string) || "likely";
  const maybePct =
    (suppliersVars[
      `${prefix}maybePct` as keyof SuppliersVars
    ] as number) || 0.6;
  const noReplyPct =
    (suppliersVars[
      `${prefix}noReplyPct` as keyof SuppliersVars
    ] as number) || 0.3;
  const arrivalFactor =
    (suppliersVars[
      `${prefix}arrivalFactor` as keyof SuppliersVars
    ] as number) || 1.0;
  const pricePerGuest =
    (suppliersVars[
      `${prefix}pricePerGuest` as keyof SuppliersVars
    ] as number) || 0;
  const minChargeGuests =
    (suppliersVars[
      `${prefix}minChargeGuests` as keyof SuppliersVars
    ] as number) || 0;
  const minChargeAmount =
    (suppliersVars[
      `${prefix}minChargeAmount` as keyof SuppliersVars
    ] as number) || 0;
  const daySeasonMultiplier =
    (suppliersVars[
      `${prefix}daySeasonMultiplier` as keyof SuppliersVars
    ] as number) || 1.0;
  const tiers =
    (suppliersVars[
      `${prefix}tiers` as keyof SuppliersVars
    ] as PricingTier[]) || [];
  const addonsPerGuest =
    (suppliersVars[
      `${prefix}addonsPerGuest` as keyof SuppliersVars
    ] as AddonItem[]) || [];
  const addonsPerEvent =
    (suppliersVars[
      `${prefix}addonsPerEvent` as keyof SuppliersVars
    ] as AddonItem[]) || [];

  // Compute guest counts
  const guestsMin =
    budgetVars.guestsMin > 0
      ? budgetVars.guestsMin
      : rsvpVars.acceptedCount;
  const guestsLikely = Math.round(
    rsvpVars.acceptedCount +
      maybePct * rsvpVars.maybeCount +
      noReplyPct * rsvpVars.noReplyCount,
  );
  const guestsMax =
    budgetVars.guestsMax > 0
      ? budgetVars.guestsMax
      : rsvpVars.invitedCount - rsvpVars.declinedCount;

  // Choose guest count based on scenario
  let guestsChosen = guestsLikely;
  if (scenarioMode === "min") guestsChosen = guestsMin;
  else if (scenarioMode === "max") guestsChosen = guestsMax;

  // Apply arrival factor
  guestsChosen = Math.round(guestsChosen * arrivalFactor);

  // Find applicable tier price
  let priceChosen = pricePerGuest;
  for (const tier of tiers) {
    if (guestsChosen >= tier.min && guestsChosen <= tier.max) {
      priceChosen = tier.pricePerGuest;
      break;
    }
  }

  // Calculate add-ons
  const addonsPerGuestTotal = addonsPerGuest
    .filter((addon) => addon.enabled)
    .reduce((sum, addon) => sum + addon.amount, 0);

  const addonsPerEventTotal = addonsPerEvent
    .filter((addon) => addon.enabled)
    .reduce((sum, addon) => sum + addon.amount, 0);

  // Calculate base per guest
  const basePerGuest =
    (priceChosen + addonsPerGuestTotal) * daySeasonMultiplier;

  // Calculate totals
  const subtotalGuests = guestsChosen * basePerGuest;
  const totalForecast = Math.round(
    subtotalGuests + addonsPerEventTotal,
  );

  const totalFloor = Math.max(
    minChargeAmount,
    minChargeGuests > 0 ? minChargeGuests * basePerGuest : 0,
  );

  // Calculate ceiling (max scenario)
  const guestsMaxScenario = Math.round(
    guestsMax * arrivalFactor,
  );
  const subtotalMaxGuests = guestsMaxScenario * basePerGuest;
  const totalCeiling = Math.round(
    subtotalMaxGuests + addonsPerEventTotal,
  );

  // Generate breakdown text
  const breakdownText = `${guestsChosen}×₪${Math.round(basePerGuest)} + אירוע ₪${addonsPerEventTotal} → ₪${totalForecast}`;

  // Only committed suppliers contribute to budget
  const totalNormalized = status === "התחייב" ? totalForecast : 0;

  return {
    [`${prefix}guestsMin`]: guestsMin,
    [`${prefix}guestsLikely`]: guestsLikely,
    [`${prefix}guestsMax`]: guestsMax,
    [`${prefix}guestsChosen`]: guestsChosen,
    [`${prefix}totalFloor`]: totalFloor,
    [`${prefix}totalForecast`]: totalForecast,
    [`${prefix}totalCeiling`]: totalCeiling,
    [`${prefix}breakdownText`]: breakdownText,
    [`${prefix}totalNormalized`]: totalNormalized,
  };
};

// Screens that should have bottom navigation
const screensWithBottomNav = [
  'dashboard',
  'budget',
  'budget-overview', 
  'new-budget-wizard',
  'guests',
  'tasks',
  'suppliers',
  'add-supplier',
  'supplier-commitment',
  'settings',
  'members-permissions'
];

export default function App() {
  const [currentScreen, setCurrentScreen] =
    useState<Screen>("auth");

  // Banner state for demo notifications
  const [activeBanners, setActiveBanners] = useState<any[]>([]);

  // Figma Variables - ALL EMPTY/ZERO BY DEFAULT
  const [appState, setAppState] = useState<AppState>({
    isAuthenticated: false,
    isViewOnly: false,
    hasEventDate: false,
    coupleName: "",
  });

  const [event, setEvent] = useState<Event>({
    eventName: "",
    eventNameEdited: false,
    eventDate: "",
  });

  const [countdown, setCountdown] = useState<Countdown>({
    daysLeft: 0,
  });

  const [rsvpVars, setRsvpVars] = useState<RSVPVars>({
    invitedCount: 0,
    acceptedCount: 0,
    maybeCount: 0,
    noReplyCount: 0,
    declinedCount: 0,
  });

  const [budgetVars, setBudgetVars] = useState<BudgetVars>({
    guestsMin: 0,
    guestsMax: 0,
    guestsExact: 0,
    giftAvg: 0,
    targetMode: "reset",
    ownContribution: 0,
    savePercent: 0,
    giftsMin: 0,
    giftsMax: 0,
    targetExact: 0,
    targetMin: 0,
    targetMax: 0,
    forecastTotal: 0,
  });

  const [suppliersVars, setSuppliersVars] =
    useState<SuppliersVars>({
      committedCount: 0,
      // Vendor 1
      vendor1_visible: false,
      vendor1_name: "",
      vendor1_category: "",
      vendor1_status: "",
      vendor1_type: "",
      vendor1_email: "",
      vendor1_phone: "",
      vendor1_offerExpiry: "",
      vendor1_deposit: 0,
      vendor1_remaining: 0,
      vendor1_nextDue: "",
      vendor1_notes: "",
      vendor1_finalAmount: 0,
      vendor1_chargeMode: "",
      vendor1_pricePerGuest: 0,
      vendor1_minChargeGuests: 0,
      vendor1_minChargeAmount: 0,
      vendor1_daySeason: "ordinary",
      vendor1_daySeasonMultiplier: 1.0,
      vendor1_tiers: [],
      vendor1_addonsPerGuest: [],
      vendor1_addonsPerEvent: [],
      vendor1_childrenRules: {
        freeUnder: 0,
        percentUnder: 0,
        staffRate: 0,
      },
      vendor1_scenarioMode: "likely",
      vendor1_maybePct: 0.6,
      vendor1_noReplyPct: 0.3,
      vendor1_arrivalFactor: 1.0,
      vendor1_guestsMin: 0,
      vendor1_guestsLikely: 0,
      vendor1_guestsMax: 0,
      vendor1_guestsChosen: 0,
      vendor1_totalFloor: 0,
      vendor1_totalForecast: 0,
      vendor1_totalCeiling: 0,
      vendor1_breakdownText: "",
      vendor1_totalNormalized: 0,
      // Vendor 2
      vendor2_visible: false,
      vendor2_name: "",
      vendor2_category: "",
      vendor2_status: "",
      vendor2_type: "",
      vendor2_email: "",
      vendor2_phone: "",
      vendor2_offerExpiry: "",
      vendor2_deposit: 0,
      vendor2_remaining: 0,
      vendor2_nextDue: "",
      vendor2_notes: "",
      vendor2_finalAmount: 0,
      vendor2_chargeMode: "",
      vendor2_pricePerGuest: 0,
      vendor2_minChargeGuests: 0,
      vendor2_minChargeAmount: 0,
      vendor2_daySeason: "ordinary",
      vendor2_daySeasonMultiplier: 1.0,
      vendor2_tiers: [],
      vendor2_addonsPerGuest: [],
      vendor2_addonsPerEvent: [],
      vendor2_childrenRules: {
        freeUnder: 0,
        percentUnder: 0,
        staffRate: 0,
      },
      vendor2_scenarioMode: "likely",
      vendor2_maybePct: 0.6,
      vendor2_noReplyPct: 0.3,
      vendor2_arrivalFactor: 1.0,
      vendor2_guestsMin: 0,
      vendor2_guestsLikely: 0,
      vendor2_guestsMax: 0,
      vendor2_guestsChosen: 0,
      vendor2_totalFloor: 0,
      vendor2_totalForecast: 0,
      vendor2_totalCeiling: 0,
      vendor2_breakdownText: "",
      vendor2_totalNormalized: 0,
      // Vendor 3
      vendor3_visible: false,
      vendor3_name: "",
      vendor3_category: "",
      vendor3_status: "",
      vendor3_type: "",
      vendor3_email: "",
      vendor3_phone: "",
      vendor3_offerExpiry: "",
      vendor3_deposit: 0,
      vendor3_remaining: 0,
      vendor3_nextDue: "",
      vendor3_notes: "",
      vendor3_finalAmount: 0,
      vendor3_chargeMode: "",
      vendor3_pricePerGuest: 0,
      vendor3_minChargeGuests: 0,
      vendor3_minChargeAmount: 0,
      vendor3_daySeason: "ordinary",
      vendor3_daySeasonMultiplier: 1.0,
      vendor3_tiers: [],
      vendor3_addonsPerGuest: [],
      vendor3_addonsPerEvent: [],
      vendor3_childrenRules: {
        freeUnder: 0,
        percentUnder: 0,
        staffRate: 0,
      },
      vendor3_scenarioMode: "likely",
      vendor3_maybePct: 0.6,
      vendor3_noReplyPct: 0.3,
      vendor3_arrivalFactor: 1.0,
      vendor3_guestsMin: 0,
      vendor3_guestsLikely: 0,
      vendor3_guestsMax: 0,
      vendor3_guestsChosen: 0,
      vendor3_totalFloor: 0,
      vendor3_totalForecast: 0,
      vendor3_totalCeiling: 0,
      vendor3_breakdownText: "",
      vendor3_totalNormalized: 0,
      // Vendor 4
      vendor4_visible: false,
      vendor4_name: "",
      vendor4_category: "",
      vendor4_status: "",
      vendor4_type: "",
      vendor4_email: "",
      vendor4_phone: "",
      vendor4_offerExpiry: "",
      vendor4_deposit: 0,
      vendor4_remaining: 0,
      vendor4_nextDue: "",
      vendor4_notes: "",
      vendor4_finalAmount: 0,
      vendor4_chargeMode: "",
      vendor4_pricePerGuest: 0,
      vendor4_minChargeGuests: 0,
      vendor4_minChargeAmount: 0,
      vendor4_daySeason: "ordinary",
      vendor4_daySeasonMultiplier: 1.0,
      vendor4_tiers: [],
      vendor4_addonsPerGuest: [],
      vendor4_addonsPerEvent: [],
      vendor4_childrenRules: {
        freeUnder: 0,
        percentUnder: 0,
        staffRate: 0,
      },
      vendor4_scenarioMode: "likely",
      vendor4_maybePct: 0.6,
      vendor4_noReplyPct: 0.3,
      vendor4_arrivalFactor: 1.0,
      vendor4_guestsMin: 0,
      vendor4_guestsLikely: 0,
      vendor4_guestsMax: 0,
      vendor4_guestsChosen: 0,
      vendor4_totalFloor: 0,
      vendor4_totalForecast: 0,
      vendor4_totalCeiling: 0,
      vendor4_breakdownText: "",
      vendor4_totalNormalized: 0,
      // Vendor 5
      vendor5_visible: false,
      vendor5_name: "",
      vendor5_category: "",
      vendor5_status: "",
      vendor5_type: "",
      vendor5_email: "",
      vendor5_phone: "",
      vendor5_offerExpiry: "",
      vendor5_deposit: 0,
      vendor5_remaining: 0,
      vendor5_nextDue: "",
      vendor5_notes: "",
      vendor5_finalAmount: 0,
      vendor5_chargeMode: "",
      vendor5_pricePerGuest: 0,
      vendor5_minChargeGuests: 0,
      vendor5_minChargeAmount: 0,
      vendor5_daySeason: "ordinary",
      vendor5_daySeasonMultiplier: 1.0,
      vendor5_tiers: [],
      vendor5_addonsPerGuest: [],
      vendor5_addonsPerEvent: [],
      vendor5_childrenRules: {
        freeUnder: 0,
        percentUnder: 0,
        staffRate: 0,
      },
      vendor5_scenarioMode: "likely",
      vendor5_maybePct: 0.6,
      vendor5_noReplyPct: 0.3,
      vendor5_arrivalFactor: 1.0,
      vendor5_guestsMin: 0,
      vendor5_guestsLikely: 0,
      vendor5_guestsMax: 0,
      vendor5_guestsChosen: 0,
      vendor5_totalFloor: 0,
      vendor5_totalForecast: 0,
      vendor5_totalCeiling: 0,
      vendor5_breakdownText: "",
      vendor5_totalNormalized: 0,
      // Vendor 6
      vendor6_visible: false,
      vendor6_name: "",
      vendor6_category: "",
      vendor6_status: "",
      vendor6_type: "",
      vendor6_email: "",
      vendor6_phone: "",
      vendor6_offerExpiry: "",
      vendor6_deposit: 0,
      vendor6_remaining: 0,
      vendor6_nextDue: "",
      vendor6_notes: "",
      vendor6_finalAmount: 0,
      vendor6_chargeMode: "",
      vendor6_pricePerGuest: 0,
      vendor6_minChargeGuests: 0,
      vendor6_minChargeAmount: 0,
      vendor6_daySeason: "ordinary",
      vendor6_daySeasonMultiplier: 1.0,
      vendor6_tiers: [],
      vendor6_addonsPerGuest: [],
      vendor6_addonsPerEvent: [],
      vendor6_childrenRules: {
        freeUnder: 0,
        percentUnder: 0,
        staffRate: 0,
      },
      vendor6_scenarioMode: "likely",
      vendor6_maybePct: 0.6,
      vendor6_noReplyPct: 0.3,
      vendor6_arrivalFactor: 1.0,
      vendor6_guestsMin: 0,
      vendor6_guestsLikely: 0,
      vendor6_guestsMax: 0,
      vendor6_guestsChosen: 0,
      vendor6_totalFloor: 0,
      vendor6_totalForecast: 0,
      vendor6_totalCeiling: 0,
      vendor6_breakdownText: "",
      vendor6_totalNormalized: 0,
      // Vendor 7
      vendor7_visible: false,
      vendor7_name: "",
      vendor7_category: "",
      vendor7_status: "",
      vendor7_type: "",
      vendor7_email: "",
      vendor7_phone: "",
      vendor7_offerExpiry: "",
      vendor7_deposit: 0,
      vendor7_remaining: 0,
      vendor7_nextDue: "",
      vendor7_notes: "",
      vendor7_finalAmount: 0,
      vendor7_chargeMode: "",
      vendor7_pricePerGuest: 0,
      vendor7_minChargeGuests: 0,
      vendor7_minChargeAmount: 0,
      vendor7_daySeason: "ordinary",
      vendor7_daySeasonMultiplier: 1.0,
      vendor7_tiers: [],
      vendor7_addonsPerGuest: [],
      vendor7_addonsPerEvent: [],
      vendor7_childrenRules: {
        freeUnder: 0,
        percentUnder: 0,
        staffRate: 0,
      },
      vendor7_scenarioMode: "likely",
      vendor7_maybePct: 0.6,
      vendor7_noReplyPct: 0.3,
      vendor7_arrivalFactor: 1.0,
      vendor7_guestsMin: 0,
      vendor7_guestsLikely: 0,
      vendor7_guestsMax: 0,
      vendor7_guestsChosen: 0,
      vendor7_totalFloor: 0,
      vendor7_totalForecast: 0,
      vendor7_totalCeiling: 0,
      vendor7_breakdownText: "",
      vendor7_totalNormalized: 0,
      // Vendor 8
      vendor8_visible: false,
      vendor8_name: "",
      vendor8_category: "",
      vendor8_status: "",
      vendor8_type: "",
      vendor8_email: "",
      vendor8_phone: "",
      vendor8_offerExpiry: "",
      vendor8_deposit: 0,
      vendor8_remaining: 0,
      vendor8_nextDue: "",
      vendor8_notes: "",
      vendor8_finalAmount: 0,
      vendor8_chargeMode: "",
      vendor8_pricePerGuest: 0,
      vendor8_minChargeGuests: 0,
      vendor8_minChargeAmount: 0,
      vendor8_daySeason: "ordinary",
      vendor8_daySeasonMultiplier: 1.0,
      vendor8_tiers: [],
      vendor8_addonsPerGuest: [],
      vendor8_addonsPerEvent: [],
      vendor8_childrenRules: {
        freeUnder: 0,
        percentUnder: 0,
        staffRate: 0,
      },
      vendor8_scenarioMode: "likely",
      vendor8_maybePct: 0.6,
      vendor8_noReplyPct: 0.3,
      vendor8_arrivalFactor: 1.0,
      vendor8_guestsMin: 0,
      vendor8_guestsLikely: 0,
      vendor8_guestsMax: 0,
      vendor8_guestsChosen: 0,
      vendor8_totalFloor: 0,
      vendor8_totalForecast: 0,
      vendor8_totalCeiling: 0,
      vendor8_breakdownText: "",
      vendor8_totalNormalized: 0,
    });

  const [dashVars, setDashVars] = useState<DashVars>(() => {
    try {
      const saved = localStorage.getItem("dashVars");
      return saved
        ? JSON.parse(saved)
        : { tasksTodayCount: 0, guestsCount: 0 };
    } catch {
      return { tasksTodayCount: 0, guestsCount: 0 };
    }
  });

  const removeBanner = (id: string) => {
    setActiveBanners(prev => prev.filter(banner => banner.id !== id));
  };

  // Supplier commitment handlers
  const handleSupplierCommitted = (supplierName: string, finalAmount: number) => {
    if (window.toast) {
      window.toast.success('ספק התחייב—התווסף לתקציב', '', {
        label: 'צפייה בתקציב',
        onClick: () => setCurrentScreen('budget-overview')
      });
    }
  };

  const handleSupplierUpdatedCommitment = (supplierName: string) => {
    if (window.toast) {
      window.toast.success('עודכן כהתחייב', '', {
        label: 'צפייה בתקציב', 
        onClick: () => setCurrentScreen('budget-overview')
      });
    }
  };

  // Memoize vendor visibility and status data to prevent unnecessary recalculations
  const vendorData = useMemo(() => {
    const data = [];
    for (let i = 1; i <= 8; i++) {
      data.push({
        visible: suppliersVars[`vendor${i}_visible` as keyof SuppliersVars] as boolean,
        status: suppliersVars[`vendor${i}_status` as keyof SuppliersVars] as string,
        finalAmount: suppliersVars[`vendor${i}_finalAmount` as keyof SuppliersVars] as number,
        totalNormalized: suppliersVars[`vendor${i}_totalNormalized` as keyof SuppliersVars] as number
      });
    }
    return data;
  }, [
    suppliersVars.vendor1_visible, suppliersVars.vendor1_status, suppliersVars.vendor1_finalAmount, suppliersVars.vendor1_totalNormalized,
    suppliersVars.vendor2_visible, suppliersVars.vendor2_status, suppliersVars.vendor2_finalAmount, suppliersVars.vendor2_totalNormalized,
    suppliersVars.vendor3_visible, suppliersVars.vendor3_status, suppliersVars.vendor3_finalAmount, suppliersVars.vendor3_totalNormalized,
    suppliersVars.vendor4_visible, suppliersVars.vendor4_status, suppliersVars.vendor4_finalAmount, suppliersVars.vendor4_totalNormalized,
    suppliersVars.vendor5_visible, suppliersVars.vendor5_status, suppliersVars.vendor5_finalAmount, suppliersVars.vendor5_totalNormalized,
    suppliersVars.vendor6_visible, suppliersVars.vendor6_status, suppliersVars.vendor6_finalAmount, suppliersVars.vendor6_totalNormalized,
    suppliersVars.vendor7_visible, suppliersVars.vendor7_status, suppliersVars.vendor7_finalAmount, suppliersVars.vendor7_totalNormalized,
    suppliersVars.vendor8_visible, suppliersVars.vendor8_status, suppliersVars.vendor8_finalAmount, suppliersVars.vendor8_totalNormalized
  ]);

  // Recompute countdown when dashboard loads and we have a date
  useEffect(() => {
    if (
      currentScreen === "dashboard" &&
      appState.hasEventDate &&
      event.eventDate
    ) {
      const eventDateObj = new Date(event.eventDate);
      const today = new Date();
      const daysLeft = dateDiffInDays(today, eventDateObj);

      setCountdown((prev) => ({
        ...prev,
        daysLeft: daysLeft,
      }));
    }
  }, [currentScreen, appState.hasEventDate, event.eventDate]);

  // Calculate forecast total and committed count from vendor data - FIXED to prevent infinite loop
  useEffect(() => {
    let forecastTotal = 0;
    let committedCount = 0;

    vendorData.forEach(vendor => {
      if (vendor.visible && vendor.status === "התחייב") {
        forecastTotal += vendor.totalNormalized || 0;
        committedCount++;
      }
    });

    // Only update if values actually changed
    setBudgetVars(prev => {
      if (prev.forecastTotal !== forecastTotal) {
        return { ...prev, forecastTotal };
      }
      return prev;
    });

    setSuppliersVars(prev => {
      if (prev.committedCount !== committedCount) {
        return { ...prev, committedCount };
      }
      return prev;
    });
  }, [vendorData]);

  // Calculate vendor pricing computations - FIXED to prevent infinite loop
  useEffect(() => {
    const updates: Partial<SuppliersVars> = {};

    for (let i = 1; i <= 8; i++) {
      const computed = computeVendorPricing(
        i,
        suppliersVars,
        rsvpVars,
        budgetVars,
      );
      Object.assign(updates, computed);
    }

    if (Object.keys(updates).length > 0) {
      setSuppliersVars((prev) => ({ ...prev, ...updates }));
    }
  }, [
    // Only depend on input fields that affect the calculation, not computed fields
    suppliersVars.vendor1_visible,
    suppliersVars.vendor1_status,
    suppliersVars.vendor1_finalAmount,
    suppliersVars.vendor1_pricePerGuest,
    suppliersVars.vendor1_scenarioMode,
    suppliersVars.vendor2_visible,
    suppliersVars.vendor2_status,
    suppliersVars.vendor2_finalAmount,
    suppliersVars.vendor2_pricePerGuest,
    suppliersVars.vendor2_scenarioMode,
    suppliersVars.vendor3_visible,
    suppliersVars.vendor3_status,
    suppliersVars.vendor3_finalAmount,
    suppliersVars.vendor3_pricePerGuest,
    suppliersVars.vendor3_scenarioMode,
    suppliersVars.vendor4_visible,
    suppliersVars.vendor4_status,
    suppliersVars.vendor4_finalAmount,
    suppliersVars.vendor4_pricePerGuest,
    suppliersVars.vendor4_scenarioMode,
    suppliersVars.vendor5_visible,
    suppliersVars.vendor5_status,
    suppliersVars.vendor5_finalAmount,
    suppliersVars.vendor5_pricePerGuest,
    suppliersVars.vendor5_scenarioMode,
    suppliersVars.vendor6_visible,
    suppliersVars.vendor6_status,
    suppliersVars.vendor6_finalAmount,
    suppliersVars.vendor6_pricePerGuest,
    suppliersVars.vendor6_scenarioMode,
    suppliersVars.vendor7_visible,
    suppliersVars.vendor7_status,
    suppliersVars.vendor7_finalAmount,
    suppliersVars.vendor7_pricePerGuest,
    suppliersVars.vendor7_scenarioMode,
    suppliersVars.vendor8_visible,
    suppliersVars.vendor8_status,
    suppliersVars.vendor8_finalAmount,
    suppliersVars.vendor8_pricePerGuest,
    suppliersVars.vendor8_scenarioMode,
    rsvpVars,
    budgetVars.guestsMin,
    budgetVars.guestsMax,
  ]);

  // Save dashVars to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(
        "dashVars",
        JSON.stringify(dashVars),
      );
    } catch {}
  }, [dashVars]);

  // NEVER reset variables on navigation - they persist
  const handleAuthSuccess = (name?: string) => {
    setAppState((prev) => ({
      ...prev,
      isAuthenticated: true,
      isViewOnly: false,
      coupleName: name || "",
    }));
    setCurrentScreen("dashboard");
  };

  const handleDemoMode = () => {
    setAppState((prev) => ({
      ...prev,
      isAuthenticated: false,
      isViewOnly: true,
      coupleName: "",
    }));
    setCurrentScreen("dashboard");
  };

  const handleNavigate = (screen: string) => {
    setCurrentScreen(screen as Screen);
  };

  const handleBudgetWizardComplete = (data: any) => {
    // Update budget variables from wizard
    setBudgetVars((prev) => ({
      ...prev,
      ...data,
    }));
    setCurrentScreen("budget-overview");
  };

  const handleBudgetWizardCancel = () => {
    setCurrentScreen("dashboard");
  };

  const handleEventDateSet = (eventData: {
    date: Date;
    eventName: string;
    daysLeft: number;
  }) => {
    setAppState((prev) => ({
      ...prev,
      hasEventDate: true,
    }));
    setEvent((prev) => ({
      ...prev,
      eventName: eventData.eventName,
      eventNameEdited: true,
      eventDate: eventData.date.toISOString().split("T")[0],
    }));
    setCountdown((prev) => ({
      ...prev,
      daysLeft: eventData.daysLeft,
    }));
    setCurrentScreen("dashboard");
  };

  const handleEventDateSkip = () => {
    setCurrentScreen("dashboard");
  };

  const handleJoin = () => {
    // Mock join functionality - in real app this would handle authentication
    setCurrentScreen("dashboard");
  };

  // Check if current screen should have bottom navigation
  const shouldShowBottomNav = screensWithBottomNav.includes(currentScreen);

  // Screens that should NOT have bottom navigation (full-screen experiences)
  if (currentScreen === "auth") {
    return (
      <>
        <Auth
          onAuthSuccess={handleAuthSuccess}
          onDemoMode={handleDemoMode}
        />
        <ToastContainer />
        <Toaster />
      </>
    );
  }

  if (currentScreen === "event-date") {
    return (
      <>
        <EventDateSelector
          appState={appState}
          setAppState={setAppState}
          event={event}
          setEvent={setEvent}
          countdown={countdown}
          setCountdown={setCountdown}
          onDateSet={handleEventDateSet}
          onSkip={handleEventDateSkip}
        />
        <ToastContainer />
        <Toaster />
      </>
    );
  }

  if (currentScreen === "join-landing") {
    return (
      <>
        <JoinLanding
          coupleName="זוג החתן והכלה"
          role="Planner"
          permissions={{
            view: ["ספקים", "משימות"],
            edit: ["ספקים", "משימות"],
            hidden: ["מתנות", "נתוני חיובים פרטיים"],
          }}
          onJoin={handleJoin}
        />
        <ToastContainer />
        <Toaster />
      </>
    );
  }

  // Render screen content function  
  const renderScreenContent = () => {
    switch (currentScreen) {
      case "dashboard":
        return (
          <Dashboard
            appState={appState}
            event={event}
            countdown={countdown}
            budgetVars={budgetVars}
            dashVars={dashVars}
            suppliersVars={suppliersVars}
            onNavigate={handleNavigate}
            setDashVars={setDashVars}
          />
        );

      case "new-budget-wizard":
        return (
          <NewBudgetWizard
            onComplete={handleBudgetWizardComplete}
            onCancel={handleBudgetWizardCancel}
            budgetVars={budgetVars}
            setBudgetVars={setBudgetVars}
            suppliersVars={suppliersVars}
            onNavigate={handleNavigate}
            onBack={() => setCurrentScreen("dashboard")}
          />
        );

      case "budget-overview":
        return (
          <BudgetOverview
            budgetVars={budgetVars}
            suppliersVars={suppliersVars}
            onEdit={() => setCurrentScreen("new-budget-wizard")}
            onBack={() => setCurrentScreen("dashboard")}
            onAddFirstSupplier={() => setCurrentScreen("suppliers")}
          />
        );

      case "budget":
        return (
          <Budget
            budgetVars={budgetVars}
            onBack={() => setCurrentScreen("dashboard")}
            onNavigate={handleNavigate}
          />
        );

      case "guests":
        return (
          <Guests
            dashVars={dashVars}
            setDashVars={setDashVars}
            rsvpVars={rsvpVars}
            setRsvpVars={setRsvpVars}
            onBack={() => setCurrentScreen("dashboard")}
          />
        );

      case "tasks":
        return (
          <Tasks
            dashVars={dashVars}
            setDashVars={setDashVars}
            suppliersVars={suppliersVars}
            onNavigate={handleNavigate}
            onBack={() => setCurrentScreen("dashboard")}
          />
        );

      case "suppliers":
      case "add-supplier":
      case "supplier-commitment":
        return (
          <Suppliers
            budgetVars={budgetVars}
            suppliersVars={suppliersVars}
            setSuppliersVars={setSuppliersVars}
            onNavigate={handleNavigate}
            onSupplierCommitted={handleSupplierCommitted}
            onSupplierUpdatedCommitment={handleSupplierUpdatedCommitment}
            currentView={currentScreen === "add-supplier" ? "add" : currentScreen === "supplier-commitment" ? "commitment" : "list"}
            onBack={() => setCurrentScreen("dashboard")}
          />
        );

      case "members-permissions":
        return (
          <MembersPermissionsSettings
            onBack={() => setCurrentScreen("settings")}
          />
        );

      case "settings":
        return (
          <>
            {/* Header with Back Button */}
            <div style={{backgroundColor: '#EFF5FB', minHeight: '88px'}} className="relative">
              <div className="flex items-center justify-between px-6 py-4 relative z-10">
                <BackButton onBack={() => setCurrentScreen("dashboard")} />
                <div className="text-center relative">
                  <h1 className="section-title text-primary">
                    הגדרות
                  </h1>
                  {/* Decorative sparkles */}
                  <div
                    className="absolute -top-1 -left-4 w-1.5 h-1.5 rotate-45 opacity-45"
                    style={{ backgroundColor: "#89B3E0" }}
                  ></div>
                  <div
                    className="absolute top-0 -right-6 w-2 h-2 rotate-45 opacity-40"
                    style={{ backgroundColor: "#F7D7A3" }}
                  ></div>
                  <div
                    className="absolute -bottom-1 left-8 w-1 h-1 rotate-45 opacity-50"
                    style={{ backgroundColor: "#89B3E0" }}
                  ></div>
                </div>
                <div className="w-20"></div>
              </div>
            </div>
            <div className="p-8">
              <div className="grid gap-4 max-w-md mx-auto">
                {/* Members & Permissions Card */}
                <div
                  className="card cursor-pointer hover:shadow-lg transition-all duration-200"
                  onClick={() =>
                    setCurrentScreen("members-permissions")
                  }
                >
                  <div className="p-6 text-center" dir="rtl">
                    <div
                      className="w-12 h-12 mx-auto rounded-full flex items-center justify-center mb-3 transition-all duration-300 hover:scale-110"
                      style={{
                        backgroundColor:
                          "var(--surface-sky-50)",
                      }}
                    >
                      <svg
                        className="w-6 h-6"
                        style={{ color: "var(--accent-sky)" }}
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={1.5}
                          d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197m13.5-9a2.25 2.25 0 11-4.5 0 2.25 2.25 0 014.5 0z"
                        />
                      </svg>
                    </div>
                    <h3
                      className="mb-2"
                      style={{ color: "var(--text-primary)" }}
                    >
                      שותפים והרשאות
                    </h3>
                    <p
                      className="text-sm"
                      style={{ color: "var(--text-secondary)" }}
                    >
                      נהלו מוזמנים, הזמנות וגישות
                    </p>
                  </div>
                </div>

                {/* General Settings (placeholder) */}
                <div className="card opacity-50">
                  <div
                    className="p-6 text-center space-y-3"
                    dir="rtl"
                  >
                    <div
                      className="w-12 h-12 mx-auto rounded-full flex items-center justify-center transition-all duration-300 hover:scale-105 hover:rotate-6"
                      style={{
                        backgroundColor:
                          "var(--surface-gold-50)",
                      }}
                    >
                      <svg
                        className="w-6 h-6 transition-all duration-220"
                        style={{
                          color: "var(--accent-gold)",
                          transitionTimingFunction:
                            "cubic-bezier(.2,.8,.2,1)",
                        }}
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"
                        />
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"
                        />
                      </svg>
                    </div>
                    <h3
                      style={{ color: "var(--text-primary)" }}
                    >
                      הגדרות כלליות
                    </h3>
                    <p
                      className="text-sm"
                      style={{ color: "var(--text-muted)" }}
                    >
                      מודול בקרוב...
                    </p>
                    <div
                      className="p-3 rounded-lg transition-all duration-300 hover:scale-[1.02]"
                      style={{
                        color: "var(--text-muted)",
                        backgroundColor: "rgba(30,90,120,0.06)",
                        fontSize: "var(--text-meta)",
                        border:
                          "1px solid rgba(167,199,231,0.2)",
                      }}
                    >
                      יכלול: העדפות אישיות, גיבויים, אבטחה
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </>
        );

      default:
        return <div>Screen not found</div>;
    }
  };

  // Main app render with conditional Layout wrapper
  return (
    <>
      {/* Top Banners */}
      {activeBanners.map(banner => (
        <TopBanner
          key={banner.id}
          {...banner}
          onDismiss={removeBanner}
        />
      ))}

      {/* Conditionally wrap content with Layout (which includes bottom nav) */}
      {shouldShowBottomNav ? (
        <Layout currentScreen={currentScreen} onNavigate={handleNavigate}>
          {renderScreenContent()}
        </Layout>
      ) : (
        <>
          {renderScreenContent()}
        </>
      )}

      <ToastContainer />
      <Toaster />
    </>
  );
}