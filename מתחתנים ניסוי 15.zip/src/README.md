# אפליקציית תכנון חתונות

אפליקציית תכנון חתונות חכמה בעברית עם עיצוב מינימלי ומערכת משתנים מתקדמת.

## הגדרת הפרויקט

### 1. יצירת פרויקט חדש
```bash
npm create vite@latest wedding-planning-app -- --template react-ts
cd wedding-planning-app
```

### 2. התקנת Dependencies
```bash
npm install
```

Dependencies נדרשים:
- React 18+ עם TypeScript
- Tailwind CSS v4
- Radix UI components
- Lucide React icons
- Class Variance Authority
- Sonner (notifications)
- React Hook Form

### 3. הרצת הפרויקט
```bash
npm run dev
```

## מבנה הפרויקט

```
src/
├── App.tsx                 # קובץ ראשי עם כל הלוגיקה
├── main.tsx               # Entry point
├── lib/
│   └── utils.ts           # פונקציות עזר
├── components/
│   ├── ui/                # קומפוננטי shadcn/ui
│   ├── Auth.tsx           # מסך התחברות
│   ├── Layout.tsx         # פריסה ראשית
│   ├── Dashboard.tsx      # דשבורד ראשי
│   ├── Budget.tsx         # מסך תקציב
│   ├── Suppliers.tsx      # ניהול ספקים
│   ├── Guests.tsx         # ניהול אורחים
│   ├── Tasks.tsx          # ניהול משימות
│   └── ...
└── styles/
    └── globals.css        # עיצוב מותאם עברית + RTL
```

## עקרונות עיצוב

### NO FAKE DATA POLICY ⚠️
- כל המשתנים מתחילים ריקים/אפס
- אין נתונים מדומים או מזויפים
- ערכים ריקים מוצגים כ-"—"
- המשתנים נשמרים בין ניווטים

### מדיניות צבע מינימלית
- 90-95% נייטרלי (לבן, אפור עדין)
- צבע רק עבור: CTAs ראשיים, מצבים פעילים, focus rings
- כפתור ראשי יחיד בכל מסך

### RTL ועברית
- כיוון RTL בכל הממשק
- פונט Heebo מותאם עברית
- פורמט מטבע ישראלי (₪)
- תמיכה מלאה ב-WCAG 2.2 AA

## מתחילים לפתח

1. **הפעילו את הפרויקט** - הכל מוכן לעבודה
2. **פתחו קומפוננט אחד בכל פעם** - התחילו מ-Dashboard
3. **הוסיפו קומפוננטי shadcn/ui** לפי הצורך
4. **שמרו על עקרון "אין דאטה פיקטיבי"**

## מידע נוסף

- עיצוב: מינימלי, קפדני, RTL
- צבעים: #0B2F6A (Navy), #EEF2F6 (Porcelain)
- טיפוגרפיה: Heebo 400/600
- גריד: 4pt בסיס
- נגישות: WCAG 2.2 AA