# Wedding Planning App - Design Guidelines

## Overview
אפליקציית תכנון חתונות בעברית (RTL) עם עיצוב מינימלי קפדני ומתודולוגיית "vendors-first" מבוססת הצעות מחיר אמיתיות.

## **NO FAKE DATA POLICY** ⚠️

### Figma Variables - ALL EMPTY BY DEFAULT
```typescript
// AppState Collection
interface AppState {
  isAuthenticated: boolean = false;
  isViewOnly: boolean = false;
  hasEventDate: boolean = false;
  coupleName: string = "";
}

// Budget Collection
interface BudgetVars {
  guestsMin: number = 0;
  guestsMax: number = 0;
  guestsExact: number = 0;
  giftAvg: number = 0;
  targetMode: string = "reset"; // "reset" | "add" | "save"
  ownContribution: number = 0;
  savePercent: number = 0;
  giftsMin: number = 0;
  giftsMax: number = 0;
  targetExact: number = 0;
  targetMin: number = 0;
  targetMax: number = 0;
  forecastTotal: number = 0;
}

// Suppliers Collection (8 vendor slots, all invisible by default)
interface SuppliersVars {
  vendor1_visible: boolean = false;
  vendor1_status: string = ""; // "", "פתוח", "הצעה", "התחייב"
  vendor1_category: string = "";
  vendor1_type: string = ""; // "total" | "perGuest"
  vendor1_total: number = 0;
  vendor1_perGuest: number = 0;
  vendor1_deposit: number = 0;
  vendor1_remaining: number = 0;
  vendor1_dueDate: string = "";
  // ... repeat for vendor2-vendor8
  committedCount: number = 0;
}

// Dash Collection
interface DashVars {
  tasksTodayCount: number = 0;
  guestsCount: number = 0;
  filesCount: number = 0;
  upcomingPaymentsCount: number = 0;
}
```

### Empty State Display Rules
- **Zero/Empty Values**: Always show "—" (em dash)
- **Variable Binding**: ALL dynamic text bound to variables
- **No Pre-population**: Fields start empty, placeholders show gray examples
- **Persistent Variables**: NEVER reset on navigation
- **No Random Data**: No generation of fake content

## Core Design Principles

### 1. Minimal Color Policy (מדיניות צבע מינימלית)
- **90-95% נייטרלי**: כרטיסים לבנים, גבולות עדינים, טקסט אפור
- **צבע רק עבור**:
  - CTAs ראשיים (Primary buttons)
  - מצבים פעילים/נבחרים
  - Focus rings (טבעות פוקוס)
  - משוב סמנטי עם אייקון+טקסט (לא רקעים ממולאים)

### 2. One Primary CTA Policy (כפתור ראשי יחיד)
- **בכל מסך יש בדיוק כפתור ממולא אחד**
- דשבורד: תאריך → תקציב → משימה דחופה (לפי קדימות)
- אשף: המשך/שמירה
- סקירה: עריכה

### 3. Typography & RTL
- **פונט**: Heebo (Hebrew optimized)
- **כיוון**: RTL כברירת מחדל
- **גדלים**: 28px Display, 20px H1, 16px H2/Body, 14px Meta
- **משקלות**: 600 לכותרות, 400 לטקסט רגיל

## Empty State Patterns

### Dashboard Empty States
```typescript
// Event Date
{!appState.hasEventDate && (
  <Card>
    <h2>יאללה, בואו נקבע תאריך</h2>
    <Button>בחרו תאריך</Button> {/* PRIMARY CTA */}
    <button>דלגו כרגע</button> {/* Secondary link */}
  </Card>
)}

// Budget
{budgetVars.targetExact === 0 && budgetVars.targetMin === 0 ? (
  <div>עדיין אין נתונים</div>
) : (
  <div>{formatCurrency(budgetVars.targetExact || budgetVars.targetMin)}</div>
)}

// Tasks
{dashVars.tasksTodayCount === 0 ? (
  <div>אין משימות להיום</div>
) : (
  <div>{dashVars.tasksTodayCount} משימות להיום</div>
)}

// Payments
{dashVars.upcomingPaymentsCount === 0 ? (
  <div>אין תשלומים קרובים</div>
) : (
  <div>{dashVars.upcomingPaymentsCount} תשלומים קרובים</div>
)}

// Files
{dashVars.filesCount === 0 ? (
  <div>לא הועלו קבצים</div>
) : (
  <div>{dashVars.filesCount} קבצים הועלו</div>
)}

// Guests
<div>{dashVars.guestsCount || "—"}</div>

// Suppliers
{suppliersVars.committedCount === 0 && (
  <Card>
    <div>עדיין אין ספקים בתכנון</div>
    <Button variant="outline">פתחו ספקים</Button>
  </Card>
)}
```

### Budget Wizard Empty States
```typescript
// Step 1: Start with zeros, let user input
<Slider
  value={[budgetVars.guestsMin || 50, budgetVars.guestsMax || 150]}
  onValueChange={(values) => updateBudgetVars({ 
    guestsMin: values[0], 
    guestsMax: values[1] 
  })}
/>

// Computed displays
<div>
  {budgetVars.giftAvg > 0 
    ? formatCurrency(budgetVars.giftAvg)
    : "—"
  }
</div>

// Step 2: Link to suppliers (no embedded vendor UI)
<Card>
  <div>ספקים יתווספו בעמוד נפרד במערכת</div>
  <Button variant="outline">פתחו עמוד ספקים</Button>
</Card>

// Step 3: Empty until suppliers exist
{suppliersVars.committedCount === 0 ? (
  <Card>
    <div>עדיין אין נתונים לתחזית. הוסיפו ספקים בעמוד הספקים.</div>
    <Button variant="outline">פתחו עמוד ספקים</Button>
  </Card>
) : (
  // Show actual forecast data
)}
```

### Budget Overview Empty States
```typescript
{budgetVars.targetExact === 0 && budgetVars.targetMin === 0 ? (
  <Card>
    <h2>עדיין אין נתוני תקציב</h2>
    <p>נראה שלא הושלם תכנון התקציב</p>
    <Button>חזרו לתכנון התקציב</Button>
  </Card>
) : (
  // Show KPIs and data
)}

{suppliersVars.committedCount === 0 ? (
  <Card>
    <h2>עדיין אין ספקים נבחרים</h2>
    <p>הוסיפו ספקים כדי לראות פירוט תקציב מפורט</p>
    <Button variant="outline">פתחו עמוד ספקים</Button>
  </Card>
) : (
  // Show categories breakdown
)}
```

## Interaction Patterns

### Budget Calculations
```typescript
// ONLY calculate when user has input values
useEffect(() => {
  if (budgetVars.giftAvg === 0 || 
      (budgetVars.guestsMin === 0 && budgetVars.guestsExact === 0)) {
    return; // Don't calculate with zero values
  }

  const giftsMin = budgetVars.guestsMin * budgetVars.giftAvg;
  const giftsMax = budgetVars.guestsMax * budgetVars.giftAvg;
  
  let targetMin = giftsMin;
  let targetMax = giftsMax;
  
  if (budgetVars.targetMode === 'add' && budgetVars.ownContribution > 0) {
    targetMin += budgetVars.ownContribution;
    targetMax += budgetVars.ownContribution;
  }
  
  setBudgetVars({ ...budgetVars, giftsMin, giftsMax, targetMin, targetMax });
}, [budgetVars.guestsMin, budgetVars.giftAvg, budgetVars.targetMode]);
```

### Currency Formatting
```typescript
const formatCurrency = (amount: number): string => {
  if (amount === 0) return "—"; // Never show ₪0
  return new Intl.NumberFormat('he-IL', {
    style: 'currency',
    currency: 'ILS',
    minimumFractionDigits: 0
  }).format(amount);
};
```

### Input Patterns
```typescript
// Numeric inputs - start empty, show placeholders
<Input
  type="number"
  inputMode="numeric"
  value={budgetVars.guestsExact || ''}
  onChange={(e) => updateBudgetVars({ guestsExact: parseInt(e.target.value) || 0 })}
  placeholder="הזינו מספר מדויק"
  className="text-right focus:ring-2 focus:ring-primary"
  dir="rtl"
/>

// Sliders - show current value or default
<Slider
  value={[budgetVars.giftAvg || 100]}
  onValueChange={(value) => updateBudgetVars({ giftAvg: value[0] })}
  min={100} max={600} step={50}
/>
```

## Brand Colors & Tokens

```css
--brand-primary: #0B2F6A; /* Deep Navy - ONLY for strong accents */
--brand-secondary-soft: #EEF2F6; /* Porcelain - subtle backgrounds */
--background: #ffffff; /* base.white */
--foreground: #111111; /* text.primary */
--border-subtle: #7A8699;
```

## Component Guidelines

### Cards
- **רקע**: לבן (#ffffff)
- **גבולות**: עדינים (#7A8699)
- **ללא**: צבעי רקע, gradients, shadows כבדים
- **מרווחים**: 4pt grid (4, 8, 12, 16, 24, 32px)

### Buttons
```typescript
// Primary (exactly ONE per screen)
<Button className="bg-primary text-primary-foreground">
  CTA ראשי
</Button>

// Secondary (unlimited)
<Button variant="outline">
  פעולה משנית
</Button>

// Tertiary (unlimited)
<Button variant="ghost">
  פעולה שלישונית
</Button>
```

### Status Indicators
```typescript
// ALWAYS icon + text, NEVER color-only
const status = percentage <= 80 ? 'בגבול' : 
              percentage <= 100 ? 'בסיכון' : 'חריגה';

<div className="flex items-center gap-1">
  {status === 'בגבול' && <CheckCircle className="w-3 h-3 text-success" />}
  {status === 'בסיכון' && <Info className="w-3 h-3 text-warning" />}
  {status === 'חריגה' && <AlertCircle className="w-3 h-3 text-destructive" />}
  <span className="text-success">{status}</span>
</div>
```

## Accessibility Requirements

### Focus Management
- **כל אלמנט אינטראקטיבי**: `focus:ring-2 focus:ring-primary`
- **גודל מינימלי**: 44px לאזורי מגע
- **ניגודיות**: WCAG 2.2 AA (4.5:1 טקסט, 3:1 UI)

### RTL Support
```typescript
// Hebrew inputs
<Input dir="rtl" className="text-right" />

// Currency formatting
const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat('he-IL', {
    style: 'currency',
    currency: 'ILS',
    minimumFractionDigits: 0
  }).format(amount);
};

// Numeric inputs
<Input type="number" inputMode="numeric" dir="rtl" />
```

## Budget Wizard - Vendors-First Flow

### Step 0: Target Mode
```typescript
const BUDGET_MODES = [
  { id: 'break-even', title: 'ניצמד לתקציב (איפוס)' },
  { id: 'add-personal', title: 'נוסיף מכיס אישי' },
  { id: 'save-money', title: 'נכוון נמוך כדי להרווח' }
];
```

### Step 1: Anchors (Range vs Exact)
```typescript
// First visit: dual-handle range
<Slider
  value={[min, max]}
  onValueChange={(values) => setRange({ min: values[0], max: values[1] })}
  min={50} max={600} step={10}
/>

// Second visit: exact number with helper
<Input type="number" value={exactGuests} />
<p className="text-xs text-muted-foreground">
  הטווח ההתחלתי היה {min}–{max}
</p>
```

### Step 2: Vendors & Quotes
- **קטגוריות**: Multi-select chips
- **הצעות**: נרמול לפי אורח → סה"כ
- **השוואה**: טבלה עם ייצוא CSV
- **בחירה**: draft/selected/rejected states

### Step 3: Forecast & Feedback
```typescript
// KPIs in separate white cards
<div className="grid grid-cols-3 gap-4">
  <Card><CardContent>יעד: {formatCurrency(target)}</CardContent></Card>
  <Card><CardContent>צפוי: {formatCurrency(forecast)}</CardContent></Card>
  <Card><CardContent>הפרש: {formatCurrency(difference)}</CardContent></Card>
</div>

// % of budget with range support
const getPercentageDisplay = (amount: number) => {
  if (isExactGuests) {
    return `${Math.round((amount / target) * 100)}%`;
  }
  // Range: X%–Y%
  return `${minPercent}%–${maxPercent}%`;
};
```

## Dashboard Rules

### No Countdown Without Date
```typescript
// Show date selection CTA instead of countdown
{!eventDate && (
  <Card>
    <CardContent>
      <h2>יאללה, בואו נקבע תאריך</h2>
      <Button>בחרו תאריך</Button> {/* Primary CTA */}
      <button>דלגו כרגע</button> {/* Secondary text link */}
    </CardContent>
  </Card>
)}
```

### Card Priority
1. **תאריך אירוע** (אם לא הוגדר)
2. **תכנון תקציב** (אם לא הוגדר)
3. **מה היום?** (משימות)
4. **תשלומים קרובים**
5. **קבצים וחוזים**
6. **מוזמנים**

## Forbidden Elements

### ❌ NEVER DO
- Pre-fill ANY values (guests, prices, names, dates)
- Show mock/sample data
- Generate random content
- Reset variables on navigation
- Display ₪0 (use "—" instead)
- Auto-populate forms
- Create fake vendors, tasks, or files
- Show countdown without real date

### ✅ ALWAYS DO
- Start with empty/zero variables
- Show "—" for zero/empty values
- Bind ALL dynamic text to variables
- Use empty state placeholders
- Let users input their own data
- Persist variables across screens
- Focus ring on ALL interactive elements
- `dir="rtl"` for Hebrew inputs

## Development Patterns

### State Management
```typescript
interface BudgetData {
  mode: 'break-even' | 'add-personal' | 'save-money';
  guestRange: { min: number; max: number };
  guestCount?: number; // Second visit
  giftPerGuest: number;
  target: number;
  forecast: number;
}
```

### Navigation Flow
```
Auth → Dashboard (no countdown) → "בחרו תאריך" → 
Wizard: Target → Anchors → Vendors → Forecast → 
Save → Overview
```

### Error Handling
```typescript
// Toast notifications in Hebrew
import { toast } from 'sonner';
toast.success('התכנון נשמר בהצלחה!');
toast.error('שגיאה בשמירת הנתונים');
```

## Testing Checklist

班主任:
- [ ] כל המשתנים מתחילים ריקים/אפס
- [ ] אין נתונים מדומים בפתיחת הקובץ
- [ ] "—" מוצג עבור ערכים אפס
- [ ] כל הטקסט הדינמי קשור למשתנים
- [ ] אין איפוס משתנים בניווט
- [ ] empty states מוצגים כשאין נתונים
- [ ] כפתור ראשי יחיד בכל מסך
- [ ] פוקוס נראה על כל האלמנטים
- [ ] RTL עובד נכון
- [ ] מטבע מעוצב עם ₪ ומפרידי אלפים
- [ ] מצבים עם אייקון+טקסט